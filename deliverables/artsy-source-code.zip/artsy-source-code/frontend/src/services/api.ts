import { previewProfile } from '../content/preview-profile'
import type { Locale } from '../i18n/language'
import type { AuditEntry, MediaItem, Profile, ProfileEditorData, Project, ProjectEditorData } from '../types'

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code = 'request_failed',
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers)
  if (init.body && !(init.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  headers.set('Accept', 'application/json')

  const response = await fetch(path, {
    ...init,
    headers,
    credentials: 'same-origin',
  })

  if (response.status === 204) return undefined as T
  const contentType = response.headers.get('content-type') ?? ''
  let payload: unknown
  if (contentType.includes('application/json')) {
    payload = await response.json()
  } else {
    const text = await response.text()
    throw new ApiError(text || `Unexpected response (${response.status})`, response.status, 'invalid_response')
  }

  if (!response.ok) {
    const record = payload as { error?: { message?: string; code?: string } }
    throw new ApiError(
      record.error?.message ?? `Request failed (${response.status})`,
      response.status,
      record.error?.code,
    )
  }
  return payload as T
}

export async function getProfile(locale: Locale): Promise<Profile> {
  try {
    return await request<Profile>('/api/profile', {
      headers: { 'Accept-Language': locale },
    })
  } catch (error) {
    if (error instanceof TypeError || error instanceof ApiError && error.code === 'invalid_response') {
      return previewProfile
    }
    throw error
  }
}

export async function getProjects(locale: Locale): Promise<Project[]> {
  try {
    return await request<Project[]>('/api/projects', {
      headers: { 'Accept-Language': locale },
    })
  } catch (error) {
    if (error instanceof TypeError || error instanceof ApiError && error.code === 'invalid_response') return []
    throw error
  }
}

export async function getProject(locale: Locale, slug: string): Promise<Project | null> {
  try {
    return await request<Project>(`/api/projects/${encodeURIComponent(slug)}`, {
      headers: { 'Accept-Language': locale },
    })
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) return null
    if (error instanceof TypeError || error instanceof ApiError && error.code === 'invalid_response') return null
    throw error
  }
}

export function adminPath(token: string, suffix = ''): string {
  const cleanSuffix = suffix.replace(/^\/+/, '')
  return `/${encodeURIComponent(token)}/api/admin${cleanSuffix ? `/${cleanSuffix}` : ''}`
}

export interface BootstrapResponse {
  needsSetup: boolean
  csrfToken: string
  authenticated: boolean
  maxUploadBytes: number
}

export interface AuthResponse {
  csrfToken: string
  authenticated: boolean
}

export const adminApi = {
  bootstrap(token: string) {
    return request<BootstrapResponse>(adminPath(token, 'bootstrap'))
  },
  setup(token: string, passphrase: string, csrfToken: string) {
    return request<AuthResponse>(adminPath(token, 'setup'), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ passphrase }),
    })
  },
  login(token: string, passphrase: string, csrfToken: string) {
    return request<AuthResponse>(adminPath(token, 'login'), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ passphrase }),
    })
  },
  logout(token: string, csrfToken: string) {
    return request<void>(adminPath(token, 'logout'), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({}),
    })
  },
  getProfile(token: string) {
    return request<ProfileEditorData>(adminPath(token, 'profile'))
  },
  saveProfile(token: string, data: ProfileEditorData, csrfToken: string) {
    return request<ProfileEditorData>(adminPath(token, 'profile'), {
      method: 'PUT',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify(data),
    })
  },
  listProjects(token: string) {
    return request<ProjectEditorData[]>(adminPath(token, 'projects'))
  },
  createProject(token: string, data: ProjectEditorData, csrfToken: string) {
    return request<ProjectEditorData>(adminPath(token, 'projects'), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify(data),
    })
  },
  saveProject(token: string, data: ProjectEditorData, csrfToken: string) {
    return request<ProjectEditorData>(adminPath(token, `projects/${encodeURIComponent(data.id ?? data.slug)}`), {
      method: 'PUT',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify(data),
    })
  },
  deleteProject(token: string, slug: string, csrfToken: string) {
    return request<void>(adminPath(token, `projects/${encodeURIComponent(slug)}`), {
      method: 'DELETE',
      headers: { 'X-CSRF-Token': csrfToken },
    })
  },
  reorderProjects(token: string, ids: string[], csrfToken: string) {
    return request<void>(adminPath(token, 'projects/reorder'), {
      method: 'PUT',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ ids }),
    })
  },
  listMedia(token: string) {
    return request<MediaItem[]>(adminPath(token, 'media'))
  },
  listAudit(token: string) {
    return request<AuditEntry[]>(adminPath(token, 'audit'))
  },
  startUpload(token: string, file: File, csrfToken: string) {
    return request<{ uploadId: string; receivedBytes: number }>(adminPath(token, 'uploads/init'), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ filename: file.name, mimeType: file.type, totalBytes: file.size }),
    })
  },
  uploadStatus(token: string, uploadId: string) {
    return request<{ receivedBytes: number; totalBytes: number }>(adminPath(token, `uploads/${encodeURIComponent(uploadId)}`))
  },
  uploadChunk(token: string, uploadId: string, csrfToken: string, bytes: Blob, start: number, end: number, total: number) {
    return request<{ receivedBytes: number }>(adminPath(token, `uploads/${encodeURIComponent(uploadId)}`), {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-CSRF-Token': csrfToken,
        'Content-Range': `bytes ${start}-${end - 1}/${total}`,
      },
      body: bytes,
    })
  },
  finishUpload(token: string, uploadId: string, csrfToken: string) {
    return request<MediaItem>(adminPath(token, `uploads/${encodeURIComponent(uploadId)}/complete`), {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({}),
    })
  },
}
