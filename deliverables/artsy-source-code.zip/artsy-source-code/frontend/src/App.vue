<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import HotbarNav from './components/HotbarNav.vue'

const route = useRoute()
const { t } = useI18n()
const isAdmin = computed(() => route.meta.admin === true)
</script>

<template>
  <div
    class="site-frame"
    :class="{ 'is-admin-frame': isAdmin }"
  >
    <a
      v-if="!isAdmin"
      class="skip-link"
      href="#main"
    >{{ t('nav.skip') }}</a>
    <HotbarNav v-if="!isAdmin" />
    <main
      id="main"
      class="site-main"
    >
      <RouterView v-slot="{ Component, route: currentRoute }">
        <Transition
          name="page"
          mode="out-in"
        >
          <component
            :is="Component"
            :key="currentRoute.path"
          />
        </Transition>
      </RouterView>
    </main>
    <footer
      v-if="!isAdmin"
      class="site-footer"
    >
      <span class="footer-mark">{{ t('footer.name') }} <span aria-hidden="true">/</span> {{ t('footer.rights') }}</span>
      <a
        href="https://www.fiverr.com/nolohc/"
        target="_blank"
        rel="noreferrer"
        :aria-label="t('about.source')"
      >
        <span>{{ t('about.source') }}</span><span
          class="accent-block"
          aria-hidden="true"
        />
      </a>
    </footer>
  </div>
</template>
