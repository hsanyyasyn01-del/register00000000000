import type { Locale } from '../i18n/language'
import type { Profile } from '../types'

// Used only when Vite is opened without the Rust API. The production API reads the same facts from the SQL seed.
export const previewProfile: Profile = {
  contactUrl: 'https://www.fiverr.com/nolohc/',
  translations: {
    en: {
      displayName: 'Artsy',
      handle: '@nolohc',
      tagline: 'Video editor for YouTube Shorts and short-form work.',
      country: 'Egypt',
      spokenLanguages: ['English', 'Spanish', 'Arabic'],
      bio: 'I edit short videos for YouTube Shorts, Reels, TikTok, reaction videos, and other YouTube content. I work from raw footage and handle pacing, captions, sound, and cuts.',
      services: ['YouTube Shorts editing', 'Reels editing', 'TikTok editing', 'Reaction videos'],
      skills: ['Video editing', 'Short-form editing', 'YouTube video creation', 'Social media video editing'],
    },
    ar: {
      displayName: 'آرتسي',
      handle: '@nolohc',
      tagline: 'مونتاج فيديوهات YouTube Shorts والمقاطع القصيرة.',
      country: 'مصر',
      spokenLanguages: ['الإنجليزية', 'الإسبانية', 'العربية'],
      bio: 'أحرر فيديوهات قصيرة لـ YouTube Shorts وReels وTikTok ومقاطع ردود الفعل وغيرها من محتوى YouTube. أعمل انطلاقاً من اللقطات الخام، مع ضبط الإيقاع والعناوين والصوت والقص.',
      services: ['مونتاج YouTube Shorts', 'مونتاج Reels', 'مونتاج TikTok', 'مقاطع ردود الفعل'],
      skills: ['مونتاج الفيديو', 'مونتاج الفيديوهات القصيرة', 'إنشاء فيديوهات YouTube', 'مونتاج فيديوهات التواصل الاجتماعي'],
    },
    fr: {
      displayName: 'Artsy',
      handle: '@nolohc',
      tagline: 'Montage de YouTube Shorts et de vidéos courtes.',
      country: 'Égypte',
      spokenLanguages: ['Anglais', 'Espagnol', 'Arabe'],
      bio: 'Je monte des vidéos courtes pour YouTube Shorts, Reels, TikTok, les vidéos de réaction et d’autres contenus YouTube. À partir de rushes, je travaille le rythme, les sous-titres, le son et les coupes.',
      services: ['Montage YouTube Shorts', 'Montage Reels', 'Montage TikTok', 'Vidéos de réaction'],
      skills: ['Montage vidéo', 'Montage de formats courts', 'Création vidéo YouTube', 'Montage vidéo pour les réseaux sociaux'],
    },
  },
}

export function profileTranslation(profile: Profile, locale: Locale) {
  return profile.translations[locale] ?? profile.translations.en
}
