import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import WorkView from '../views/WorkView.vue'
import AboutView from '../views/AboutView.vue'
import ContactView from '../views/ContactView.vue'
import ProjectView from '../views/ProjectView.vue'
import AdminView from '../views/AdminView.vue'
import NotFoundView from '../views/NotFoundView.vue'
import { i18n } from '../i18n'

export const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'home', component: HomeView },
    { path: '/work', name: 'work', component: WorkView },
    { path: '/about', name: 'about', component: AboutView },
    { path: '/contact', name: 'contact', component: ContactView },
    { path: '/project/:slug', name: 'project', component: ProjectView },
    { path: '/:token([A-Za-z0-9_-]{43})', name: 'admin', component: AdminView, meta: { admin: true } },
    { path: '/:pathMatch(.*)*', name: 'not-found', component: NotFoundView },
  ],
  scrollBehavior(to) {
    if (to.hash) return { el: to.hash, top: 24, behavior: 'auto' }
    return { top: 0, behavior: 'auto' }
  },
})

router.afterEach((to) => {
  const titleKey = to.name === 'not-found' ? 'notFound' : String(to.name)
  document.title = i18n.global.t(`seo.${titleKey}`)
  document.querySelector('meta[name="description"]')?.setAttribute('content', i18n.global.t('seo.description'))

  const existingRobots = document.querySelector('meta[name="robots"][data-admin-route]')
  if (to.meta.admin) {
    const robots = existingRobots ?? document.createElement('meta')
    robots.setAttribute('name', 'robots')
    robots.setAttribute('content', 'noindex, nofollow, noarchive, nosnippet')
    robots.setAttribute('data-admin-route', '')
    if (!existingRobots) document.head.append(robots)
  } else {
    existingRobots?.remove()
  }
})
