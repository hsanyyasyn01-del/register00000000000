import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getProfile, getProjects } from '../services/api'
import { locale } from '../i18n'
import type { Profile, Project } from '../types'

export const usePortfolioStore = defineStore('portfolio', () => {
  const profile = ref<Profile | null>(null)
  const projects = ref<Project[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)
  let loaded = false

  async function load(force = false) {
    if (loaded && !force) return
    loading.value = true
    error.value = null
    try {
      const [profileData, projectData] = await Promise.all([getProfile(locale), getProjects(locale)])
      profile.value = profileData
      projects.value = projectData
      loaded = true
    } catch (reason) {
      error.value = reason instanceof Error ? reason.message : 'request_failed'
    } finally {
      loading.value = false
    }
  }

  return { profile, projects, loading, error, load }
})
