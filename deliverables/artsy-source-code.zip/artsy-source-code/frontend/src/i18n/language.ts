export type Locale = 'en' | 'ar' | 'fr'

const supported = new Set<Locale>(['en', 'ar', 'fr'])

export function normalizeLocale(value: unknown): Locale {
  if (typeof value !== 'string') return 'en'
  const primary = value.trim().toLowerCase().split('-')[0]
  return supported.has(primary as Locale) ? (primary as Locale) : 'en'
}

export function isRtl(locale: Locale): boolean {
  return locale === 'ar'
}
