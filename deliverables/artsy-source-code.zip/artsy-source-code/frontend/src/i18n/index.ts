import { createI18n } from 'vue-i18n'
import en from '../locales/en.json'
import ar from '../locales/ar.json'
import fr from '../locales/fr.json'
import { normalizeLocale } from './language'

export const locale = normalizeLocale(document.documentElement.lang)

export const i18n = createI18n({
  legacy: false,
  locale,
  fallbackLocale: 'en',
  messages: { en, ar, fr },
  globalInjection: true,
  missingWarn: import.meta.env.DEV,
})
