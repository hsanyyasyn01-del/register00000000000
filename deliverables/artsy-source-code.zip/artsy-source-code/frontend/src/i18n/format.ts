import type { Locale } from './language'

function numberingSystem(locale: Locale): Intl.NumberFormatOptions['numberingSystem'] {
  return locale === 'ar' ? 'arab' : undefined
}

export function formatNumber(value: number, locale: Locale): string {
  return new Intl.NumberFormat(locale, { numberingSystem: numberingSystem(locale) }).format(value)
}

export function formatIndex(value: number, locale: Locale): string {
  return new Intl.NumberFormat(locale, {
    minimumIntegerDigits: 2,
    useGrouping: false,
    numberingSystem: numberingSystem(locale),
  }).format(value)
}
