<script setup lang="ts">
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { locale } from '../i18n'
import { formatIndex } from '../i18n/format'

const route = useRoute()
const { t } = useI18n()

function active(name: 'work' | 'about' | 'contact') {
  if (name === 'work') return route.path === '/work' || route.path.startsWith('/project/')
  return route.path === `/${name}`
}
</script>

<template>
  <nav
    class="hotbar"
    :aria-label="t('nav.work') + ' / ' + t('nav.about') + ' / ' + t('nav.contact')"
  >
    <RouterLink
      class="hotbar-slot"
      to="/work"
      :aria-current="active('work') ? 'page' : undefined"
    >
      <span class="slot-index">{{ formatIndex(1, locale) }}</span><span>{{ t('nav.work') }}</span>
    </RouterLink>
    <RouterLink
      class="hotbar-slot"
      to="/about"
      :aria-current="active('about') ? 'page' : undefined"
    >
      <span class="slot-index">{{ formatIndex(2, locale) }}</span><span>{{ t('nav.about') }}</span>
    </RouterLink>
    <RouterLink
      class="hotbar-slot"
      to="/contact"
      :aria-current="active('contact') ? 'page' : undefined"
    >
      <span class="slot-index">{{ formatIndex(3, locale) }}</span><span>{{ t('nav.contact') }}</span>
    </RouterLink>
  </nav>
</template>
