<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  name: 'play' | 'external' | 'mail' | 'arrow' | 'close' | 'check' | 'plus' | 'file' | 'move'
  label?: string
}>(), { label: '' })

const shapes: Record<typeof props.name, string> = {
  play: 'M4 2h3v2h3v2h2v2h2v2h-2v2h-2v2H7v2H4z',
  external: 'M8 1h7v7h-2V4.4L7 10.4 5.6 9 11.6 3H8z M2 3h5v2H4v7h7V9h2v5H2z',
  mail: 'M1 3h14v10H1z M3 5l5 4 5-4v1L8 10 3 6z',
  arrow: 'M1 7h10L7 3l1-1 7 6-7 6-1-1 4-4H1z',
  close: 'M2 1h3v3h2v2h2V4h2V1h3v3h-2v2h-2v2h2v2h2v3h-3v-2h-2V9H7v2H5v2H2v-3h2V8h2V6H4V4H2z',
  check: 'M1 8h3v3h2v-2h2V7h2V5h2V3h3v4h-2v2h-2v2h-2v2H6v2H3v-3H1z',
  plus: 'M6 1h4v5h5v4h-5v5H6v-5H1V6h5z',
  file: 'M3 1h7l4 4v10H3z M9 2v4h4 M5 8h7v1H5z M5 11h7v1H5z',
  move: 'M7 1h2v2h2V1h2v2h2v2h-2v2h-2V5H9v6h2V9h2v2h2v2h-2v2h-2v-2H9v2H7v-2H5v2H3v-2H1v-2h2V9h2v2h2V5H5v2H3V5H1V3h2V1h2v2h2z',
}

const path = computed(() => shapes[props.name])
</script>

<template>
  <svg
    class="pixel-icon"
    :class="`icon-${name}`"
    viewBox="0 0 16 16"
    aria-hidden="true"
    focusable="false"
    shape-rendering="crispEdges"
  >
    <path
      :d="path"
      fill="currentColor"
    />
  </svg>
</template>
