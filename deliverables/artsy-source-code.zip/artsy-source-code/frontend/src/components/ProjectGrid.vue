<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import PixelIcon from './PixelIcon.vue'
import { locale } from '../i18n'
import { formatIndex, formatNumber } from '../i18n/format'
import type { Project } from '../types'

defineProps<{ projects: Project[] }>()
const { t } = useI18n()
</script>

<template>
  <div
    v-if="projects.length"
    class="project-grid"
  >
    <article
      v-for="project in projects"
      :key="project.id || project.slug"
      class="project-card"
    >
      <RouterLink
        class="project-link"
        :to="`/project/${encodeURIComponent(project.slug)}`"
        :aria-label="`${t('work.openProject')}: ${project.title}`"
      >
        <div class="project-poster">
          <img
            v-if="project.posterUrl"
            :src="project.posterUrl"
            :alt="project.title"
            loading="lazy"
            decoding="async"
          >
          <div
            v-else
            class="poster-empty"
            aria-hidden="true"
          >
            <span class="poster-index">{{ formatIndex(project.sortOrder + 1, locale) }}</span>
            <PixelIcon name="play" />
          </div>
          <span
            class="poster-corner"
            aria-hidden="true"
          />
        </div>
        <div class="project-card-copy">
          <div class="project-card-heading">
            <h3>{{ project.title }}</h3>
            <span
              v-if="project.year"
              class="project-year"
            >{{ formatNumber(project.year, locale) }}</span>
          </div>
          <p
            v-if="project.description"
            class="project-summary"
          >
            {{ project.description }}
          </p>
          <ul
            v-if="project.tools.length"
            class="tool-list"
            :aria-label="t('work.tools')"
          >
            <li
              v-for="tool in project.tools"
              :key="tool"
            >
              {{ tool }}
            </li>
          </ul>
          <span class="card-open"><span>{{ t('work.openProject') }}</span><PixelIcon name="arrow" /></span>
        </div>
      </RouterLink>
    </article>
  </div>
  <div
    v-else
    class="work-empty"
    role="status"
  >
    <span
      class="empty-index"
      aria-hidden="true"
    >{{ formatIndex(0, locale) }}</span>
    <div>
      <p class="empty-title">
        {{ t('work.empty') }}
      </p>
      <p class="empty-copy">
        {{ t('work.emptyDetail') }}
      </p>
    </div>
  </div>
</template>
