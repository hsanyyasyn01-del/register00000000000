<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import PixelIcon from '../components/PixelIcon.vue'
import { locale } from '../i18n'
import { formatNumber } from '../i18n/format'
const { t } = useI18n()
</script>

<template>
  <div class="page-wrap inner-page not-found-page">
    <p class="section-eyebrow">
      {{ formatNumber(404, locale) + ' / ' + t('common.notFoundLabel') }}
    </p>
    <h1 class="pixel-heading page-title">
      {{ t('project.notFound') }}
    </h1>
    <RouterLink
      class="text-link"
      to="/"
    >
      <span>{{ t('nav.work') }}</span><PixelIcon name="arrow" />
    </RouterLink>
  </div>
</template>
