<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { ApiError, adminApi } from '../services/api'
import type { AuditEntry, MediaItem, ProfileEditorData, ProjectEditorData } from '../types'
import type { Locale } from '../i18n/language'
import { locale } from '../i18n'
import { formatNumber } from '../i18n/format'
import PixelIcon from '../components/PixelIcon.vue'
import '../assets/admin.css'

const route = useRoute()
const { t } = useI18n()
const token = computed(() => String(route.params.token ?? ''))
const locales: Locale[] = ['en', 'ar', 'fr']
const localeNames: Record<Locale, string> = { en: 'EN', ar: 'AR', fr: 'FR' }
const sectionKeys = ['profile', 'projects', 'media', 'translations', 'settings'] as const
type Section = typeof sectionKeys[number]

const section = ref<Section>('profile')
const activeLocale = ref<Locale>('en')
const previewLocale = ref<Locale>('en')
const authReady = ref(false)
const needsSetup = ref(true)
const authenticated = ref(false)
const csrfToken = ref('')
const maxUploadBytes = ref(1024 * 1024 * 1024)
const passphrase = ref('')
const confirmPassphrase = ref('')
const busy = ref(false)
const busyText = ref('')
const notice = ref('')
const errorMessage = ref('')
const profileForm = ref<ProfileEditorData | null>(null)
const profileBaseline = ref('')
const projects = ref<ProjectEditorData[]>([])
const currentProject = ref<ProjectEditorData | null>(null)
const projectBaseline = ref('')
const media = ref<MediaItem[]>([])
const audit = ref<AuditEntry[]>([])
const uploaded = ref(0)
const uploadProgress = ref(0)
const uploadStatus = ref('')
const draggedId = ref('')
const selectedMediaId = ref('')
const previewVideo = ref<HTMLVideoElement | null>(null)
let autosaveTimer: number | undefined
let localDraftTimer: number | undefined

const profileDirty = computed(() => Boolean(profileForm.value && profileBaseline.value && JSON.stringify(profileForm.value) !== profileBaseline.value))
const projectDirty = computed(() => Boolean(currentProject.value && projectBaseline.value && JSON.stringify(currentProject.value) !== projectBaseline.value))
const hasUnsavedChanges = computed(() => profileDirty.value || projectDirty.value)
const activeTranslation = computed(() => profileForm.value?.translations[activeLocale.value])
const profileCompleteness = computed(() => {
  const value = profileForm.value?.translations[activeLocale.value]
  if (!value) return 0
  const fields = [value.displayName, value.handle, value.tagline, value.bio, value.country, value.spokenLanguages.length ? 'yes' : '', value.services.length ? 'yes' : '', value.skills.length ? 'yes' : '']
  return Math.round(fields.filter(item => item.trim().length > 0).length / fields.length * 100)
})
const projectTranslation = computed(() => currentProject.value?.translations[activeLocale.value])
const previewTranslation = computed(() => profileForm.value?.translations[previewLocale.value])
const previewProjectTranslation = computed(() => currentProject.value?.translations[previewLocale.value])
const previewDirection = computed(() => previewLocale.value === 'ar' ? 'rtl' : 'ltr')
const isNewProject = computed(() => !currentProject.value?.id)

const servicesText = computed({
  get: () => activeTranslation.value?.services.join('\n') ?? '',
  set: (value: string) => { if (activeTranslation.value) activeTranslation.value.services = value.split('\n').map(item => item.trim()).filter(Boolean) },
})
const skillsText = computed({
  get: () => activeTranslation.value?.skills.join('\n') ?? '',
  set: (value: string) => { if (activeTranslation.value) activeTranslation.value.skills = value.split('\n').map(item => item.trim()).filter(Boolean) },
})
const spokenLanguagesText = computed({
  get: () => activeTranslation.value?.spokenLanguages.join(', ') ?? '',
  set: (value: string) => { if (activeTranslation.value) activeTranslation.value.spokenLanguages = value.split(',').map(item => item.trim()).filter(Boolean) },
})
const toolsText = computed({
  get: () => projectTranslation.value?.tools.join(', ') ?? '',
  set: (value: string) => { if (projectTranslation.value) projectTranslation.value.tools = value.split(',').map(item => item.trim()).filter(Boolean) },
})
const creditsText = computed({
  get: () => projectTranslation.value?.credits.join(', ') ?? '',
  set: (value: string) => { if (projectTranslation.value) projectTranslation.value.credits = value.split(',').map(item => item.trim()).filter(Boolean) },
})
const tagsText = computed({
  get: () => projectTranslation.value?.tags.join(', ') ?? '',
  set: (value: string) => { if (projectTranslation.value) projectTranslation.value.tags = value.split(',').map(item => item.trim()).filter(Boolean) },
})

function makeEmptyProject(sortOrder: number): ProjectEditorData {
  const emptyTranslation = () => ({ title: '', description: '', tools: [], credits: [], tags: [] })
  const translations: ProjectEditorData['translations'] = {
    en: emptyTranslation(),
    ar: emptyTranslation(),
    fr: emptyTranslation(),
  }
  return {
    slug: '', year: null, status: 'draft', sortOrder,
    videoMediaId: null, posterMediaId: null, externalUrl: null, translations,
  }
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

function setError(reason: unknown) {
  if (reason instanceof ApiError && reason.status === 403) {
    errorMessage.value = t('admin.csrfError')
    authenticated.value = false
    return
  }
  if (reason instanceof ApiError && reason.status === 401) {
    errorMessage.value = t('admin.wrongPassphrase')
    return
  }
  if (reason instanceof ApiError && reason.status === 422) {
    errorMessage.value = t('admin.validationError')
    return
  }
  if (reason instanceof ApiError && reason.status === 429) {
    errorMessage.value = t('admin.rateLimited')
    return
  }
  if (reason instanceof ApiError && reason.status === 409) {
    errorMessage.value = t('admin.conflict')
    return
  }
  errorMessage.value = t('common.error')
}

async function bootstrap() {
  authReady.value = false
  errorMessage.value = ''
  try {
    const state = await adminApi.bootstrap(token.value)
    csrfToken.value = state.csrfToken
    needsSetup.value = state.needsSetup
    authenticated.value = state.authenticated
    maxUploadBytes.value = state.maxUploadBytes
    if (state.authenticated) await loadEditor()
  } catch (reason) {
    setError(reason)
  } finally {
    authReady.value = true
  }
}

async function submitAuth() {
  errorMessage.value = ''
  notice.value = ''
  if (needsSetup.value && passphrase.value !== confirmPassphrase.value) {
    errorMessage.value = t('admin.passphraseMismatch')
    return
  }
  busy.value = true
  try {
    const result = needsSetup.value
      ? await adminApi.setup(token.value, passphrase.value, csrfToken.value)
      : await adminApi.login(token.value, passphrase.value, csrfToken.value)
    csrfToken.value = result.csrfToken
    authenticated.value = result.authenticated
    passphrase.value = ''
    confirmPassphrase.value = ''
    await loadEditor()
  } catch (reason) {
    setError(reason)
    if (reason instanceof ApiError && reason.status === 403) await bootstrap()
  } finally {
    busy.value = false
  }
}

async function loadEditor() {
  const [profileData, projectData, mediaData, auditData] = await Promise.all([
    adminApi.getProfile(token.value),
    adminApi.listProjects(token.value),
    adminApi.listMedia(token.value),
    adminApi.listAudit(token.value),
  ])
  profileForm.value = clone(profileData)
  profileBaseline.value = JSON.stringify(profileForm.value)
  projects.value = projectData.sort((a, b) => a.sortOrder - b.sortOrder)
  media.value = mediaData
  audit.value = auditData
  if (currentProject.value?.id) {
    const updated = projects.value.find(item => item.id === currentProject.value?.id)
    if (updated) openProject(updated, false)
  }
}

async function logout() {
  try {
    await adminApi.logout(token.value, csrfToken.value)
  } finally {
    authenticated.value = false
    profileForm.value = null
    projects.value = []
    csrfToken.value = ''
    await bootstrap()
  }
}

async function saveProfile() {
  if (!profileForm.value) return
  busy.value = true
  busyText.value = t('admin.saving')
  errorMessage.value = ''
  try {
    const saved = await adminApi.saveProfile(token.value, profileForm.value, csrfToken.value)
    profileForm.value = clone(saved)
    profileBaseline.value = JSON.stringify(profileForm.value)
    notice.value = t('admin.profileSaved')
  } catch (reason) {
    setError(reason)
  } finally {
    busy.value = false
    busyText.value = ''
  }
}

function openProject(project: ProjectEditorData, restoreDraft = true) {
  currentProject.value = clone(project)
  projectBaseline.value = JSON.stringify(currentProject.value)
  if (restoreDraft && project.id) {
    try {
      const saved = localStorage.getItem(`artsy-draft:${token.value}:${project.id}`)
      if (saved) {
        const draft = JSON.parse(saved) as ProjectEditorData
        if (draft.id === project.id) currentProject.value = draft
      }
    } catch { /* Ignore damaged local draft data. */ }
  }
}

function newProject() {
  currentProject.value = makeEmptyProject(projects.value.length)
  projectBaseline.value = JSON.stringify(currentProject.value)
  section.value = 'projects'
  notice.value = ''
}

async function saveProject(autosave = false) {
  if (!currentProject.value || !csrfToken.value) return
  const data = clone(currentProject.value)
  if (!data.slug.trim()) {
    if (!autosave) errorMessage.value = t('admin.required')
    return
  }
  if (busy.value && !autosave) return
  if (!autosave) {
    busy.value = true
    busyText.value = t('admin.saving')
  }
  errorMessage.value = ''
  try {
    const saved = data.id
      ? await adminApi.saveProject(token.value, data, csrfToken.value)
      : await adminApi.createProject(token.value, data, csrfToken.value)
    const existing = projects.value.findIndex(item => item.id === saved.id)
    if (existing >= 0) projects.value.splice(existing, 1, saved)
    else projects.value.push(saved)
    projects.value.sort((a, b) => a.sortOrder - b.sortOrder)
    currentProject.value = clone(saved)
    projectBaseline.value = JSON.stringify(currentProject.value)
    localStorage.removeItem(`artsy-draft:${token.value}:${saved.id}`)
    if (!autosave) notice.value = t('admin.projectSaved')
    await refreshAudit()
  } catch (reason) {
    if (!autosave) setError(reason)
  } finally {
    if (!autosave) {
      busy.value = false
      busyText.value = ''
    }
  }
}

async function deleteCurrentProject() {
  if (!currentProject.value?.id) return
  if (!window.confirm(t('admin.deleteProject') + '?')) return
  busy.value = true
  try {
    await adminApi.deleteProject(token.value, currentProject.value.id, csrfToken.value)
    localStorage.removeItem(`artsy-draft:${token.value}:${currentProject.value.id}`)
    projects.value = projects.value.filter(project => project.id !== currentProject.value?.id)
    currentProject.value = null
    projectBaseline.value = ''
    await refreshAudit()
  } catch (reason) {
    setError(reason)
  } finally {
    busy.value = false
  }
}

function moveProject(index: number, delta: number) {
  const target = index + delta
  if (target < 0 || target >= projects.value.length) return
  const next = [...projects.value]
  const [item] = next.splice(index, 1)
  next.splice(target, 0, item)
  next.forEach((project, sortOrder) => { project.sortOrder = sortOrder })
  projects.value = next
  void reorderProjects()
}

function onDragStart(project: ProjectEditorData) {
  draggedId.value = project.id ?? ''
}

function onDrop(project: ProjectEditorData) {
  if (!draggedId.value || !project.id || draggedId.value === project.id) return
  const from = projects.value.findIndex(item => item.id === draggedId.value)
  const to = projects.value.findIndex(item => item.id === project.id)
  if (from < 0 || to < 0) return
  const next = [...projects.value]
  const [item] = next.splice(from, 1)
  next.splice(to, 0, item)
  next.forEach((entry, index) => { entry.sortOrder = index })
  projects.value = next
  draggedId.value = ''
  void reorderProjects()
}

async function reorderProjects() {
  try {
    await adminApi.reorderProjects(token.value, projects.value.flatMap(item => item.id ? [item.id] : []), csrfToken.value)
  } catch (reason) {
    setError(reason)
  }
}

async function refreshAudit() {
  try { audit.value = await adminApi.listAudit(token.value) } catch { /* Audit panel can refresh later. */ }
}

function fileMime(file: File) {
  if (file.type) return file.type
  const extension = file.name.split('.').pop()?.toLowerCase()
  const types: Record<string, string> = {
    mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime',
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
  }
  return types[extension ?? ''] ?? 'application/octet-stream'
}

async function uploadFile(file: File) {
  if (file.size > maxUploadBytes.value) {
    errorMessage.value = `${t('admin.sizeLimit')}: ${formatBytes(maxUploadBytes.value)}`
    return
  }
  busy.value = true
  errorMessage.value = ''
  uploadProgress.value = 0
  uploadStatus.value = t('admin.uploading')
  try {
    const normalized = file.type ? file : new File([file], file.name, { type: fileMime(file) })
    const key = `artsy-upload:${token.value}:${file.name}:${file.size}:${file.lastModified}`
    let uploadId = localStorage.getItem(key)
    let receivedBytes = 0
    if (uploadId) {
      try { receivedBytes = (await adminApi.uploadStatus(token.value, uploadId)).receivedBytes }
      catch { uploadId = null }
    }
    if (!uploadId) {
      const started = await adminApi.startUpload(token.value, normalized, csrfToken.value)
      uploadId = started.uploadId
      receivedBytes = started.receivedBytes
      localStorage.setItem(key, uploadId)
    }
    const chunkSize = 4 * 1024 * 1024
    while (receivedBytes < file.size) {
      const end = Math.min(receivedBytes + chunkSize, file.size)
      await adminApi.uploadChunk(token.value, uploadId, csrfToken.value, file.slice(receivedBytes, end), receivedBytes, end, file.size)
      receivedBytes = end
      uploadProgress.value = Math.round(receivedBytes / file.size * 100)
    }
    const mediaItem = await adminApi.finishUpload(token.value, uploadId, csrfToken.value)
    localStorage.removeItem(key)
    media.value.unshift(mediaItem)
    uploaded.value += 1
    selectedMediaId.value = mediaItem.id
    if (currentProject.value) {
      if (mediaItem.mimeType.startsWith('video/')) currentProject.value.videoMediaId = mediaItem.id
      else currentProject.value.posterMediaId = mediaItem.id
    }
    uploadStatus.value = t('admin.uploadDone')
    notice.value = t('admin.uploadDone')
    await refreshAudit()
  } catch (reason) {
    setError(reason)
    uploadStatus.value = t('admin.uploadFailed')
  } finally {
    busy.value = false
  }
}

async function onFileChange(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (file) await uploadFile(file)
  input.value = ''
}

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${formatNumber(Math.ceil(bytes / 1024), locale)} KB`
  return `${new Intl.NumberFormat(locale, { minimumFractionDigits: 1, maximumFractionDigits: 1, numberingSystem: locale === 'ar' ? 'arab' : undefined }).format(bytes / 1024 / 1024)} MB`
}

function translationCompleteness(lang: Locale) {
  const value = profileForm.value?.translations[lang]
  if (!value) return 0
  const fields = [value.displayName, value.handle, value.tagline, value.bio, value.country, value.spokenLanguages.length ? 'yes' : '', value.services.length ? 'yes' : '', value.skills.length ? 'yes' : '']
  return Math.round(fields.filter(item => item.trim().length > 0).length / fields.length * 100)
}

function selectVideo(mediaId: string) {
  selectedMediaId.value = mediaId
  if (currentProject.value && media.value.find(item => item.id === mediaId)?.mimeType.startsWith('video/')) {
    currentProject.value.videoMediaId = mediaId
  }
}

function selectPoster(mediaId: string) {
  selectedMediaId.value = mediaId
  if (currentProject.value && media.value.find(item => item.id === mediaId)?.mimeType.startsWith('image/')) {
    currentProject.value.posterMediaId = mediaId
  }
}

async function captureFrame() {
  const video = previewVideo.value
  if (!video || video.readyState < 2) return
  const canvas = document.createElement('canvas')
  canvas.width = video.videoWidth
  canvas.height = video.videoHeight
  const context = canvas.getContext('2d')
  if (!context) return
  context.drawImage(video, 0, 0, canvas.width, canvas.height)
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.9))
  if (!blob) return
  await uploadFile(new File([blob], `poster-${Date.now()}.jpg`, { type: 'image/jpeg' }))
}

async function saveActiveSection() {
  if (section.value === 'profile') await saveProfile()
  else if (section.value === 'projects' && currentProject.value) await saveProject()
}

async function publishCurrent() {
  if (!currentProject.value) return
  currentProject.value.status = 'published'
  await saveProject()
}

function onShortcut(event: KeyboardEvent) {
  const isMac = navigator.platform.toLowerCase().includes('mac')
  const modifier = isMac ? event.metaKey : event.ctrlKey
  if (!modifier) return
  if (event.key.toLowerCase() === 's') {
    event.preventDefault()
    void saveActiveSection()
  }
  if (event.key.toLowerCase() === 'p' && event.shiftKey) {
    event.preventDefault()
    void publishCurrent()
  }
}

function beforeUnload(event: BeforeUnloadEvent) {
  if (!hasUnsavedChanges.value) return
  event.preventDefault()
  event.returnValue = t('admin.confirmLeave')
}

watch(currentProject, (value) => {
  if (!value || !authenticated.value) return
  if (localDraftTimer) window.clearTimeout(localDraftTimer)
  localDraftTimer = window.setTimeout(() => {
    if (value.id) localStorage.setItem(`artsy-draft:${token.value}:${value.id}`, JSON.stringify(value))
  }, 350)
  if (autosaveTimer) window.clearTimeout(autosaveTimer)
  if (value.id && value.status === 'draft') {
    autosaveTimer = window.setTimeout(() => {
      if (projectDirty.value) void saveProject(true)
    }, 1600)
  }
}, { deep: true })

watch(section, (value) => {
  notice.value = ''
  if (value === 'media') void adminApi.listMedia(token.value).then(items => { media.value = items }).catch(setError)
  if (value === 'settings') void refreshAudit()
})

onMounted(() => {
  void bootstrap()
  window.addEventListener('keydown', onShortcut)
  window.addEventListener('beforeunload', beforeUnload)
})
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onShortcut)
  window.removeEventListener('beforeunload', beforeUnload)
  if (autosaveTimer) window.clearTimeout(autosaveTimer)
  if (localDraftTimer) window.clearTimeout(localDraftTimer)
})
</script>

<template>
  <div
    class="admin-shell"
    :dir="locale === 'ar' ? 'rtl' : 'ltr'"
  >
    <header class="admin-topbar">
      <RouterLink
        class="admin-wordmark"
        to="/"
        tabindex="-1"
        aria-hidden="true"
      >
        A<span>/</span>R
      </RouterLink>
      <div class="admin-top-title">
        <p class="admin-micro-label">
          {{ t('admin.subtitle') }}
        </p>
        <h1>{{ t('admin.title') }}</h1>
      </div>
      <div class="admin-top-actions">
        <span
          v-if="authenticated"
          class="admin-status"
        ><span
          class="status-pixel"
          aria-hidden="true"
        />{{ t('admin.statusReady') }}</span>
        <button
          v-if="authenticated"
          class="admin-quiet-button"
          type="button"
          @click="logout"
        >
          {{ t('admin.logout') }}
        </button>
      </div>
    </header>

    <div
      v-if="!authReady"
      class="admin-auth-wrap"
      role="status"
    >
      <div
        class="segmented-loader"
        aria-hidden="true"
      >
        <i /><i /><i /><i />
      </div><p>{{ t('common.loading') }}</p>
    </div>

    <section
      v-else-if="!authenticated"
      class="admin-auth-wrap"
    >
      <div class="admin-auth-card">
        <p class="admin-micro-label">
          ARTSY / ADMIN
        </p>
        <h2>{{ needsSetup ? t('admin.setupTitle') : t('admin.loginTitle') }}</h2>
        <p class="admin-auth-hint">
          {{ needsSetup ? t('admin.setupHint') : t('admin.loginHint') }}
        </p>
        <form
          class="admin-auth-form"
          @submit.prevent="submitAuth"
        >
          <label class="admin-field"><span>{{ t('admin.passphrase') }}</span><input
            v-model="passphrase"
            type="password"
            autocomplete="current-password"
            minlength="12"
            maxlength="128"
            required
          ></label>
          <label
            v-if="needsSetup"
            class="admin-field"
          ><span>{{ t('admin.confirmPassphrase') }}</span><input
            v-model="confirmPassphrase"
            type="password"
            autocomplete="new-password"
            minlength="12"
            maxlength="128"
            required
          ></label>
          <button
            class="admin-primary-button"
            type="submit"
            :disabled="busy || passphrase.length < 12"
          >
            {{ needsSetup ? t('admin.setup') : t('admin.login') }}<PixelIcon name="arrow" />
          </button>
        </form>
        <p
          v-if="errorMessage"
          class="admin-error"
          role="alert"
        >
          {{ errorMessage }}
        </p>
        <p class="admin-auth-foot">
          {{ t('admin.rotateNote') }}
        </p>
      </div>
    </section>

    <div
      v-else
      class="admin-workspace"
    >
      <aside
        class="admin-sidebar"
        :aria-label="t('admin.title')"
      >
        <p class="admin-micro-label">
          ARTSY / CONTROL
        </p>
        <nav class="admin-side-nav">
          <button
            v-for="item in sectionKeys"
            :key="item"
            type="button"
            :class="['admin-nav-button', { active: section === item }]"
            :aria-current="section === item ? 'page' : undefined"
            @click="section = item"
          >
            <span
              class="nav-marker"
              aria-hidden="true"
            /><span>{{ t(`admin.sections.${item}`) }}</span><span
              v-if="item === 'profile'"
              class="nav-completeness"
            >{{ formatNumber(profileCompleteness, locale) }}%</span>
          </button>
        </nav>
        <div class="sidebar-foot">
          <span class="sidebar-foot-label">{{ t('admin.language') }}</span><span class="sidebar-locale">{{ localeNames[activeLocale] }}</span>
        </div>
      </aside>

      <main class="admin-editor">
        <div class="editor-toolbar">
          <div>
            <p class="admin-micro-label">
              {{ t(`admin.sections.${section}`) }}
            </p><span
              v-if="hasUnsavedChanges"
              class="dirty-flag"
            ><span class="dirty-dot" />{{ t('admin.unsaved') }}</span><span
              v-else-if="notice"
              class="saved-flag"
            ><PixelIcon name="check" />{{ notice }}</span>
          </div>
          <button
            v-if="section === 'profile' || section === 'projects' && currentProject"
            class="admin-save-button"
            type="button"
            :disabled="busy || !hasUnsavedChanges"
            @click="saveActiveSection"
          >
            <span>{{ busy ? busyText : t('admin.save') }}</span><span class="save-key">⌘ / Ctrl S</span>
          </button>
        </div>
        <p
          v-if="errorMessage"
          class="admin-error editor-error"
          role="alert"
        >
          {{ errorMessage }}
        </p>

        <section
          v-if="section === 'profile' && profileForm"
          class="editor-section"
        >
          <div
            class="language-tabs"
            :aria-label="t('admin.language')"
          >
            <button
              v-for="lang in locales"
              :key="lang"
              type="button"
              :class="['language-tab', { selected: activeLocale === lang }]"
              :aria-pressed="activeLocale === lang"
              @click="activeLocale = lang"
            >
              {{ localeNames[lang] }}<span
                :class="['tab-complete', { complete: profileForm.translations[lang]?.bio && profileForm.translations[lang]?.tagline }]"
                :aria-label="profileForm.translations[lang]?.bio ? t('admin.complete') : t('admin.incomplete')"
              />
            </button>
          </div>
          <div class="form-grid profile-editor-grid">
            <label class="admin-field"><span>{{ t('admin.displayName') }}</span><input
              v-model="profileForm.translations[activeLocale].displayName"
              maxlength="120"
            ></label>
            <label class="admin-field"><span>{{ t('admin.handle') }}</span><input
              v-model="profileForm.translations[activeLocale].handle"
              maxlength="120"
              dir="auto"
            ></label>
            <label class="admin-field field-wide"><span>{{ t('admin.tagline') }}</span><input
              v-model="profileForm.translations[activeLocale].tagline"
              maxlength="220"
            ></label>
            <label class="admin-field field-wide"><span>{{ t('admin.bio') }}</span><textarea
              v-model="profileForm.translations[activeLocale].bio"
              rows="6"
              maxlength="3000"
            /></label>
            <label class="admin-field"><span>{{ t('admin.services') }}</span><textarea
              v-model="servicesText"
              rows="5"
            /></label>
            <label class="admin-field"><span>{{ t('admin.skills') }}</span><textarea
              v-model="skillsText"
              rows="5"
            /></label>
            <div class="field-group field-wide">
              <p class="admin-micro-label">
                {{ t('admin.complete') }} / {{ localeNames[activeLocale] }}
              </p>
              <progress
                class="completeness-track"
                :value="profileCompleteness"
                max="100"
                :aria-label="t('admin.complete')"
              >
                {{ formatNumber(profileCompleteness, locale) }}%
              </progress>
              <span class="completion-caption">{{ formatNumber(profileCompleteness, locale) }}% — {{ profileCompleteness === 100 ? t('admin.complete') : t('admin.incomplete') }}</span>
            </div>
            <label class="admin-field"><span>{{ t('admin.country') }}</span><input
              v-model="profileForm.translations[activeLocale].country"
              maxlength="120"
            ></label>
            <label class="admin-field"><span>{{ t('admin.publicLanguages') }}</span><input
              v-model="spokenLanguagesText"
              maxlength="500"
            ></label>
            <label class="admin-field field-wide"><span>{{ t('admin.contactUrl') }}</span><input
              v-model="profileForm.contactUrl"
              type="url"
              maxlength="500"
              dir="ltr"
            ></label>
          </div>
        </section>

        <section
          v-else-if="section === 'projects'"
          class="editor-section project-editor-section"
        >
          <div class="project-list-pane">
            <div class="project-list-head">
              <h2>{{ t('admin.projectList') }}</h2><button
                class="icon-action"
                type="button"
                :aria-label="t('admin.newProject')"
                @click="newProject"
              >
                <PixelIcon name="plus" />
              </button>
            </div>
            <p
              v-if="!projects.length"
              class="admin-empty-copy"
            >
              {{ t('admin.emptyProjects') }}
            </p>
            <div
              v-else
              class="admin-project-list"
            >
              <div
                v-for="(project, index) in projects"
                :key="project.id"
                class="admin-project-row"
                :class="{ selected: currentProject?.id === project.id }"
                draggable="true"
                @dragstart="onDragStart(project)"
                @dragover.prevent
                @drop="onDrop(project)"
              >
                <button
                  class="project-select"
                  type="button"
                  @click="openProject(project)"
                >
                  <span
                    class="project-state-mark"
                    :class="project.status"
                  /><span class="project-row-title">{{ project.translations.en.title || project.slug }}</span>
                </button>
                <div class="project-order-actions">
                  <button
                    type="button"
                    :aria-label="t('admin.moveUp')"
                    :disabled="index === 0"
                    @click="moveProject(index, -1)"
                  >
                    ↑
                  </button><button
                    type="button"
                    :aria-label="t('admin.moveDown')"
                    :disabled="index === projects.length - 1"
                    @click="moveProject(index, 1)"
                  >
                    ↓
                  </button>
                </div>
              </div>
            </div>
            <button
              class="admin-outline-button create-project-button"
              type="button"
              @click="newProject"
            >
              {{ t('admin.newProject') }}<PixelIcon name="plus" />
            </button>
          </div>

          <div
            v-if="currentProject"
            class="project-form-pane"
          >
            <div class="project-form-head">
              <h2>{{ isNewProject ? t('admin.newProject') : currentProject.translations[activeLocale]?.title || currentProject.slug }}</h2><button
                v-if="currentProject.id"
                class="admin-danger-button"
                type="button"
                @click="deleteCurrentProject"
              >
                {{ t('admin.deleteProject') }}
              </button>
            </div>
            <div
              class="language-tabs compact-tabs"
              :aria-label="t('admin.language')"
            >
              <button
                v-for="lang in locales"
                :key="lang"
                type="button"
                :class="['language-tab', { selected: activeLocale === lang }]"
                :aria-pressed="activeLocale === lang"
                @click="activeLocale = lang"
              >
                {{ localeNames[lang] }}
              </button>
            </div>
            <div class="form-grid">
              <label class="admin-field"><span>{{ t('admin.slug') }}</span><input
                v-model="currentProject.slug"
                maxlength="80"
                pattern="[a-z0-9]+(?:-[a-z0-9]+)*"
                required
                dir="ltr"
              ></label>
              <label class="admin-field"><span>{{ t('admin.year') }}</span><input
                v-model.number="currentProject.year"
                type="number"
                min="1900"
                max="2100"
              ></label>
              <label class="admin-field field-wide"><span>{{ t('admin.projectTitle') }}</span><input
                v-model="projectTranslation!.title"
                maxlength="180"
                required
              ></label>
              <label class="admin-field field-wide"><span>{{ t('admin.description') }}</span><textarea
                v-model="projectTranslation!.description"
                rows="5"
                maxlength="5000"
              /></label>
              <label class="admin-field"><span>{{ t('admin.tools') }}</span><input v-model="toolsText"></label>
              <label class="admin-field"><span>{{ t('admin.credits') }}</span><input v-model="creditsText"></label>
              <label class="admin-field field-wide"><span>{{ t('admin.tags') }}</span><input v-model="tagsText"><small class="admin-muted">{{ t('admin.tagsHint') }}</small></label>
              <label class="admin-field"><span>{{ t('admin.status') }}</span><select v-model="currentProject.status"><option value="draft">{{ t('admin.draft') }}</option><option value="published">{{ t('admin.published') }}</option></select></label>
              <label class="admin-field"><span>{{ t('admin.contactUrl') }}</span><input
                v-model="currentProject.externalUrl"
                type="url"
                maxlength="500"
                dir="ltr"
              ></label>
              <label class="admin-field"><span>{{ t('admin.video') }}</span><select
                :value="currentProject.videoMediaId ?? ''"
                @change="selectVideo(($event.target as HTMLSelectElement).value)"
              ><option value="">—</option><option
                v-for="item in media.filter(item => item.mimeType.startsWith('video/'))"
                :key="item.id"
                :value="item.id"
              >{{ item.filename }}</option></select></label>
              <label class="admin-field"><span>{{ t('admin.poster') }}</span><select
                :value="currentProject.posterMediaId ?? ''"
                @change="selectPoster(($event.target as HTMLSelectElement).value)"
              ><option value="">—</option><option
                v-for="item in media.filter(item => item.mimeType.startsWith('image/'))"
                :key="item.id"
                :value="item.id"
              >{{ item.filename }}</option></select></label>
            </div>
            <div class="editor-actions-row">
              <button
                class="admin-save-button"
                type="button"
                :disabled="busy || !projectDirty"
                @click="saveProject()"
              >
                {{ t('admin.save') }}
              </button><button
                v-if="currentProject.status !== 'published'"
                class="admin-publish-button"
                type="button"
                :disabled="busy"
                @click="publishCurrent"
              >
                {{ t('admin.published') }}<PixelIcon name="check" />
              </button>
            </div>
            <p class="shortcut-hint">
              {{ t('admin.shortcuts') }}
            </p>
          </div>
          <div
            v-else
            class="project-no-selection"
          >
            <PixelIcon name="file" /><p>{{ t('admin.emptyProjects') }}</p>
          </div>
        </section>

        <section
          v-else-if="section === 'media'"
          class="editor-section media-section"
        >
          <header class="media-intro">
            <div>
              <p class="admin-micro-label">
                {{ t('admin.sections.media') }}
              </p><h2>{{ t('admin.chooseVideo') }}</h2><p>{{ t('admin.uploadHint') }}</p>
            </div><span class="upload-cap">{{ t('admin.sizeLimit') }}<strong>{{ formatBytes(maxUploadBytes) }}</strong></span>
          </header>
          <label class="upload-dropzone"><input
            type="file"
            accept="video/mp4,video/webm,video/quicktime,image/png,image/jpeg,image/webp,.mp4,.webm,.mov,.png,.jpg,.jpeg,.webp"
            :disabled="busy"
            @change="onFileChange"
          ><span class="upload-icon"><PixelIcon name="file" /></span><span class="upload-label">{{ t('admin.chooseVideo') }}</span><span class="upload-note">{{ t('admin.uploadHint') }}</span></label>
          <div
            v-if="uploadStatus"
            class="upload-progress-block"
            role="status"
          >
            <div class="progress-label">
              <span>{{ uploadStatus }}</span><span>{{ formatNumber(uploadProgress, locale) }}%</span>
            </div><progress
              class="segmented-progress"
              :value="uploadProgress"
              max="100"
            >
              {{ formatNumber(uploadProgress, locale) }}%
            </progress>
          </div>
          <div class="media-list-head">
            <h2>{{ t('admin.sections.media') }}</h2><span>{{ formatNumber(media.length, locale) }}</span>
          </div>
          <p
            v-if="!media.length"
            class="admin-empty-copy"
          >
            {{ t('admin.noMedia') }}
          </p>
          <ul
            v-else
            class="media-list"
          >
            <li
              v-for="item in media"
              :key="item.id"
              :class="{ selected: selectedMediaId === item.id }"
            >
              <button
                type="button"
                @click="selectedMediaId = item.id"
              >
                <span
                  class="media-type-mark"
                  :class="item.mimeType.startsWith('video/') ? 'video' : 'image'"
                /><span class="media-name">{{ item.filename }}</span><span class="media-size">{{ formatBytes(item.sizeBytes) }}</span>
              </button><a
                class="media-open"
                :href="item.url"
                target="_blank"
                rel="noreferrer"
                :aria-label="t('common.external')"
              ><PixelIcon name="external" /></a>
            </li>
          </ul>
          <div
            v-if="currentProject"
            class="capture-panel"
          >
            <div>
              <p class="admin-micro-label">
                {{ t('admin.poster') }}
              </p><p>{{ t('admin.capturePoster') }}</p>
            </div>
            <video
              v-if="currentProject.videoMediaId"
              ref="previewVideo"
              controls
              preload="none"
              :src="media.find(item => item.id === currentProject?.videoMediaId)?.url"
              class="capture-video"
            />
            <button
              class="admin-outline-button"
              type="button"
              :disabled="!currentProject.videoMediaId"
              @click="captureFrame"
            >
              {{ t('admin.capturePoster') }}<PixelIcon name="play" />
            </button>
          </div>
        </section>

        <section
          v-else-if="section === 'translations' && profileForm"
          class="editor-section translation-section"
        >
          <header class="translation-intro">
            <p class="admin-micro-label">
              {{ t('admin.sections.translations') }}
            </p><h2>{{ t('admin.language') }}</h2><p>{{ t('admin.complete') }}: {{ locales.map(lang => localeNames[lang]).join(' / ') }}</p>
          </header>
          <div class="translation-cards">
            <button
              v-for="lang in locales"
              :key="lang"
              type="button"
              class="translation-card"
              @click="activeLocale = lang; section = 'profile'"
            >
              <span class="translation-card-code">{{ localeNames[lang] }}</span><span class="translation-card-name">{{ profileForm.translations[lang]?.displayName || '—' }}</span><progress
                class="translation-completeness"
                :value="translationCompleteness(lang)"
                max="100"
                :aria-label="`${localeNames[lang]} ${t('admin.complete')}`"
              >
                {{ formatNumber(translationCompleteness(lang), locale) }}%
              </progress><span class="translation-card-go">{{ t('admin.sections.profile') }}<PixelIcon name="arrow" /></span>
            </button>
          </div>
          <p class="admin-empty-copy">
            {{ t('admin.projectTitle') }} / {{ t('admin.description') }} — {{ t('admin.sections.projects') }}
          </p>
        </section>

        <section
          v-else-if="section === 'settings'"
          class="editor-section settings-section"
        >
          <div class="settings-block">
            <p class="admin-micro-label">
              {{ t('admin.sections.settings') }}
            </p><h2>{{ t('admin.sizeLimit') }}</h2><p>{{ formatBytes(maxUploadBytes) }}</p><p class="admin-muted">
              {{ t('admin.rotateNote') }}
            </p><code>cargo run --manifest-path backend/Cargo.toml -- admin-rotate</code>
          </div>
          <div class="settings-block audit-block">
            <div class="media-list-head">
              <h2>{{ t('admin.audit') }}</h2><button
                class="admin-quiet-button"
                type="button"
                @click="refreshAudit"
              >
                {{ t('admin.save') }}
              </button>
            </div><p
              v-if="!audit.length"
              class="admin-empty-copy"
            >
              {{ t('admin.noAudit') }}
            </p><ol
              v-else
              class="audit-list"
            >
              <li
                v-for="entry in audit"
                :key="entry.id"
              >
                <span class="audit-action">{{ entry.action }} / {{ entry.entityType }}</span><time :datetime="entry.createdAt">{{ new Intl.DateTimeFormat(locale, { dateStyle: 'short', timeStyle: 'short', numberingSystem: locale === 'ar' ? 'arab' : undefined }).format(new Date(entry.createdAt)) }}</time>
              </li>
            </ol>
          </div>
        </section>
      </main>

      <aside
        class="admin-preview"
        :dir="previewDirection"
        :aria-label="t('admin.previewLabel')"
      >
        <div class="preview-head">
          <div>
            <p class="admin-micro-label">
              {{ t('admin.preview') }}
            </p><h2>{{ previewTranslation?.displayName || 'Artsy' }}</h2>
          </div><label class="preview-language"><span>{{ t('admin.previewLanguage') }}</span><select v-model="previewLocale"><option
            v-for="lang in locales"
            :key="lang"
            :value="lang"
          >{{ localeNames[lang] }}</option></select></label>
        </div>
        <div class="preview-card">
          <p class="admin-micro-label">
            {{ t('hero.index') }}
          </p>
          <h3>{{ previewTranslation?.displayName || 'Artsy' }}</h3>
          <p
            class="preview-handle"
            dir="ltr"
          >
            {{ previewTranslation?.handle }}
          </p>
          <p class="preview-tagline">
            {{ previewTranslation?.tagline }}
          </p>
          <p class="preview-bio">
            {{ previewTranslation?.bio }}
          </p>
          <div class="preview-rule" />
          <p class="admin-micro-label">
            {{ t('admin.projectTitle') }}
          </p>
          <h4>{{ previewProjectTranslation?.title || t('admin.emptyProjects') }}</h4>
          <p class="preview-bio">
            {{ previewProjectTranslation?.description }}
          </p>
        </div>
        <div class="preview-status">
          <span class="status-pixel" />{{ t('admin.unsaved') }} <span v-if="hasUnsavedChanges">/</span><span v-else>{{ t('admin.saved') }}</span>
        </div>
      </aside>
    </div>
  </div>
</template>
