<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { usePortfolioStore } from '../stores/portfolio'
import { locale } from '../i18n'
import { formatIndex } from '../i18n/format'
import ProjectGrid from '../components/ProjectGrid.vue'
import PixelIcon from '../components/PixelIcon.vue'

const { t } = useI18n()
const store = usePortfolioStore()
const activeTag = ref('')
const tags = computed(() => [...new Set(store.projects.flatMap(project => project.tags))].sort())
const filtered = computed(() => activeTag.value
  ? store.projects.filter(project => project.tags.includes(activeTag.value))
  : store.projects)

onMounted(() => { void store.load() })
</script>

<template>
  <div class="page-wrap inner-page">
    <header class="page-heading-row">
      <div>
        <p class="section-eyebrow">
          {{ t('work.eyebrow') }}
        </p>
        <h1 class="pixel-heading page-title">
          {{ t('work.title') }}
        </h1>
        <p class="page-lede">
          {{ t('work.intro') }}
        </p>
      </div>
      <span
        class="large-index"
        aria-hidden="true"
      >{{ formatIndex(1, locale) }}</span>
    </header>
    <div
      v-if="tags.length"
      class="filter-row"
      role="group"
      :aria-label="t('work.tags')"
    >
      <button
        class="filter-button"
        :aria-pressed="activeTag === ''"
        @click="activeTag = ''"
      >
        {{ t('work.all') }}
      </button>
      <button
        v-for="tag in tags"
        :key="tag"
        class="filter-button"
        :aria-pressed="activeTag === tag"
        @click="activeTag = tag"
      >
        {{ tag }}
      </button>
    </div>
    <ProjectGrid :projects="filtered" />
    <RouterLink
      class="back-link"
      to="/"
    >
      <PixelIcon name="arrow" /><span>{{ t('nav.work') }}</span>
    </RouterLink>
  </div>
</template>
