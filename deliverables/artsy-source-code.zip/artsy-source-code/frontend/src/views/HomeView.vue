<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { usePortfolioStore } from '../stores/portfolio'
import { locale } from '../i18n'
import { formatIndex } from '../i18n/format'
import { previewProfile, profileTranslation } from '../content/preview-profile'
import ProjectGrid from '../components/ProjectGrid.vue'
import PixelIcon from '../components/PixelIcon.vue'

const { t } = useI18n()
const store = usePortfolioStore()
const avatarFailed = ref(false)
const bannerFailed = ref(false)
const profile = computed(() => store.profile ?? previewProfile)
const person = computed(() => profileTranslation(profile.value, locale))
const featuredProjects = computed(() => store.projects.slice(0, 3))

onMounted(() => { void store.load() })
</script>

<template>
  <div class="page-wrap home-page">
    <img
      v-if="!bannerFailed"
      class="profile-banner"
      src="https://yt3.googleusercontent.com/3_gN4bf62Q2D6TRYe9qB3HckhUgfnYryVHD8euYiXjxabbtB8fTQLHU3dQGTdL4igwzhC8tl7ZM=w1060-fcrop64=1,00005a57ffffa5a8-k-c0xffffffff-no-nd-rj"
      :alt="t('hero.bannerAlt')"
      width="1060"
      height="300"
      fetchpriority="high"
      @error="bannerFailed = true"
    >
    <div
      v-else
      class="profile-banner profile-banner-fallback"
      role="img"
      :aria-label="t('hero.bannerAlt')"
    >
      <span
        class="banner-fallback-brand"
        aria-hidden="true"
      >ARTSY</span>
      <span
        class="banner-fallback-grid"
        aria-hidden="true"
      ><i /><i /><i /><i /><i /><i /><i /><i /><i /></span>
      <span
        class="banner-fallback-index"
        aria-hidden="true"
      >{{ formatIndex(1, locale) }}</span>
    </div>
    <section
      class="hero-panel"
      aria-labelledby="hero-title"
    >
      <div class="panel-stamp">
        <span>{{ t('hero.index') }}</span>
        <span
          class="stamp-line"
          aria-hidden="true"
        />
        <span>ARTSY / {{ formatIndex(1, locale) }}</span>
      </div>
      <div class="hero-layout">
        <figure class="avatar-frame">
          <img
            v-if="!avatarFailed"
            class="profile-avatar"
            src="https://yt3.googleusercontent.com/a5CJTPRicsXFxO13sVSIcM-PTWsuYBHtE637joRZrVcuw1aZlW5H0iTDlRtXxHX46Ibr4Gcn-Uo=s160-c-k-c0x00ffffff-no-rj"
            :alt="t('hero.avatarAlt')"
            width="160"
            height="160"
            fetchpriority="high"
            @error="avatarFailed = true"
          >
          <div
            v-else
            class="avatar-fallback"
            role="img"
            :aria-label="t('hero.avatarAlt')"
          >
            A
          </div>
          <figcaption><bdi dir="ltr">{{ person.handle }}</bdi></figcaption>
        </figure>
        <div class="hero-copy">
          <h1
            id="hero-title"
            class="pixel-heading hero-title"
          >
            <span class="hero-intro">{{ t('hero.intro') }}</span>
            <span class="hero-name">{{ t('hero.name') }}</span>
          </h1>
          <p class="hero-subtitle">
            {{ person.tagline }}
          </p>
          <div
            class="icon-strip"
            aria-hidden="true"
          >
            <span><PixelIcon name="play" /></span>
            <span><PixelIcon name="external" /></span>
            <span><PixelIcon name="mail" /></span>
            <span><PixelIcon name="arrow" /></span>
          </div>
        </div>
      </div>
      <span
        class="hero-corner hero-corner-start"
        aria-hidden="true"
      />
      <span
        class="hero-corner hero-corner-end"
        aria-hidden="true"
      />
    </section>

    <section
      id="work"
      class="content-section work-section"
      aria-labelledby="work-title"
    >
      <div class="section-head">
        <div>
          <p class="section-eyebrow">
            {{ t('work.eyebrow') }}
          </p>
          <h2
            id="work-title"
            class="pixel-heading section-title"
          >
            {{ t('work.title') }}
          </h2>
        </div>
        <div class="section-aside">
          <p>{{ t('work.intro') }}</p>
          <RouterLink
            class="text-link"
            to="/work"
          >
            <span>{{ t('work.all') }}</span><PixelIcon name="arrow" />
          </RouterLink>
        </div>
      </div>
      <ProjectGrid :projects="featuredProjects" />
    </section>

    <section
      id="about"
      class="content-section about-section"
      aria-labelledby="about-title"
    >
      <div class="section-head">
        <div>
          <p class="section-eyebrow">
            {{ t('about.eyebrow') }}
          </p>
          <h2
            id="about-title"
            class="pixel-heading section-title"
          >
            {{ t('about.title') }}
          </h2>
        </div>
        <p
          class="section-counter"
          aria-hidden="true"
        >
          {{ formatIndex(2, locale) }}
        </p>
      </div>
      <div class="about-grid">
        <p class="about-bio">
          {{ person.bio }}
        </p>
        <div class="about-details">
          <div class="detail-block">
            <h3>{{ t('about.services') }}</h3>
            <ul class="plain-list">
              <li
                v-for="service in person.services"
                :key="service"
              >
                {{ service }}
              </li>
            </ul>
          </div>
          <div class="detail-block">
            <h3>{{ t('about.skills') }}</h3>
            <ul class="plain-list">
              <li
                v-for="skill in person.skills"
                :key="skill"
              >
                {{ skill }}
              </li>
            </ul>
          </div>
          <dl class="profile-facts">
            <div><dt>{{ t('about.basedIn') }}</dt><dd>{{ person.country }}</dd></div>
            <div><dt>{{ t('about.languages') }}</dt><dd>{{ person.spokenLanguages.join(' · ') }}</dd></div>
          </dl>
        </div>
      </div>
    </section>

    <section
      id="contact"
      class="content-section contact-section"
      aria-labelledby="contact-title"
    >
      <div class="section-head">
        <div>
          <p class="section-eyebrow">
            {{ t('contact.eyebrow') }}
          </p>
          <h2
            id="contact-title"
            class="pixel-heading section-title"
          >
            {{ t('contact.title') }}
          </h2>
        </div>
        <PixelIcon
          class="contact-mark"
          name="mail"
        />
      </div>
      <div class="contact-row">
        <p>{{ t('contact.body') }}</p>
        <a
          class="button-link"
          :href="profile.contactUrl"
          target="_blank"
          rel="noreferrer"
        >
          <span>{{ t('contact.button') }}</span><PixelIcon name="external" />
        </a>
      </div>
    </section>
  </div>
</template>
