<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { locale } from '../i18n'
import { formatIndex, formatNumber } from '../i18n/format'
import { getProject } from '../services/api'
import { usePortfolioStore } from '../stores/portfolio'
import type { Project } from '../types'
import PixelIcon from '../components/PixelIcon.vue'

const route = useRoute()
const { t } = useI18n()
const store = usePortfolioStore()
const project = ref<Project | null>(null)
const loading = ref(true)
const failed = ref(false)
const slug = computed(() => String(route.params.slug ?? ''))

async function loadProject() {
  loading.value = true
  failed.value = false
  try {
    project.value = await getProject(locale, slug.value)
    if (!project.value) {
      await store.load()
      project.value = store.projects.find(item => item.slug === slug.value) ?? null
    }
  } catch {
    failed.value = true
  } finally {
    loading.value = false
  }
}

onMounted(() => { void loadProject() })
watch(slug, () => { void loadProject() })
</script>

<template>
  <div class="page-wrap inner-page project-page">
    <RouterLink
      class="back-link"
      to="/work"
    >
      <PixelIcon name="arrow" /><span>{{ t('work.back') }}</span>
    </RouterLink>
    <p
      v-if="loading"
      class="page-lede"
      role="status"
    >
      {{ t('project.loading') }}
    </p>
    <section
      v-else-if="project"
      class="project-detail"
      aria-labelledby="project-title"
    >
      <header class="project-detail-head">
        <div>
          <p class="section-eyebrow">
            {{ project.tags.join(' / ') || t('work.eyebrow') }}
          </p>
          <h1
            id="project-title"
            class="pixel-heading page-title"
          >
            {{ project.title }}
          </h1>
          <p
            v-if="project.year"
            class="project-year-detail"
          >
            {{ t('work.year') }} / {{ formatNumber(project.year, locale) }}
          </p>
        </div>
        <span
          class="large-index"
          aria-hidden="true"
        >{{ formatIndex(1, locale) }}</span>
      </header>
      <div class="video-frame">
        <video
          v-if="project.videoUrl"
          :poster="project.posterUrl ?? undefined"
          controls
          preload="none"
          playsinline
        >
          <source :src="project.videoUrl">
          {{ t('project.videoUnavailable') }}
        </video>
        <div
          v-else
          class="video-unavailable"
        >
          <PixelIcon name="play" /><p>{{ t('project.videoUnavailable') }}</p>
        </div>
      </div>
      <div class="project-description-grid">
        <div class="detail-block">
          <h2>{{ t('work.description') }}</h2>
          <p class="project-description">
            {{ project.description || t('project.videoUnavailable') }}
          </p>
          <a
            v-if="project.externalUrl"
            class="text-link"
            :href="project.externalUrl"
            target="_blank"
            rel="noreferrer"
          >
            <span>{{ t('work.external') }}</span><PixelIcon name="external" />
          </a>
        </div>
        <dl class="project-meta">
          <div v-if="project.tools.length">
            <dt>{{ t('work.tools') }}</dt><dd>{{ project.tools.join(' · ') }}</dd>
          </div>
          <div v-if="project.credits.length">
            <dt>{{ t('work.credits') }}</dt><dd>{{ project.credits.join(' · ') }}</dd>
          </div>
          <div v-if="project.tags.length">
            <dt>{{ t('work.tags') }}</dt><dd>{{ project.tags.join(' · ') }}</dd>
          </div>
        </dl>
      </div>
    </section>
    <section
      v-else
      class="not-found-panel"
      role="status"
    >
      <p class="section-eyebrow">
        {{ failed ? t('common.error') : formatNumber(404, locale) }}
      </p>
      <h1 class="pixel-heading page-title">
        {{ t('project.notFound') }}
      </h1>
      <RouterLink
        class="text-link"
        to="/work"
      >
        <span>{{ t('work.back') }}</span><PixelIcon name="arrow" />
      </RouterLink>
    </section>
  </div>
</template>
