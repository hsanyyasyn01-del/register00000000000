<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { usePortfolioStore } from '../stores/portfolio'
import { locale } from '../i18n'
import { formatIndex } from '../i18n/format'
import { previewProfile } from '../content/preview-profile'
import PixelIcon from '../components/PixelIcon.vue'

const { t } = useI18n()
const store = usePortfolioStore()
const profile = computed(() => store.profile ?? previewProfile)
onMounted(() => { void store.load() })
</script>

<template>
  <div class="page-wrap inner-page contact-page">
    <header class="page-heading-row">
      <div>
        <p class="section-eyebrow">
          {{ t('contact.eyebrow') }}
        </p><h1 class="pixel-heading page-title">
          {{ t('contact.title') }}
        </h1>
      </div>
      <span
        class="large-index"
        aria-hidden="true"
      >{{ formatIndex(3, locale) }}</span>
    </header>
    <div class="contact-card">
      <PixelIcon
        class="contact-mark"
        name="mail"
      />
      <p class="contact-copy">
        {{ t('contact.body') }}
      </p>
      <a
        class="button-link"
        :href="profile.contactUrl"
        target="_blank"
        rel="noreferrer"
      >
        <span>{{ t('contact.button') }}</span><PixelIcon name="external" />
      </a>
      <p class="small-note">
        {{ t('contact.externalNote') }}
      </p>
    </div>
  </div>
</template>
