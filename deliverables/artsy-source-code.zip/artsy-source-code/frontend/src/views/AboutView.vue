<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { locale } from '../i18n'
import { formatIndex } from '../i18n/format'
import { profileTranslation, previewProfile } from '../content/preview-profile'
import { usePortfolioStore } from '../stores/portfolio'

const { t } = useI18n()
const store = usePortfolioStore()
const profile = computed(() => store.profile ?? previewProfile)
const person = computed(() => profileTranslation(profile.value, locale))
onMounted(() => { void store.load() })
</script>

<template>
  <div class="page-wrap inner-page about-page">
    <header class="page-heading-row">
      <div>
        <p class="section-eyebrow">
          {{ t('about.eyebrow') }}
        </p><h1 class="pixel-heading page-title">
          {{ t('about.title') }}
        </h1>
      </div>
      <span
        class="large-index"
        aria-hidden="true"
      >{{ formatIndex(2, locale) }}</span>
    </header>
    <div class="about-grid about-page-grid">
      <div>
        <p class="about-bio">
          {{ person.bio }}
        </p>
        <dl class="profile-facts">
          <div><dt>{{ t('about.basedIn') }}</dt><dd>{{ person.country }}</dd></div>
          <div><dt>{{ t('about.languages') }}</dt><dd>{{ person.spokenLanguages.join(' · ') }}</dd></div>
          <div><dt>{{ t('about.name') }}</dt><dd><bdi dir="ltr">{{ person.handle }}</bdi></dd></div>
        </dl>
      </div>
      <div class="about-details">
        <div class="detail-block">
          <h2>{{ t('about.services') }}</h2><ul class="plain-list">
            <li
              v-for="service in person.services"
              :key="service"
            >
              {{ service }}
            </li>
          </ul>
        </div>
        <div class="detail-block">
          <h2>{{ t('about.skills') }}</h2><ul class="plain-list">
            <li
              v-for="skill in person.skills"
              :key="skill"
            >
              {{ skill }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
