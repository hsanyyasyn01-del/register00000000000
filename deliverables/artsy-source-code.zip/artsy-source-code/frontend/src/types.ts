import type { Locale } from './i18n/language'

export interface ProfileTranslation {
  displayName: string
  handle: string
  tagline: string
  bio: string
  country: string
  spokenLanguages: string[]
  services: string[]
  skills: string[]
}

export interface Profile {
  contactUrl: string
  translations: Partial<Record<Locale, ProfileTranslation>> & { en: ProfileTranslation }
}

export interface Project {
  id: string
  slug: string
  year: number | null
  status: 'draft' | 'published'
  title: string
  description: string
  tools: string[]
  credits: string[]
  tags: string[]
  videoUrl: string | null
  posterUrl: string | null
  externalUrl: string | null
  sortOrder: number
}

export interface MediaItem {
  id: string
  filename: string
  mimeType: string
  sizeBytes: number
  url: string
}

export interface AuditEntry {
  id: string
  action: string
  entityType: string
  entityId: string | null
  createdAt: string
}

export interface ProfileEditorData {
  contactUrl: string
  translations: Record<Locale, ProfileTranslation>
}

export interface ProjectEditorTranslation {
  title: string
  description: string
  tools: string[]
  credits: string[]
  tags: string[]
}

export interface ProjectEditorData {
  id?: string
  slug: string
  year: number | null
  status: 'draft' | 'published'
  sortOrder: number
  videoMediaId: string | null
  posterMediaId: string | null
  externalUrl: string | null
  translations: Record<Locale, ProjectEditorTranslation>
}
