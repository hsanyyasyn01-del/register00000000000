import { describe, expect, it } from 'vitest'
import { isRtl, normalizeLocale } from '../src/i18n/language'
import { formatIndex, formatNumber } from '../src/i18n/format'
import en from '../src/locales/en.json'
import ar from '../src/locales/ar.json'
import fr from '../src/locales/fr.json'

describe('locale handling', () => {
  it.each([
    ['en-US', 'en'], ['en', 'en'], ['ar-EG', 'ar'], ['AR', 'ar'], ['fr-CA', 'fr'], ['fr', 'fr'],
    ['es-MX', 'en'], ['', 'en'], [null, 'en'], ['en_US', 'en'],
  ])('normalizes %s to %s', (input, expected) => {
    expect(normalizeLocale(input)).toBe(expected)
  })

  it('marks only Arabic as right-to-left', () => {
    expect(isRtl('ar')).toBe(true)
    expect(isRtl('en')).toBe(false)
    expect(isRtl('fr')).toBe(false)
  })

  it('formats Arabic interface numbers with Arabic-Indic digits', () => {
    expect(formatIndex(1, 'ar')).toBe('٠١')
    expect(formatNumber(404, 'ar')).toBe('٤٠٤')
    expect(formatIndex(1, 'en')).toBe('01')
  })

  it('keeps the static message keys aligned across supported locales', () => {
    const keys = (value: unknown, prefix = ''): string[] => {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return [prefix]
      return Object.entries(value).flatMap(([key, child]) => keys(child, prefix ? `${prefix}.${key}` : key))
    }
    expect(keys(ar).sort()).toEqual(keys(en).sort())
    expect(keys(fr).sort()).toEqual(keys(en).sort())
  })
})
