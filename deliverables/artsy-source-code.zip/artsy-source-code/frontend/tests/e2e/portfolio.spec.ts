import { expect, test, type Page, type Route } from '@playwright/test'
import AxeBuilder from '@axe-core/playwright'
import type { AuditEntry, MediaItem, Profile, ProfileEditorData, Project, ProjectEditorData } from '../../src/types'

const profile: Profile = {
  contactUrl: 'https://www.fiverr.com/nolohc/',
  translations: {
    en: {
      displayName: 'Artsy',
      handle: '@nolohc',
      tagline: 'Video editor for YouTube Shorts and short-form work.',
      bio: 'I edit short-form video with pacing, captions, sound, and clear cuts.',
      country: 'Egypt',
      spokenLanguages: ['English', 'Spanish', 'Arabic'],
      services: ['YouTube Shorts editing', 'Reels editing'],
      skills: ['Video editor', 'YouTube video creator'],
    },
    ar: {
      displayName: 'آرتسي',
      handle: '@nolohc',
      tagline: 'مونتاج فيديوهات YouTube Shorts والمقاطع القصيرة.',
      bio: 'أعمل على مونتاج المقاطع القصيرة مع ضبط الإيقاع والعناوين والصوت والقص الواضح.',
      country: 'مصر',
      spokenLanguages: ['الإنجليزية', 'الإسبانية', 'العربية'],
      services: ['مونتاج YouTube Shorts', 'مونتاج Reels'],
      skills: ['مونتاج الفيديو', 'إنشاء فيديوهات YouTube'],
    },
    fr: {
      displayName: 'Artsy',
      handle: '@nolohc',
      tagline: 'Montage de YouTube Shorts et de vidéos courtes.',
      bio: 'Je monte des formats courts avec du rythme, des sous-titres, du son et des coupes lisibles.',
      country: 'Égypte',
      spokenLanguages: ['Anglais', 'Espagnol', 'Arabe'],
      services: ['Montage YouTube Shorts', 'Montage Reels'],
      skills: ['Montage vidéo', 'Création vidéo YouTube'],
    },
  },
}

function projectFor(locale: 'en' | 'ar' | 'fr'): Project {
  const copy = {
    en: { title: 'Fixture edit', description: 'A project used by the browser tests.', tools: ['CapCut'], credits: ['Video editing'], tags: ['Short-form'] },
    ar: { title: 'مونتاج تجريبي', description: 'مشروع تجريبي لاختبارات المتصفح.', tools: ['CapCut'], credits: ['مونتاج الفيديو'], tags: ['مقاطع قصيرة'] },
    fr: { title: 'Montage de test', description: 'Projet utilisé par les tests du navigateur.', tools: ['CapCut'], credits: ['Montage vidéo'], tags: ['Format court'] },
  }[locale]
  return {
    id: 'fixture-project',
    slug: 'fixture-edit',
    year: null,
    status: 'published',
    title: copy.title,
    description: copy.description,
    tools: copy.tools,
    credits: copy.credits,
    tags: copy.tags,
    videoUrl: null,
    posterUrl: null,
    externalUrl: null,
    sortOrder: 0,
  }
}

async function setDocumentLocale(page: Page, path: string, locale: 'ar' | 'fr', direction: 'rtl' | 'ltr') {
  await page.route(path, async (route) => {
    const response = await route.fetch()
    const html = await response.text()
    const updated = html.replace('<html lang="en" dir="ltr">', `<html lang="${locale}" dir="${direction}">`)
    if (updated === html) throw new Error('The test server document language marker changed.')
    await route.fulfill({ response, body: updated })
  })
}

async function mockPublicApi(page: Page, failImages = false, emptyProjects = false) {
  await page.route('**/api/profile', route => route.fulfill({ json: profile }))
  const fulfillProjects = async (route: Route, asList: boolean) => {
    const acceptLanguage = route.request().headers()['accept-language'] ?? 'en'
    const locale = acceptLanguage.startsWith('ar') ? 'ar' : acceptLanguage.startsWith('fr') ? 'fr' : 'en'
    await route.fulfill({ json: asList ? (emptyProjects ? [] : [projectFor(locale)]) : projectFor(locale) })
  }
  await page.route('**/api/projects', route => fulfillProjects(route, true))
  await page.route('**/api/projects/**', route => fulfillProjects(route, false))
  await page.route('https://yt3.googleusercontent.com/**', route => failImages
    ? route.abort()
    : route.fulfill({
        status: 200,
        contentType: 'image/png',
        body: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/n7sAAAAASUVORK5CYII=', 'base64'),
      }))
}

function editorProfile(): ProfileEditorData {
  const english = profile.translations.en
  const arabic = profile.translations.ar
  const french = profile.translations.fr
  if (!english || !arabic || !french) throw new Error('The editor fixture must include all locales.')
  return {
    contactUrl: 'https://www.fiverr.com/nolohc/',
    translations: {
      en: { ...english },
      ar: { ...arabic },
      fr: { ...french },
    },
  }
}

async function fulfillJson(route: Route, value: unknown, status = 200) {
  await route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(value) })
}

async function mockAdminApi(page: Page) {
  const token = 'A'.repeat(43)
  let authenticated = false
  let currentProfile = editorProfile()
  let projects: ProjectEditorData[] = []
  let media: MediaItem[] = []
  let savedProject: ProjectEditorData | undefined
  let receivedBytes = 4
  let resumedFromCheckpoint = false
  const audit: AuditEntry[] = []

  await page.route('**/api/admin/**', async (route) => {
    const request = route.request()
    const path = new URL(request.url()).pathname.split('/api/admin/')[1] ?? ''
    if (path === 'bootstrap') {
      return fulfillJson(route, {
        needsSetup: !authenticated,
        authenticated,
        csrfToken: authenticated ? 'session-csrf-token' : 'setup-csrf-token',
        maxUploadBytes: 1024 * 1024 * 1024,
      })
    }
    if (path === 'setup' && request.method() === 'POST') {
      authenticated = true
      return fulfillJson(route, { csrfToken: 'session-csrf-token', authenticated: true })
    }
    if (path === 'login' && request.method() === 'POST') {
      authenticated = true
      return fulfillJson(route, { csrfToken: 'session-csrf-token', authenticated: true })
    }
    if (!authenticated) return fulfillJson(route, { error: { code: 'unauthorized', message: 'Authentication required.' } }, 401)
    if (path === 'profile' && request.method() === 'GET') return fulfillJson(route, currentProfile)
    if (path === 'profile' && request.method() === 'PUT') {
      currentProfile = request.postDataJSON() as ProfileEditorData
      return fulfillJson(route, currentProfile)
    }
    if (path === 'projects' && request.method() === 'GET') return fulfillJson(route, projects)
    if (path === 'projects' && request.method() === 'POST') {
      savedProject = { ...(request.postDataJSON() as ProjectEditorData), id: 'fixture-project-created' }
      projects = [savedProject]
      return fulfillJson(route, savedProject, 201)
    }
    if (path === 'projects/reorder') return fulfillJson(route, { saved: true })
    if (path === 'media' && request.method() === 'GET') return fulfillJson(route, media)
    if (path === 'audit') return fulfillJson(route, audit)
    if (path === 'uploads/init') {
      receivedBytes = 0
      return fulfillJson(route, { uploadId: 'fixture-upload', receivedBytes }, 201)
    }
    if (path === 'uploads/fixture-upload' && request.method() === 'GET') {
      resumedFromCheckpoint = receivedBytes === 4
      return fulfillJson(route, { receivedBytes, totalBytes: 8 })
    }
    if (path === 'uploads/fixture-upload' && request.method() === 'PUT') {
      receivedBytes += (await request.postDataBuffer())?.length ?? 0
      return fulfillJson(route, { receivedBytes })
    }
    if (path === 'uploads/fixture-upload/complete') {
      const uploaded: MediaItem = {
        id: 'fixture-media',
        filename: 'sample.png',
        mimeType: 'image/png',
        sizeBytes: 8,
        url: '/media/fixture-media',
      }
      media = [uploaded, ...media]
      return fulfillJson(route, uploaded, 201)
    }
    if (path === 'logout') {
      authenticated = false
      return route.fulfill({ status: 204, body: '' })
    }
    return fulfillJson(route, { error: { code: 'not_found', message: 'Not found.' } }, 404)
  })

  return {
    token,
    getSavedProject: () => savedProject,
    resumedFromCheckpoint: () => resumedFromCheckpoint,
    uploadedBytes: () => receivedBytes,
  }
}

test('English public pages navigate to a localized project', async ({ page }) => {
  await mockPublicApi(page)
  await page.goto('/')

  await expect(page.locator('html')).toHaveAttribute('lang', 'en')
  await expect(page.getByRole('heading', { level: 1 })).toContainText('ARTSY')
  await expect(page.getByText('Video editor for YouTube Shorts and short-form work.')).toBeVisible()
  await expect(page.getByRole('img', { name: "Artsy's profile banner" })).toBeVisible()

  await page.getByRole('link', { name: /Work/ }).click()
  await expect(page.getByRole('heading', { level: 1, name: 'Work' })).toBeVisible()
  await page.getByRole('link', { name: /Open project: Fixture edit/ }).click()
  await expect(page.getByRole('heading', { level: 1, name: 'Fixture edit' })).toBeVisible()
  await expect(page.getByText('A project used by the browser tests.')).toBeVisible()
})

test('remote image failures leave accessible local pixel fallbacks', async ({ page }) => {
  await mockPublicApi(page, true)
  await page.goto('/')

  await expect(page.getByRole('img', { name: "Artsy's profile banner" })).toBeVisible()
  await expect(page.getByRole('img', { name: "Artsy's profile portrait" })).toHaveText('A')
  await expect(page.locator('.profile-banner-fallback')).toBeVisible()
})

test('Arabic uses RTL flow, Arabic numerals, and the self-hosted Arabic font at 320 pixels', async ({ page }) => {
  await mockPublicApi(page, false, true)
  await setDocumentLocale(page, '**/', 'ar', 'rtl')
  await page.setViewportSize({ width: 320, height: 760 })
  await page.goto('/')

  await expect(page.locator('html')).toHaveAttribute('lang', 'ar')
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl')
  await expect(page.getByRole('heading', { level: 1 })).toContainText('آرتسي')
  await expect(page.getByText('مونتاج فيديوهات YouTube Shorts والمقاطع القصيرة.')).toBeVisible()
  await expect(page.locator('.slot-index').first()).toHaveText('٠١')
  await expect(page.locator('.empty-index')).toHaveText('٠٠')
  await expect(page.locator('select')).toHaveCount(0)
  await page.evaluate(() => document.fonts.ready.then(() => true))
  expect(await page.evaluate(() => document.fonts.check('16px "IBM Plex Sans Arabic"'))).toBe(true)
  const dimensions = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    clientWidth: document.documentElement.clientWidth,
  }))
  expect(dimensions.scrollWidth).toBeLessThanOrEqual(dimensions.clientWidth)
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze()
  expect(results.violations).toEqual([])
})

test('French copy and page metadata use the detected document language', async ({ page }) => {
  await mockPublicApi(page)
  await setDocumentLocale(page, '**/contact', 'fr', 'ltr')
  await page.goto('/contact')
  await expect(page.locator('html')).toHaveAttribute('lang', 'fr')
  await expect(page.getByRole('heading', { level: 1, name: 'Contact' })).toBeVisible()
  await expect(page.getByRole('link', { name: /Ouvrir le profil Fiverr/ })).toBeVisible()
  await expect(page).toHaveTitle('Contact — Artsy')
})

test('public home has no detected WCAG 2.1 AA violations in dark mode', async ({ page }) => {
  await mockPublicApi(page)
  await page.emulateMedia({ colorScheme: 'dark' })
  await page.goto('/')
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible()

  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze()
  expect(results.violations).toEqual([])
})

test('all other public routes have no detected WCAG 2.1 AA violations', async ({ page }) => {
  await mockPublicApi(page)
  for (const path of ['/work', '/about', '/contact', '/project/fixture-edit']) {
    await page.goto(path)
    await expect(page.locator('main')).toBeVisible()
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze()
    expect(results.violations, `axe violations at ${path}`).toEqual([])
  }
})

test('private editor setup saves three-language project content and resumes a media upload', async ({ page }) => {
  const api = await mockAdminApi(page)
  await page.goto(`/${api.token}`)

  await expect(page.getByRole('heading', { name: 'Set a passphrase' })).toBeVisible()
  const setupAudit = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze()
  expect(setupAudit.violations).toEqual([])
  await page.getByLabel('Passphrase', { exact: true }).fill('a secure local test phrase')
  await page.getByLabel('Confirm passphrase').fill('a secure local test phrase')
  await page.getByRole('button', { name: 'Set passphrase' }).click()
  await expect(page.getByRole('button', { name: 'Profile' })).toBeVisible()
  const editorAudit = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze()
  expect(editorAudit.violations).toEqual([])

  await page.getByRole('button', { name: 'Projects' }).click()
  await page.getByRole('button', { name: 'New project' }).last().click()
  await page.getByLabel('URL slug').fill('fixture-project')
  await page.getByLabel('Project title').fill('Fixture project')
  await page.getByLabel('Description').fill('A private editor test project.')
  await page.getByLabel('Tools, comma separated').fill('CapCut')
  await page.getByLabel('Credits, comma separated').fill('Video editing')
  await page.getByLabel('Tags, comma separated').fill('Short-form')
  await page.getByRole('button', { name: 'AR', exact: true }).click()
  await page.getByLabel('Project title').fill('مشروع تجريبي')
  await page.getByLabel('Description').fill('وصف تجريبي للمحرر.')
  await page.getByLabel('Tools, comma separated').fill('CapCut')
  await page.getByLabel('Credits, comma separated').fill('مونتاج الفيديو')
  await page.getByLabel('Tags, comma separated').fill('مقاطع قصيرة')
  await page.getByRole('button', { name: 'FR', exact: true }).click()
  await page.getByLabel('Project title').fill('Projet de test')
  await page.getByLabel('Description').fill('Description de test de l’éditeur.')
  await page.getByLabel('Tools, comma separated').fill('CapCut')
  await page.getByLabel('Credits, comma separated').fill('Montage vidéo')
  await page.getByLabel('Tags, comma separated').fill('Format court')
  await page.getByRole('button', { name: 'Save changes' }).last().click()
  await expect(page.getByText('Project saved.')).toBeVisible()
  expect(api.getSavedProject()?.translations.ar.tags).toEqual(['مقاطع قصيرة'])
  expect(api.getSavedProject()?.translations.fr.credits).toEqual(['Montage vidéo'])

  await page.getByRole('button', { name: 'Media' }).click()
  const uploadLastModified = 1_700_000_000_000
  await page.evaluate(({ key, uploadId, bytes, lastModified }) => {
    localStorage.setItem(key, uploadId)
    const input = document.querySelector<HTMLInputElement>('input[type="file"]')
    if (!input) throw new Error('The media upload input is missing.')
    const transfer = new DataTransfer()
    transfer.items.add(new File([new Uint8Array(bytes)], 'sample.png', {
      type: 'image/png',
      lastModified,
    }))
    input.files = transfer.files
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }))
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }))
  }, {
    key: `artsy-upload:${api.token}:sample.png:8:${uploadLastModified}`,
    uploadId: 'fixture-upload',
    bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a],
    lastModified: uploadLastModified,
  })
  await expect(page.getByText('Upload complete').first()).toBeVisible()
  await expect(page.getByText('sample.png')).toBeVisible()
  expect(api.resumedFromCheckpoint()).toBe(true)
  expect(api.uploadedBytes()).toBe(8)
})
