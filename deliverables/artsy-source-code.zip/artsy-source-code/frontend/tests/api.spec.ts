import { afterEach, describe, expect, it, vi } from 'vitest'
import { adminPath, request } from '../src/services/api'

afterEach(() => vi.unstubAllGlobals())

describe('API client', () => {
  it('uses same-origin credentials and returns decoded JSON', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    }))
    vi.stubGlobal('fetch', fetchMock)
    await expect(request<{ ok: boolean }>('/api/health')).resolves.toEqual({ ok: true })
    expect(fetchMock).toHaveBeenCalledWith('/api/health', expect.objectContaining({ credentials: 'same-origin' }))
    expect((fetchMock.mock.calls[0]?.[1] as RequestInit).headers).toBeInstanceOf(Headers)
  })

  it('keeps structured server errors available to forms', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ error: { code: 'csrf_failed', message: 'CSRF check failed' } }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' },
    })))
    await expect(request('/private/action', { method: 'POST' })).rejects.toMatchObject({
      status: 403,
      code: 'csrf_failed',
      message: 'CSRF check failed',
    })
  })

  it('keeps the one-time URL token in a relative same-origin API path', () => {
    expect(adminPath('a/b +', 'profile')).toBe('/a%2Fb%20%2B/api/admin/profile')
    expect(adminPath('private-token')).toBe('/private-token/api/admin')
  })
})
