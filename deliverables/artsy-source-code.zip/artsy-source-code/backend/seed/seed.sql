-- Public profile facts transcribed from https://www.fiverr.com/nolohc/ on 2026-10-02.
-- Artsy is the display name supplied for this portfolio; the public Fiverr handle is retained.
INSERT INTO profile (id, contact_url)
VALUES (1, 'https://www.fiverr.com/nolohc/')
ON CONFLICT (id) DO NOTHING;

INSERT INTO profile_translations (
    profile_id, locale, display_name, handle, tagline, bio, country,
    spoken_languages, services, skills
) VALUES
(
    1, 'en', 'Artsy', '@nolohc',
    'Video editor for YouTube Shorts and short-form work.',
    'I edit short videos for YouTube Shorts, Reels, TikTok, reaction videos, and other YouTube content. I work from raw footage and handle pacing, captions, sound, and cuts.',
    'Egypt',
    '["English", "Spanish", "Arabic"]'::JSONB,
    '["YouTube Shorts editing", "Reels editing", "TikTok editing", "Reaction videos"]'::JSONB,
    '["Video editor", "Short-form editor", "YouTube video creator", "Social media video editor"]'::JSONB
),
(
    1, 'ar', 'آرتسي', '@nolohc',
    'مونتاج فيديوهات YouTube Shorts والمقاطع القصيرة.',
    'أحرر فيديوهات قصيرة لـ YouTube Shorts وReels وTikTok ومقاطع ردود الفعل وغيرها من محتوى YouTube. أعمل انطلاقاً من اللقطات الخام، مع ضبط الإيقاع والعناوين والصوت والقص.',
    'مصر',
    '["الإنجليزية", "الإسبانية", "العربية"]'::JSONB,
    '["مونتاج YouTube Shorts", "مونتاج Reels", "مونتاج TikTok", "مقاطع ردود الفعل"]'::JSONB,
    '["مونتاج الفيديو", "مونتاج الفيديوهات القصيرة", "إنشاء فيديوهات YouTube", "مونتاج فيديوهات التواصل الاجتماعي"]'::JSONB
),
(
    1, 'fr', 'Artsy', '@nolohc',
    'Montage vidéo pour YouTube Shorts et formats courts.',
    'Je monte des vidéos courtes pour YouTube Shorts, Reels, TikTok, les vidéos de réaction et d’autres contenus YouTube. À partir de rushes, je travaille le rythme, les sous-titres, le son et les coupes.',
    'Égypte',
    '["Anglais", "Espagnol", "Arabe"]'::JSONB,
    '["Montage YouTube Shorts", "Montage Reels", "Montage TikTok", "Vidéos de réaction"]'::JSONB,
    '["Montage vidéo", "Montage de formats courts", "Création vidéo YouTube", "Montage vidéo pour les réseaux sociaux"]'::JSONB
)
ON CONFLICT (profile_id, locale) DO NOTHING;
