CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS profile (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    contact_url TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profile_translations (
    profile_id SMALLINT NOT NULL DEFAULT 1 REFERENCES profile(id) ON DELETE CASCADE,
    locale TEXT NOT NULL CHECK (locale IN ('en', 'ar', 'fr')),
    display_name TEXT NOT NULL DEFAULT '',
    handle TEXT NOT NULL DEFAULT '',
    tagline TEXT NOT NULL DEFAULT '',
    bio TEXT NOT NULL DEFAULT '',
    country TEXT NOT NULL DEFAULT '',
    spoken_languages JSONB NOT NULL DEFAULT '[]'::JSONB CHECK (jsonb_typeof(spoken_languages) = 'array'),
    services JSONB NOT NULL DEFAULT '[]'::JSONB CHECK (jsonb_typeof(services) = 'array'),
    skills JSONB NOT NULL DEFAULT '[]'::JSONB CHECK (jsonb_typeof(skills) = 'array'),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (profile_id, locale)
);

CREATE TABLE IF NOT EXISTS media (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    storage_path TEXT NOT NULL UNIQUE,
    storage_backend TEXT NOT NULL CHECK (storage_backend IN ('supabase', 'local')),
    original_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes BIGINT NOT NULL CHECK (size_bytes > 0),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug TEXT NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
    year SMALLINT CHECK (year IS NULL OR year BETWEEN 1900 AND 2100),
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    sort_order INTEGER NOT NULL DEFAULT 0,
    external_url TEXT,
    video_media_id UUID REFERENCES media(id) ON DELETE SET NULL,
    poster_media_id UUID REFERENCES media(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS project_translations (
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    locale TEXT NOT NULL CHECK (locale IN ('en', 'ar', 'fr')),
    title TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    tools JSONB NOT NULL DEFAULT '[]'::JSONB CHECK (jsonb_typeof(tools) = 'array'),
    credits JSONB NOT NULL DEFAULT '[]'::JSONB CHECK (jsonb_typeof(credits) = 'array'),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (project_id, locale)
);

CREATE TABLE IF NOT EXISTS tags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug TEXT NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tag_translations (
    tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    locale TEXT NOT NULL CHECK (locale IN ('en', 'ar', 'fr')),
    name TEXT NOT NULL,
    PRIMARY KEY (tag_id, locale)
);

CREATE TABLE IF NOT EXISTS project_tags (
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    sort_order INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (project_id, tag_id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_auth (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    password_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_sessions (
    session_hash TEXT PRIMARY KEY CHECK (length(session_hash) = 64),
    csrf_hash TEXT NOT NULL CHECK (length(csrf_hash) = 64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_challenges (
    token_hash TEXT PRIMARY KEY CHECK (length(token_hash) = 64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS upload_sessions (
    id UUID PRIMARY KEY,
    filename TEXT NOT NULL,
    declared_mime TEXT NOT NULL,
    total_bytes BIGINT NOT NULL CHECK (total_bytes > 0),
    received_bytes BIGINT NOT NULL DEFAULT 0 CHECK (received_bytes >= 0 AND received_bytes <= total_bytes),
    chunk_path TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    details JSONB NOT NULL DEFAULT '{}'::JSONB CHECK (jsonb_typeof(details) = 'object'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS projects_public_order_idx ON projects (status, sort_order, created_at DESC);
CREATE INDEX IF NOT EXISTS project_translations_locale_idx ON project_translations (locale, project_id);
CREATE INDEX IF NOT EXISTS project_tags_order_idx ON project_tags (project_id, sort_order);
CREATE INDEX IF NOT EXISTS audit_log_created_idx ON audit_log (created_at DESC);
CREATE INDEX IF NOT EXISTS admin_sessions_expiry_idx ON admin_sessions (expires_at);
CREATE INDEX IF NOT EXISTS admin_challenges_expiry_idx ON admin_challenges (expires_at);
CREATE INDEX IF NOT EXISTS upload_sessions_expiry_idx ON upload_sessions (expires_at);

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'profile', 'profile_translations', 'projects', 'project_translations',
        'media', 'tags', 'tag_translations', 'project_tags', 'settings', 'admin_auth',
        'admin_sessions', 'admin_challenges', 'upload_sessions', 'audit_log'
    ] LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', table_name);
    END LOOP;
END $$;
