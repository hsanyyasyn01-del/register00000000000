use std::{
    collections::HashMap,
    net::SocketAddr,
    time::{Duration, Instant},
};

use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Algorithm, Argon2, Params, Version,
};
use axum::http::{header, HeaderMap};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use chrono::{Duration as ChronoDuration, Utc};
use rand::RngCore;
use sha2::{Digest, Sha256};
use sqlx::{PgPool, Row};
use subtle::ConstantTimeEq;
use tokio::sync::Mutex;

use crate::error::AppError;

const SESSION_COOKIE: &str = "__Host-arts-session";
const BOOTSTRAP_COOKIE: &str = "__Host-arts-bootstrap";
const SESSION_TTL: i64 = 12 * 60 * 60;
const CHALLENGE_TTL: i64 = 10 * 60;
const LOGIN_WINDOW: Duration = Duration::from_secs(15 * 60);
const LOGIN_LIMIT: usize = 5;

#[derive(Clone, Debug)]
pub struct BootstrapState {
    pub needs_setup: bool,
    pub authenticated: bool,
    pub csrf_token: String,
    pub set_cookie: String,
}

#[derive(Clone, Debug)]
pub struct LoginResult {
    pub csrf_token: String,
    pub set_cookie: String,
    pub clear_bootstrap_cookie: String,
}

#[derive(Clone, Debug)]
pub struct SessionContext {
    pub session_hash: String,
}

#[derive(Default)]
pub struct LoginLimiter {
    attempts: Mutex<HashMap<String, Vec<Instant>>>,
}

impl LoginLimiter {
    pub async fn allow(&self, remote: Option<SocketAddr>) -> bool {
        let key = remote
            .map(|address| hash_secret(&address.ip().to_string()))
            .unwrap_or_else(|| hash_secret("unknown-remote"));
        let now = Instant::now();
        let mut attempts = self.attempts.lock().await;
        let values = attempts.entry(key).or_default();
        values.retain(|time| now.duration_since(*time) < LOGIN_WINDOW);
        if values.len() >= LOGIN_LIMIT {
            return false;
        }
        values.push(now);
        true
    }
}

pub fn new_url_token() -> String {
    let mut bytes = [0_u8; 32];
    rand::rngs::OsRng.fill_bytes(&mut bytes);
    URL_SAFE_NO_PAD.encode(bytes)
}

pub fn hash_secret(value: &str) -> String {
    hex::encode(Sha256::digest(value.as_bytes()))
}

fn constant_time_equal(left: &str, right: &str) -> bool {
    left.as_bytes().ct_eq(right.as_bytes()).into()
}

pub async fn ensure_admin_token(pool: &PgPool, base_url: &str) -> Result<Option<String>, AppError> {
    let token = new_url_token();
    let result = sqlx::query("INSERT INTO settings (key, value) VALUES ('admin_token_hash', $1) ON CONFLICT (key) DO NOTHING")
        .bind(hash_secret(&token))
        .execute(pool)
        .await?;
    if result.rows_affected() == 1 {
        Ok(Some(format!(
            "{}/{}",
            base_url.trim_end_matches('/'),
            token
        )))
    } else {
        Ok(None)
    }
}

pub async fn rotate_admin_token(pool: &PgPool, base_url: &str) -> Result<String, AppError> {
    let token = new_url_token();
    sqlx::query(
        "INSERT INTO settings (key, value) VALUES ('admin_token_hash', $1) \
         ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()",
    )
    .bind(hash_secret(&token))
    .execute(pool)
    .await?;
    sqlx::query("DELETE FROM admin_sessions")
        .execute(pool)
        .await?;
    sqlx::query("DELETE FROM admin_challenges")
        .execute(pool)
        .await?;
    sqlx::query("INSERT INTO audit_log (action, entity_type, details) VALUES ('rotated', 'admin_token', '{}'::JSONB)")
        .execute(pool)
        .await?;
    Ok(format!("{}/{}", base_url.trim_end_matches('/'), token))
}

pub async fn verify_admin_token(pool: &PgPool, token: &str) -> Result<bool, AppError> {
    if token.len() != 43
        || !token
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_' || byte == b'-')
    {
        return Ok(false);
    }
    let stored = sqlx::query("SELECT value FROM settings WHERE key = 'admin_token_hash'")
        .fetch_optional(pool)
        .await?;
    let Some(row) = stored else {
        return Ok(false);
    };
    let saved: String = row.try_get("value")?;
    Ok(constant_time_equal(&hash_secret(token), &saved))
}

pub async fn bootstrap(pool: &PgPool, headers: &HeaderMap) -> Result<BootstrapState, AppError> {
    let password_hash = crate::db::admin_passphrase_hash(pool).await?;
    let needs_setup = password_hash.as_ref().is_none_or(String::is_empty);
    if let Some(session_token) = cookie_value(headers, SESSION_COOKIE) {
        let session_hash = hash_secret(session_token);
        let row = sqlx::query("SELECT expires_at FROM admin_sessions WHERE session_hash = $1")
            .bind(&session_hash)
            .fetch_optional(pool)
            .await?;
        if let Some(record) = row {
            let expires_at: chrono::DateTime<Utc> = record.try_get("expires_at")?;
            if expires_at > Utc::now() && !needs_setup {
                let csrf_token = new_url_token();
                sqlx::query("UPDATE admin_sessions SET csrf_hash = $2, expires_at = $3 WHERE session_hash = $1")
                    .bind(&session_hash)
                    .bind(hash_secret(&csrf_token))
                    .bind(Utc::now() + ChronoDuration::seconds(SESSION_TTL))
                    .execute(pool)
                    .await?;
                return Ok(BootstrapState {
                    needs_setup: false,
                    authenticated: true,
                    csrf_token,
                    set_cookie: String::new(),
                });
            }
            sqlx::query("DELETE FROM admin_sessions WHERE session_hash = $1")
                .bind(session_hash)
                .execute(pool)
                .await?;
        }
    }
    let csrf_token = new_url_token();
    sqlx::query("DELETE FROM admin_challenges WHERE expires_at <= $1")
        .bind(Utc::now())
        .execute(pool)
        .await?;
    sqlx::query("INSERT INTO admin_challenges (token_hash, expires_at) VALUES ($1, $2)")
        .bind(hash_secret(&csrf_token))
        .bind(Utc::now() + ChronoDuration::seconds(CHALLENGE_TTL))
        .execute(pool)
        .await?;
    Ok(BootstrapState {
        needs_setup,
        authenticated: false,
        csrf_token: csrf_token.clone(),
        set_cookie: cookie(BOOTSTRAP_COOKIE, &csrf_token, CHALLENGE_TTL),
    })
}

pub async fn setup_passphrase(
    pool: &PgPool,
    headers: &HeaderMap,
    passphrase: &str,
) -> Result<LoginResult, AppError> {
    validate_passphrase(passphrase)?;
    let challenge_hash = validate_challenge(pool, headers).await?;
    let password_hash = hash_passphrase(passphrase)?;
    let result = sqlx::query(
        "INSERT INTO admin_auth (id, password_hash) VALUES (1, $1) \
         ON CONFLICT (id) DO UPDATE SET password_hash = EXCLUDED.password_hash, updated_at = NOW() \
         WHERE admin_auth.password_hash IS NULL",
    )
    .bind(password_hash)
    .execute(pool)
    .await?;
    if result.rows_affected() != 1 {
        return Err(AppError::Conflict);
    }
    sqlx::query("DELETE FROM admin_challenges WHERE token_hash = $1")
        .bind(challenge_hash)
        .execute(pool)
        .await?;
    create_session(pool).await
}

pub async fn login(
    pool: &PgPool,
    headers: &HeaderMap,
    passphrase: &str,
    limiter: &LoginLimiter,
    remote: Option<SocketAddr>,
) -> Result<LoginResult, AppError> {
    if !limiter.allow(remote).await {
        return Err(AppError::TooManyRequests);
    }
    validate_passphrase(passphrase)?;
    let challenge_hash = validate_challenge(pool, headers).await?;
    let password_hash = crate::db::admin_passphrase_hash(pool)
        .await?
        .ok_or(AppError::Unauthorized)?;
    if !verify_passphrase(passphrase, &password_hash) {
        return Err(AppError::Unauthorized);
    }
    sqlx::query("DELETE FROM admin_challenges WHERE token_hash = $1")
        .bind(challenge_hash)
        .execute(pool)
        .await?;
    create_session(pool).await
}

pub async fn require_session(
    pool: &PgPool,
    headers: &HeaderMap,
    csrf_required: bool,
) -> Result<SessionContext, AppError> {
    let token = cookie_value(headers, SESSION_COOKIE).ok_or(AppError::Unauthorized)?;
    let session_hash = hash_secret(token);
    let row =
        sqlx::query("SELECT csrf_hash, expires_at FROM admin_sessions WHERE session_hash = $1")
            .bind(&session_hash)
            .fetch_optional(pool)
            .await?
            .ok_or(AppError::Unauthorized)?;
    let stored_csrf: String = row.try_get("csrf_hash")?;
    let expires_at: chrono::DateTime<Utc> = row.try_get("expires_at")?;
    if expires_at <= Utc::now() {
        sqlx::query("DELETE FROM admin_sessions WHERE session_hash = $1")
            .bind(&session_hash)
            .execute(pool)
            .await?;
        return Err(AppError::Unauthorized);
    }
    if csrf_required {
        verify_same_origin(headers)?;
        let supplied = headers
            .get("x-csrf-token")
            .and_then(|value| value.to_str().ok())
            .ok_or(AppError::Forbidden)?;
        if !constant_time_equal(&hash_secret(supplied), &stored_csrf) {
            return Err(AppError::Forbidden);
        }
    }
    Ok(SessionContext { session_hash })
}

pub async fn logout(pool: &PgPool, headers: &HeaderMap) -> Result<String, AppError> {
    let session = require_session(pool, headers, true).await?;
    sqlx::query("DELETE FROM admin_sessions WHERE session_hash = $1")
        .bind(session.session_hash)
        .execute(pool)
        .await?;
    Ok(clear_cookie(SESSION_COOKIE))
}

fn validate_passphrase(passphrase: &str) -> Result<(), AppError> {
    let count = passphrase.chars().count();
    if !(12..=128).contains(&count) || passphrase.len() > 512 {
        return Err(AppError::Validation);
    }
    Ok(())
}

fn hash_passphrase(passphrase: &str) -> Result<String, AppError> {
    let salt = SaltString::generate(&mut OsRng);
    let argon = Argon2::new(Algorithm::Argon2id, Version::V0x13, Params::default());
    argon
        .hash_password(passphrase.as_bytes(), &salt)
        .map(|hash| hash.to_string())
        .map_err(|_| AppError::Internal)
}

fn verify_passphrase(passphrase: &str, hash: &str) -> bool {
    let Ok(parsed) = PasswordHash::new(hash) else {
        return false;
    };
    Argon2::default()
        .verify_password(passphrase.as_bytes(), &parsed)
        .is_ok()
}

async fn validate_challenge(pool: &PgPool, headers: &HeaderMap) -> Result<String, AppError> {
    verify_same_origin(headers)?;
    let cookie_token = cookie_value(headers, BOOTSTRAP_COOKIE).ok_or(AppError::Forbidden)?;
    let supplied = headers
        .get("x-csrf-token")
        .and_then(|value| value.to_str().ok())
        .ok_or(AppError::Forbidden)?;
    if !constant_time_equal(cookie_token, supplied) {
        return Err(AppError::Forbidden);
    }
    let token_hash = hash_secret(supplied);
    let valid = sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS (SELECT 1 FROM admin_challenges WHERE token_hash = $1 AND expires_at > $2)",
    )
    .bind(&token_hash)
    .bind(Utc::now())
    .fetch_one(pool)
    .await?;
    if !valid {
        return Err(AppError::Forbidden);
    }
    Ok(token_hash)
}

fn verify_same_origin(headers: &HeaderMap) -> Result<(), AppError> {
    let origin = headers
        .get(header::ORIGIN)
        .and_then(|value| value.to_str().ok())
        .ok_or(AppError::Forbidden)?;
    let host = headers
        .get(header::HOST)
        .and_then(|value| value.to_str().ok())
        .ok_or(AppError::Forbidden)?;
    let parsed = url::Url::parse(origin).map_err(|_| AppError::Forbidden)?;
    if !matches!(parsed.scheme(), "https" | "http") {
        return Err(AppError::Forbidden);
    }
    let origin_host = parsed
        .host_str()
        .ok_or(AppError::Forbidden)?
        .to_ascii_lowercase();
    let origin_authority = parsed
        .port()
        .map_or(origin_host.clone(), |port| format!("{origin_host}:{port}"));
    if !constant_time_equal(&origin_authority, &host.to_ascii_lowercase()) {
        return Err(AppError::Forbidden);
    }
    Ok(())
}

async fn create_session(pool: &PgPool) -> Result<LoginResult, AppError> {
    let session_token = new_url_token();
    let csrf_token = new_url_token();
    let session_hash = hash_secret(&session_token);
    sqlx::query(
        "INSERT INTO admin_sessions (session_hash, csrf_hash, expires_at) VALUES ($1, $2, $3)",
    )
    .bind(session_hash)
    .bind(hash_secret(&csrf_token))
    .bind(Utc::now() + ChronoDuration::seconds(SESSION_TTL))
    .execute(pool)
    .await?;
    Ok(LoginResult {
        csrf_token,
        set_cookie: cookie(SESSION_COOKIE, &session_token, SESSION_TTL),
        clear_bootstrap_cookie: clear_cookie(BOOTSTRAP_COOKIE),
    })
}

fn cookie(name: &str, value: &str, max_age: i64) -> String {
    format!("{name}={value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age={max_age}")
}

fn clear_cookie(name: &str) -> String {
    format!("{name}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0")
}

fn cookie_value<'a>(headers: &'a HeaderMap, name: &str) -> Option<&'a str> {
    let raw = headers.get(header::COOKIE)?.to_str().ok()?;
    raw.split(';').find_map(|segment| {
        let (cookie_name, value) = segment.trim().split_once('=')?;
        (cookie_name == name).then_some(value)
    })
}

#[cfg(test)]
mod tests {
    use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};

    use super::{
        constant_time_equal, hash_passphrase, hash_secret, new_url_token, validate_passphrase,
        verify_passphrase,
    };

    #[test]
    fn generated_admin_tokens_have_at_least_256_random_bits_in_url_safe_encoding() {
        let first = new_url_token();
        let second = new_url_token();
        assert_eq!(first.len(), 43);
        assert!(first
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_' || byte == b'-'));
        assert_eq!(
            URL_SAFE_NO_PAD.decode(first).expect("token decodes").len(),
            32
        );
        assert_ne!(hash_secret(&new_url_token()), hash_secret(&second));
    }

    #[test]
    fn passphrase_validation_and_argon2id_verification_work() {
        assert!(validate_passphrase("short").is_err());
        assert!(validate_passphrase("this is a longer passphrase").is_ok());
        let hash = hash_passphrase("this is a longer passphrase").expect("hash succeeds");
        assert!(hash.starts_with("$argon2id$"));
        assert!(verify_passphrase("this is a longer passphrase", &hash));
        assert!(!verify_passphrase("different passphrase", &hash));
    }

    #[test]
    fn csrf_comparison_is_bound_to_the_supplied_token() {
        let token = new_url_token();
        let expected_hash = hash_secret(&token);
        assert!(constant_time_equal(&hash_secret(&token), &expected_hash));
        assert!(!constant_time_equal(&hash_secret("wrong"), &expected_hash));
        assert!(!constant_time_equal(&token, "short"));
    }
}
