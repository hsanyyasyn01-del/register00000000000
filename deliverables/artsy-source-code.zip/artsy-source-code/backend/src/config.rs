use std::{env, path::PathBuf};

#[derive(Clone)]
pub struct Config {
    pub database_url: String,
    pub port: u16,
    pub public_base_url: String,
    pub frontend_dist: PathBuf,
    pub data_dir: PathBuf,
    pub storage_bucket: String,
    pub supabase_url: Option<String>,
    pub supabase_service_key: Option<String>,
    pub max_upload_bytes: u64,
}

impl Config {
    pub fn from_env() -> Result<Self, String> {
        let database_url = required("DATABASE_URL")?;
        let port = optional("PORT")
            .unwrap_or_else(|| "8080".to_owned())
            .parse::<u16>()
            .map_err(|_| "PORT must be a valid TCP port".to_owned())?;
        if port == 0 {
            return Err("PORT must be between 1 and 65535".to_owned());
        }
        let public_base_url = optional("PUBLIC_BASE_URL")
            .unwrap_or_else(|| format!("http://localhost:{port}"))
            .trim_end_matches('/')
            .to_owned();
        let public_url = url::Url::parse(&public_base_url)
            .map_err(|_| "PUBLIC_BASE_URL must be an absolute HTTP or HTTPS URL".to_owned())?;
        if !matches!(public_url.scheme(), "http" | "https")
            || public_url.host_str().is_none()
            || !public_url.username().is_empty()
            || public_url.password().is_some()
            || public_url.query().is_some()
            || public_url.fragment().is_some()
            || !matches!(public_url.path(), "" | "/")
        {
            return Err(
                "PUBLIC_BASE_URL must be a site origin without credentials, query, or path"
                    .to_owned(),
            );
        }
        let frontend_dist =
            optional("FRONTEND_DIST").map_or_else(|| PathBuf::from("frontend/dist"), PathBuf::from);
        let data_dir = optional("DATA_DIR").map_or_else(|| PathBuf::from("data"), PathBuf::from);
        let storage_bucket =
            optional("SUPABASE_STORAGE_BUCKET").unwrap_or_else(|| "portfolio-media".to_owned());
        let supabase_url =
            optional("SUPABASE_URL").map(|value| value.trim_end_matches('/').to_owned());
        let supabase_service_key = optional("SUPABASE_SERVICE_KEY");
        if supabase_url.is_some() != supabase_service_key.is_some() {
            return Err("SUPABASE_URL and SUPABASE_SERVICE_KEY must be set together".to_owned());
        }
        if let Some(url) = &supabase_url {
            let parsed = url::Url::parse(url)
                .map_err(|_| "SUPABASE_URL must be an absolute HTTP or HTTPS URL".to_owned())?;
            if !matches!(parsed.scheme(), "http" | "https")
                || parsed.host_str().is_none()
                || !parsed.username().is_empty()
                || parsed.password().is_some()
                || parsed.query().is_some()
                || parsed.fragment().is_some()
                || !matches!(parsed.path(), "" | "/")
            {
                return Err(
                    "SUPABASE_URL must be a site origin without credentials, query, or path"
                        .to_owned(),
                );
            }
        }
        if storage_bucket.is_empty()
            || !storage_bucket
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || "-_".contains(c))
        {
            return Err("SUPABASE_STORAGE_BUCKET contains unsupported characters".to_owned());
        }
        let max_upload_bytes = optional("MAX_UPLOAD_BYTES")
            .unwrap_or_else(|| (1024_u64 * 1024 * 1024).to_string())
            .parse::<u64>()
            .map_err(|_| "MAX_UPLOAD_BYTES must be an unsigned integer".to_owned())?;
        if !(1_048_576..=10_u64 * 1024 * 1024 * 1024).contains(&max_upload_bytes) {
            return Err("MAX_UPLOAD_BYTES must be between 1 MiB and 10 GiB".to_owned());
        }
        Ok(Self {
            database_url,
            port,
            public_base_url,
            frontend_dist,
            data_dir,
            storage_bucket,
            supabase_url,
            supabase_service_key,
            max_upload_bytes,
        })
    }
}

fn required(key: &str) -> Result<String, String> {
    optional(key).ok_or_else(|| format!("{key} is required; set it in the environment or .env"))
}

fn optional(key: &str) -> Option<String> {
    env::var(key)
        .ok()
        .map(|value| value.trim().to_owned())
        .filter(|value| !value.is_empty())
}
