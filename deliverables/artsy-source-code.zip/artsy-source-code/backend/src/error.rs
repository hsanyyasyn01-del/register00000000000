use axum::{
    http::StatusCode,
    response::{IntoResponse, Response},
    Json,
};
use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum AppError {
    #[error("not found")]
    NotFound,
    #[error("invalid request")]
    BadRequest,
    #[error("invalid input")]
    Validation,
    #[error("authentication required")]
    Unauthorized,
    #[error("request rejected")]
    Forbidden,
    #[error("rate limit exceeded")]
    TooManyRequests,
    #[error("resource conflict")]
    Conflict,
    #[error("database operation failed")]
    Database(#[from] sqlx::Error),
    #[error("storage operation failed")]
    Storage,
    #[error("file operation failed")]
    Io(#[from] std::io::Error),
    #[error("invalid JSON")]
    Json(#[from] serde_json::Error),
    #[error("internal operation failed")]
    Internal,
}

#[derive(Serialize)]
struct ErrorEnvelope {
    error: ErrorPayload,
}

#[derive(Serialize)]
struct ErrorPayload {
    code: &'static str,
    message: &'static str,
}

impl AppError {
    fn status_code(&self) -> StatusCode {
        match self {
            Self::NotFound => StatusCode::NOT_FOUND,
            Self::BadRequest => StatusCode::BAD_REQUEST,
            Self::Validation => StatusCode::UNPROCESSABLE_ENTITY,
            Self::Unauthorized => StatusCode::UNAUTHORIZED,
            Self::Forbidden => StatusCode::FORBIDDEN,
            Self::TooManyRequests => StatusCode::TOO_MANY_REQUESTS,
            Self::Conflict => StatusCode::CONFLICT,
            Self::Database(_) | Self::Storage | Self::Io(_) | Self::Internal => {
                StatusCode::INTERNAL_SERVER_ERROR
            }
            Self::Json(_) => StatusCode::BAD_REQUEST,
        }
    }

    fn code(&self) -> &'static str {
        match self {
            Self::NotFound => "not_found",
            Self::BadRequest => "bad_request",
            Self::Validation => "validation_failed",
            Self::Unauthorized => "unauthorized",
            Self::Forbidden => "forbidden",
            Self::TooManyRequests => "rate_limited",
            Self::Conflict => "conflict",
            Self::Database(_) => "database_error",
            Self::Storage => "storage_error",
            Self::Io(_) => "io_error",
            Self::Json(_) => "invalid_json",
            Self::Internal => "internal_error",
        }
    }

    fn public_message(&self) -> &'static str {
        match self {
            Self::NotFound => "The requested resource was not found.",
            Self::BadRequest | Self::Json(_) => "The request could not be read.",
            Self::Validation => "One or more fields are invalid.",
            Self::Unauthorized => "Authentication is required.",
            Self::Forbidden => "The request was rejected.",
            Self::TooManyRequests => "Too many attempts. Try again later.",
            Self::Conflict => "The resource already exists or has changed.",
            Self::Database(_) | Self::Storage | Self::Io(_) | Self::Internal => {
                "The request could not be completed."
            }
        }
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let status = self.status_code();
        if status.is_server_error() {
            tracing::error!(code = self.code(), "request failed");
        }
        let body = ErrorEnvelope {
            error: ErrorPayload {
                code: self.code(),
                message: self.public_message(),
            },
        };
        (status, Json(body)).into_response()
    }
}
