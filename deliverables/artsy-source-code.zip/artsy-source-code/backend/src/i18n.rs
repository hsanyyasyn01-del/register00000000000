#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum Locale {
    En,
    Ar,
    Fr,
}

impl Locale {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::En => "en",
            Self::Ar => "ar",
            Self::Fr => "fr",
        }
    }

    pub const fn direction(self) -> &'static str {
        match self {
            Self::Ar => "rtl",
            Self::En | Self::Fr => "ltr",
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Candidate {
    locale: Option<Locale>,
    quality: f32,
    order: usize,
}

pub fn resolve_accept_language(header: Option<&str>) -> Locale {
    let Some(header) = header else {
        return Locale::En;
    };
    let mut candidates = header
        .split(',')
        .enumerate()
        .filter_map(|(order, item)| parse_candidate(item, order))
        .filter(|candidate| candidate.quality > 0.0)
        .collect::<Vec<_>>();
    candidates.sort_by(|left, right| {
        right
            .quality
            .total_cmp(&left.quality)
            .then_with(|| left.order.cmp(&right.order))
    });
    candidates
        .into_iter()
        .find_map(|candidate| candidate.locale)
        .unwrap_or(Locale::En)
}

fn parse_candidate(item: &str, order: usize) -> Option<Candidate> {
    let mut parts = item.trim().split(';');
    let tag = parts.next()?.trim();
    if tag.is_empty() {
        return None;
    }
    let mut quality = 1.0_f32;
    for parameter in parts {
        let Some((name, value)) = parameter.trim().split_once('=') else {
            continue;
        };
        if name.trim().eq_ignore_ascii_case("q") {
            let parsed = value.trim().parse::<f32>().ok()?;
            if !parsed.is_finite() || !(0.0..=1.0).contains(&parsed) {
                return None;
            }
            quality = parsed;
        }
    }
    let locale = if tag == "*" {
        None
    } else {
        let primary = tag.split('-').next()?.to_ascii_lowercase();
        match primary.as_str() {
            "en" => Some(Locale::En),
            "ar" => Some(Locale::Ar),
            "fr" => Some(Locale::Fr),
            _ => None,
        }
    };
    Some(Candidate {
        locale,
        quality,
        order,
    })
}

#[cfg(test)]
mod tests {
    use super::{resolve_accept_language, Locale};

    #[test]
    fn selects_supported_primary_subtag_by_quality() {
        assert_eq!(
            resolve_accept_language(Some("de-DE, fr-CA;q=0.8, ar-EG;q=0.95")),
            Locale::Ar
        );
        assert_eq!(
            resolve_accept_language(Some("zh, fr;q=0.7, en-US;q=0.6")),
            Locale::Fr
        );
        assert_eq!(
            resolve_accept_language(Some("en;q=0.4, fr;q=0.4")),
            Locale::En
        );
    }

    #[test]
    fn ignores_zero_invalid_and_out_of_range_quality_values() {
        assert_eq!(
            resolve_accept_language(Some("fr;q=0, ar;q=0.2")),
            Locale::Ar
        );
        assert_eq!(
            resolve_accept_language(Some("fr;q=NaN,ar;q=0.9")),
            Locale::Ar
        );
        assert_eq!(
            resolve_accept_language(Some("fr;q=1.1, en;q=-0.1")),
            Locale::En
        );
        assert_eq!(resolve_accept_language(Some("fr;q=wat")), Locale::En);
    }

    #[test]
    fn tolerates_empty_items_case_and_extra_parameters() {
        assert_eq!(
            resolve_accept_language(Some(",, FR-fr ; level=1; q=0.8, ar;q=0.2,")),
            Locale::Fr
        );
        assert_eq!(resolve_accept_language(Some("AR-eg;Q=0.7")), Locale::Ar);
        assert_eq!(resolve_accept_language(Some("en_US")), Locale::En);
    }

    #[test]
    fn falls_back_to_english_when_nothing_supported_is_acceptable() {
        assert_eq!(resolve_accept_language(None), Locale::En);
        assert_eq!(
            resolve_accept_language(Some("de-DE, es-ES, *;q=0.5")),
            Locale::En
        );
        assert_eq!(resolve_accept_language(Some("fr;q=0, ar;q=0")), Locale::En);
        assert_eq!(resolve_accept_language(Some("")), Locale::En);
    }
}
