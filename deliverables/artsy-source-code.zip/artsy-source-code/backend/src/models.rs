use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use uuid::Uuid;

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProfileTranslation {
    pub display_name: String,
    pub handle: String,
    pub tagline: String,
    pub bio: String,
    pub country: String,
    pub spoken_languages: Vec<String>,
    pub services: Vec<String>,
    pub skills: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProfileEditorData {
    pub contact_url: String,
    pub translations: BTreeMap<String, ProfileTranslation>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PublicProfile {
    pub contact_url: String,
    pub translations: BTreeMap<String, ProfileTranslation>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectTranslation {
    pub title: String,
    pub description: String,
    pub tools: Vec<String>,
    pub credits: Vec<String>,
    pub tags: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectEditorData {
    pub id: Option<Uuid>,
    pub slug: String,
    pub year: Option<i16>,
    pub status: String,
    pub sort_order: i32,
    pub video_media_id: Option<Uuid>,
    pub poster_media_id: Option<Uuid>,
    pub external_url: Option<String>,
    pub translations: BTreeMap<String, ProjectTranslation>,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PublicProject {
    pub id: Uuid,
    pub slug: String,
    pub year: Option<i16>,
    pub status: String,
    pub title: String,
    pub description: String,
    pub tools: Vec<String>,
    pub credits: Vec<String>,
    pub tags: Vec<String>,
    pub video_url: Option<String>,
    pub poster_url: Option<String>,
    pub external_url: Option<String>,
    pub sort_order: i32,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MediaItem {
    pub id: Uuid,
    pub filename: String,
    pub mime_type: String,
    pub size_bytes: i64,
    pub url: String,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AuditEntry {
    pub id: Uuid,
    pub action: String,
    pub entity_type: String,
    pub entity_id: Option<String>,
    pub details: Value,
    pub created_at: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PassphraseRequest {
    pub passphrase: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct UploadInitRequest {
    pub filename: String,
    pub mime_type: String,
    pub total_bytes: u64,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ReorderRequest {
    pub ids: Vec<Uuid>,
}
