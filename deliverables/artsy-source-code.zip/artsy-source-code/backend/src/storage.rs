use std::{
    path::{Path, PathBuf},
    time::Duration,
};

use reqwest::{header, Client, Response};
use serde::Serialize;
use tokio::{fs, io::AsyncReadExt};
use tokio_util::io::ReaderStream;
use url::Url;
use uuid::Uuid;

use crate::{config::Config, error::AppError};

#[derive(Clone)]
pub struct Storage {
    client: Client,
    root: PathBuf,
    supabase_url: Option<String>,
    service_key: Option<String>,
    bucket: String,
}

impl Storage {
    pub fn new(config: &Config) -> Result<Self, AppError> {
        let client = Client::builder()
            .connect_timeout(Duration::from_secs(10))
            .timeout(Duration::from_secs(60 * 60))
            .build()
            .map_err(|_| AppError::Internal)?;
        Ok(Self {
            client,
            root: config.data_dir.join("media"),
            supabase_url: config.supabase_url.clone(),
            service_key: config.supabase_service_key.clone(),
            bucket: config.storage_bucket.clone(),
        })
    }

    pub fn remote_enabled(&self) -> bool {
        self.supabase_url.is_some() && self.service_key.is_some()
    }

    pub async fn store_file(
        &self,
        storage_path: &str,
        source_path: &Path,
        mime_type: &str,
        size_bytes: u64,
    ) -> Result<&'static str, AppError> {
        if self.remote_enabled() {
            let url = self.object_url(storage_path)?;
            let file = fs::File::open(source_path).await?;
            let stream = ReaderStream::new(file);
            let size_header = header::HeaderValue::from_str(&size_bytes.to_string())
                .map_err(|_| AppError::Internal)?;
            let key = self.service_key.as_deref().ok_or(AppError::Storage)?;
            let response = self
                .client
                .post(url)
                .header(header::AUTHORIZATION, format!("Bearer {key}"))
                .header("apikey", key)
                .header(header::CONTENT_TYPE, mime_type)
                .header(header::CONTENT_LENGTH, size_header)
                .header("x-upsert", "false")
                .body(reqwest::Body::wrap_stream(stream))
                .send()
                .await
                .map_err(|_| AppError::Storage)?;
            if !response.status().is_success() {
                return Err(AppError::Storage);
            }
            Ok("supabase")
        } else {
            let target = self.local_path(storage_path)?;
            if let Some(parent) = target.parent() {
                fs::create_dir_all(parent).await?;
            }
            fs::copy(source_path, &target).await?;
            Ok("local")
        }
    }

    pub async fn delete(&self, storage_path: &str, backend: &str) -> Result<(), AppError> {
        if backend == "local" {
            let path = self.local_path(storage_path)?;
            match fs::remove_file(path).await {
                Ok(()) => Ok(()),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
                Err(error) => Err(AppError::Io(error)),
            }
        } else if backend == "supabase" {
            let base = self.base_url()?;
            let url = base
                .join(&format!("storage/v1/object/{}", self.bucket))
                .map_err(|_| AppError::Internal)?;
            let key = self.service_key.as_deref().ok_or(AppError::Storage)?;
            let response = self
                .client
                .delete(url)
                .header(header::AUTHORIZATION, format!("Bearer {key}"))
                .header("apikey", key)
                .json(&RemoveRequest {
                    prefixes: vec![storage_path],
                })
                .send()
                .await
                .map_err(|_| AppError::Storage)?;
            if response.status().is_success() || response.status() == reqwest::StatusCode::NOT_FOUND
            {
                Ok(())
            } else {
                Err(AppError::Storage)
            }
        } else {
            Err(AppError::Storage)
        }
    }

    pub async fn get_remote(
        &self,
        storage_path: &str,
        range: Option<&str>,
    ) -> Result<Response, AppError> {
        let url = self.object_url(storage_path)?;
        let key = self.service_key.as_deref().ok_or(AppError::Storage)?;
        let mut request = self
            .client
            .get(url)
            .header(header::AUTHORIZATION, format!("Bearer {key}"))
            .header("apikey", key);
        if let Some(range) = range {
            request = request.header(header::RANGE, range);
        }
        request.send().await.map_err(|_| AppError::Storage)
    }

    pub fn local_path(&self, storage_path: &str) -> Result<PathBuf, AppError> {
        if storage_path.is_empty()
            || storage_path.starts_with('/')
            || storage_path
                .split('/')
                .any(|segment| segment.is_empty() || segment == "." || segment == "..")
            || !storage_path
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || b"/-_.".contains(&byte))
        {
            return Err(AppError::BadRequest);
        }
        Ok(self.root.join(storage_path))
    }

    fn object_url(&self, storage_path: &str) -> Result<Url, AppError> {
        let mut url = self.base_url()?;
        {
            let mut segments = url.path_segments_mut().map_err(|_| AppError::Internal)?;
            segments.pop_if_empty();
            segments.push("storage");
            segments.push("v1");
            segments.push("object");
            segments.push(&self.bucket);
            for segment in storage_path.split('/') {
                if segment.is_empty() || segment == "." || segment == ".." {
                    return Err(AppError::BadRequest);
                }
                segments.push(segment);
            }
        }
        Ok(url)
    }

    fn base_url(&self) -> Result<Url, AppError> {
        Url::parse(self.supabase_url.as_deref().ok_or(AppError::Storage)?)
            .map_err(|_| AppError::Internal)
    }
}

#[derive(Serialize)]
struct RemoveRequest<'a> {
    prefixes: Vec<&'a str>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum VerifiedMediaType {
    Mp4,
    Webm,
    QuickTime,
    Png,
    Jpeg,
    Webp,
}

impl VerifiedMediaType {
    pub const fn mime(self) -> &'static str {
        match self {
            Self::Mp4 => "video/mp4",
            Self::Webm => "video/webm",
            Self::QuickTime => "video/quicktime",
            Self::Png => "image/png",
            Self::Jpeg => "image/jpeg",
            Self::Webp => "image/webp",
        }
    }

    pub const fn extension(self) -> &'static str {
        match self {
            Self::Mp4 => "mp4",
            Self::Webm => "webm",
            Self::QuickTime => "mov",
            Self::Png => "png",
            Self::Jpeg => "jpg",
            Self::Webp => "webp",
        }
    }

    pub const fn is_video(self) -> bool {
        matches!(self, Self::Mp4 | Self::Webm | Self::QuickTime)
    }
}

pub fn sniff_media_type(header_bytes: &[u8]) -> Option<VerifiedMediaType> {
    if header_bytes.starts_with(&[0x1A, 0x45, 0xDF, 0xA3]) {
        return Some(VerifiedMediaType::Webm);
    }
    if header_bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        return Some(VerifiedMediaType::Png);
    }
    if header_bytes.starts_with(&[0xFF, 0xD8, 0xFF]) {
        return Some(VerifiedMediaType::Jpeg);
    }
    if header_bytes.len() >= 12 && &header_bytes[0..4] == b"RIFF" && &header_bytes[8..12] == b"WEBP"
    {
        return Some(VerifiedMediaType::Webp);
    }
    if header_bytes.len() >= 12 && &header_bytes[4..8] == b"ftyp" {
        if header_bytes.get(8..12) == Some(b"qt  ") {
            return Some(VerifiedMediaType::QuickTime);
        }
        return Some(VerifiedMediaType::Mp4);
    }
    None
}

pub fn validate_upload_request(
    filename: &str,
    mime_type: &str,
    total_bytes: u64,
    max_bytes: u64,
) -> Result<(), AppError> {
    if filename.trim().is_empty()
        || filename.len() > 240
        || filename.chars().any(char::is_control)
        || total_bytes == 0
        || total_bytes > max_bytes
        || !matches!(
            mime_type,
            "video/mp4"
                | "video/webm"
                | "video/quicktime"
                | "image/png"
                | "image/jpeg"
                | "image/webp"
                | "application/octet-stream"
        )
    {
        return Err(AppError::Validation);
    }
    Ok(())
}

pub fn make_storage_path(media_type: VerifiedMediaType, id: Uuid) -> String {
    let folder = if media_type.is_video() {
        "video"
    } else {
        "image"
    };
    format!("{folder}/{id}.{}", media_type.extension())
}

pub async fn sha256_file(path: &Path) -> Result<String, AppError> {
    use sha2::{Digest, Sha256};
    let mut file = fs::File::open(path).await?;
    let mut hasher = Sha256::new();
    let mut buffer = vec![0_u8; 128 * 1024];
    loop {
        let read = file.read(&mut buffer).await?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
    }
    Ok(hex::encode(hasher.finalize()))
}

#[cfg(test)]
mod tests {
    use super::{make_storage_path, sniff_media_type, validate_upload_request, VerifiedMediaType};
    use uuid::Uuid;

    #[test]
    fn upload_checks_size_name_and_declared_type() {
        assert!(validate_upload_request("edit.mp4", "video/mp4", 1024, 4096).is_ok());
        assert!(validate_upload_request("", "video/mp4", 1024, 4096).is_err());
        assert!(
            validate_upload_request("edit.exe", "application/x-msdownload", 1024, 4096).is_err()
        );
        assert!(validate_upload_request("edit.mp4", "video/mp4", 4097, 4096).is_err());
        assert!(validate_upload_request("edit.mp4", "video/mp4", 0, 4096).is_err());
    }

    #[test]
    fn verifies_actual_container_signatures_not_extensions() {
        assert_eq!(
            sniff_media_type(b"\x00\x00\x00\x18ftypisom"),
            Some(VerifiedMediaType::Mp4)
        );
        assert_eq!(
            sniff_media_type(b"\x00\x00\x00\x18ftypqt  "),
            Some(VerifiedMediaType::QuickTime)
        );
        assert_eq!(
            sniff_media_type(b"\x1A\x45\xDF\xA3\x93"),
            Some(VerifiedMediaType::Webm)
        );
        assert_eq!(
            sniff_media_type(b"\x89PNG\r\n\x1a\n"),
            Some(VerifiedMediaType::Png)
        );
        assert_eq!(
            sniff_media_type(b"\xFF\xD8\xFF\xAA"),
            Some(VerifiedMediaType::Jpeg)
        );
        assert_eq!(
            sniff_media_type(b"RIFF\x00\x00\x00\x00WEBP"),
            Some(VerifiedMediaType::Webp)
        );
        assert_eq!(sniff_media_type(b"this is not a video"), None);
    }

    #[test]
    fn media_paths_are_generated_from_detected_type_and_uuid() {
        let id = Uuid::nil();
        assert_eq!(
            make_storage_path(VerifiedMediaType::Mp4, id),
            "video/00000000-0000-0000-0000-000000000000.mp4"
        );
        assert_eq!(
            make_storage_path(VerifiedMediaType::Webp, id),
            "image/00000000-0000-0000-0000-000000000000.webp"
        );
    }
}
