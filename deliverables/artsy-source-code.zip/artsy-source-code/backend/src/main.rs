mod auth;
mod config;
mod db;
mod error;
mod i18n;
mod models;
mod routes;
mod state;
mod storage;

use std::{env, net::SocketAddr};

use config::Config;
use sqlx::PgPool;
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let _ = dotenvy::dotenv();
    init_tracing();
    let config = Config::from_env().map_err(|message| format!("configuration error: {message}"))?;
    let command = env::args().nth(1).unwrap_or_else(|| "serve".to_owned());
    let pool = connect_and_migrate(&config).await?;

    match command.as_str() {
        "seed" => {
            db::seed(&pool).await.map_err(|_| "database seed failed")?;
            println!("Seed data is present.");
            Ok(())
        }
        "admin-rotate" => {
            let url = auth::rotate_admin_token(&pool, &config.public_base_url).await?;
            println!("Admin URL: {url}");
            Ok(())
        }
        "serve" => serve(config, pool).await,
        _ => Err("usage: portfolio-server [serve|seed|admin-rotate]".into()),
    }
}

async fn connect_and_migrate(config: &Config) -> Result<PgPool, Box<dyn std::error::Error>> {
    let pool = db::connect(config)
        .await
        .map_err(|_| "database connection failed; check DATABASE_URL and network access")?;
    db::migrate(&pool)
        .await
        .map_err(|_| "database migrations failed")?;
    Ok(pool)
}

async fn serve(config: Config, pool: PgPool) -> Result<(), Box<dyn std::error::Error>> {
    db::seed(&pool).await.map_err(|_| "database seed failed")?;
    let state = state::AppState::new(config, pool)?;
    routes::cleanup_orphaned_uploads(&state).await?;
    if let Some(url) = auth::ensure_admin_token(&state.pool, &state.config.public_base_url).await? {
        println!("Admin URL: {url}");
    }
    let address = SocketAddr::from(([0, 0, 0, 0], state.config.port));
    let listener = tokio::net::TcpListener::bind(address).await?;
    tracing::info!(port = state.config.port, "portfolio server listening");
    axum::serve(
        listener,
        routes::build_router(state).into_make_service_with_connect_info::<SocketAddr>(),
    )
    .with_graceful_shutdown(shutdown_signal())
    .await?;
    Ok(())
}

async fn shutdown_signal() {
    if let Err(error) = tokio::signal::ctrl_c().await {
        tracing::error!(%error, "failed to listen for shutdown signal");
    }
    tracing::info!("shutdown signal received");
}

fn init_tracing() {
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));
    tracing_subscriber::fmt()
        .with_env_filter(filter)
        .json()
        .with_current_span(false)
        .with_span_list(false)
        .init();
}
