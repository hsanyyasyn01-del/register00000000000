use std::sync::Arc;

use sqlx::PgPool;

use crate::{auth::LoginLimiter, config::Config, error::AppError, storage::Storage};

#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    pub config: Arc<Config>,
    pub storage: Storage,
    pub login_limiter: Arc<LoginLimiter>,
}

impl AppState {
    pub fn new(config: Config, pool: PgPool) -> Result<Self, AppError> {
        let storage = Storage::new(&config)?;
        Ok(Self {
            pool,
            config: Arc::new(config),
            storage,
            login_limiter: Arc::new(LoginLimiter::default()),
        })
    }
}
