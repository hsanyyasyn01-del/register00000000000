use std::collections::{BTreeMap, HashSet};

use chrono::{Duration, Utc};
use serde_json::{json, Value};
use sqlx::{migrate::Migrator, postgres::PgPoolOptions, PgPool, Row};
use uuid::Uuid;

use crate::{
    config::Config,
    error::AppError,
    i18n::Locale,
    models::{
        AuditEntry, MediaItem, ProfileEditorData, ProfileTranslation, ProjectEditorData,
        ProjectTranslation, PublicProfile, PublicProject,
    },
};

static MIGRATOR: Migrator = sqlx::migrate!("./migrations");
const SEED_SQL: &str = include_str!("../seed/seed.sql");
const LOCALES: [&str; 3] = ["en", "ar", "fr"];

pub async fn connect(config: &Config) -> Result<PgPool, sqlx::Error> {
    PgPoolOptions::new()
        .max_connections(12)
        .acquire_timeout(std::time::Duration::from_secs(10))
        .connect(&config.database_url)
        .await
}

pub async fn migrate(pool: &PgPool) -> Result<(), sqlx::migrate::MigrateError> {
    MIGRATOR.run(pool).await
}

pub async fn seed(pool: &PgPool) -> Result<(), sqlx::Error> {
    sqlx::raw_sql(SEED_SQL).execute(pool).await?;
    Ok(())
}

pub async fn fetch_profile_editor(pool: &PgPool) -> Result<ProfileEditorData, AppError> {
    let profile = sqlx::query("SELECT contact_url FROM profile WHERE id = 1")
        .fetch_optional(pool)
        .await?
        .ok_or(AppError::NotFound)?;
    let contact_url: String = profile.try_get("contact_url")?;
    let rows = sqlx::query(
        "SELECT locale, display_name, handle, tagline, bio, country, spoken_languages, services, skills \
         FROM profile_translations WHERE profile_id = 1 ORDER BY locale",
    )
    .fetch_all(pool)
    .await?;
    let mut translations = BTreeMap::new();
    for row in rows {
        let locale: String = row.try_get("locale")?;
        let translation = ProfileTranslation {
            display_name: row.try_get("display_name")?,
            handle: row.try_get("handle")?,
            tagline: row.try_get("tagline")?,
            bio: row.try_get("bio")?,
            country: row.try_get("country")?,
            spoken_languages: json_value(row.try_get("spoken_languages")?)?,
            services: json_value(row.try_get("services")?)?,
            skills: json_value(row.try_get("skills")?)?,
        };
        translations.insert(locale, translation);
    }
    Ok(ProfileEditorData {
        contact_url,
        translations,
    })
}

pub async fn fetch_public_profile(
    pool: &PgPool,
    locale: Locale,
) -> Result<PublicProfile, AppError> {
    let profile = fetch_profile_editor(pool).await?;
    let mut translations = BTreeMap::new();
    if let Some(english) = profile.translations.get("en") {
        translations.insert("en".to_owned(), english.clone());
    }
    if locale != Locale::En {
        if let Some(translation) = profile.translations.get(locale.as_str()) {
            translations.insert(locale.as_str().to_owned(), translation.clone());
        }
    }
    Ok(PublicProfile {
        contact_url: profile.contact_url,
        translations,
    })
}

pub async fn save_profile(
    pool: &PgPool,
    data: &ProfileEditorData,
) -> Result<ProfileEditorData, AppError> {
    validate_profile(data)?;
    let mut transaction = pool.begin().await?;
    sqlx::query(
        "INSERT INTO profile (id, contact_url, updated_at) VALUES (1, $1, NOW()) \
         ON CONFLICT (id) DO UPDATE SET contact_url = EXCLUDED.contact_url, updated_at = NOW()",
    )
    .bind(&data.contact_url)
    .execute(&mut *transaction)
    .await?;
    for locale in LOCALES {
        let translation = data.translations.get(locale).ok_or(AppError::Validation)?;
        sqlx::query(
            "INSERT INTO profile_translations (profile_id, locale, display_name, handle, tagline, bio, country, spoken_languages, services, skills, updated_at) \
             VALUES (1, $1, $2, $3, $4, $5, $6, $7, $8, $9, NOW()) \
             ON CONFLICT (profile_id, locale) DO UPDATE SET \
             display_name = EXCLUDED.display_name, handle = EXCLUDED.handle, tagline = EXCLUDED.tagline, \
             bio = EXCLUDED.bio, country = EXCLUDED.country, spoken_languages = EXCLUDED.spoken_languages, \
             services = EXCLUDED.services, skills = EXCLUDED.skills, updated_at = NOW()",
        )
        .bind(locale)
        .bind(&translation.display_name)
        .bind(&translation.handle)
        .bind(&translation.tagline)
        .bind(&translation.bio)
        .bind(&translation.country)
        .bind(json!(translation.spoken_languages))
        .bind(json!(translation.services))
        .bind(json!(translation.skills))
        .execute(&mut *transaction)
        .await?;
    }
    transaction.commit().await?;
    record_audit(pool, "updated", "profile", Some("1"), json!({})).await?;
    fetch_profile_editor(pool).await
}

fn validate_profile(data: &ProfileEditorData) -> Result<(), AppError> {
    if data.contact_url.len() > 500
        || !valid_optional_http_url(&data.contact_url)
        || data.translations.len() != LOCALES.len()
        || data
            .translations
            .keys()
            .any(|locale| !LOCALES.contains(&locale.as_str()))
    {
        return Err(AppError::Validation);
    }
    for locale in LOCALES {
        let translation = data.translations.get(locale).ok_or(AppError::Validation)?;
        if translation.display_name.trim().is_empty()
            || translation.display_name.len() > 120
            || translation.handle.len() > 120
            || translation.tagline.len() > 220
            || translation.bio.len() > 3000
            || translation.country.len() > 120
            || translation.spoken_languages.len() > 20
            || translation.services.len() > 40
            || translation.skills.len() > 40
            || translation
                .spoken_languages
                .iter()
                .any(|item| item.trim().is_empty() || item.len() > 80)
            || translation
                .services
                .iter()
                .chain(&translation.skills)
                .any(|item| item.trim().is_empty() || item.len() > 120)
        {
            return Err(AppError::Validation);
        }
    }
    Ok(())
}

fn valid_optional_http_url(value: &str) -> bool {
    if value.is_empty() {
        return true;
    }
    url::Url::parse(value)
        .map(|url| matches!(url.scheme(), "https" | "http") && url.host_str().is_some())
        .unwrap_or(false)
}

pub async fn fetch_project_editors(pool: &PgPool) -> Result<Vec<ProjectEditorData>, AppError> {
    let rows = sqlx::query(
        "SELECT id, slug, year, status, sort_order, external_url, video_media_id, poster_media_id \
         FROM projects ORDER BY sort_order, created_at DESC",
    )
    .fetch_all(pool)
    .await?;
    let mut projects = Vec::with_capacity(rows.len());
    for row in rows {
        let id: Uuid = row.try_get("id")?;
        let translation_rows = sqlx::query(
            "SELECT translation.locale, translation.title, translation.description, translation.tools, translation.credits, \
             COALESCE(ARRAY(SELECT COALESCE(tag_translation.name, tag.name) \
                 FROM project_tags project_tag JOIN tags tag ON tag.id = project_tag.tag_id \
                 LEFT JOIN tag_translations tag_translation ON tag_translation.tag_id = tag.id \
                     AND tag_translation.locale = translation.locale \
                 WHERE project_tag.project_id = translation.project_id \
                 ORDER BY project_tag.sort_order, tag.slug), ARRAY[]::TEXT[]) AS tags \
             FROM project_translations translation WHERE translation.project_id = $1 ORDER BY translation.locale",
        )
        .bind(id)
        .fetch_all(pool)
        .await?;
        let mut translations = BTreeMap::new();
        for translation_row in translation_rows {
            let locale: String = translation_row.try_get("locale")?;
            translations.insert(
                locale,
                ProjectTranslation {
                    title: translation_row.try_get("title")?,
                    description: translation_row.try_get("description")?,
                    tools: json_value(translation_row.try_get("tools")?)?,
                    credits: json_value(translation_row.try_get("credits")?)?,
                    tags: translation_row.try_get("tags")?,
                },
            );
        }
        projects.push(ProjectEditorData {
            id: Some(id),
            slug: row.try_get("slug")?,
            year: row.try_get("year")?,
            status: row.try_get("status")?,
            sort_order: row.try_get("sort_order")?,
            video_media_id: row.try_get("video_media_id")?,
            poster_media_id: row.try_get("poster_media_id")?,
            external_url: row.try_get("external_url")?,
            translations,
        });
    }
    Ok(projects)
}

pub async fn fetch_public_projects(
    pool: &PgPool,
    locale: Locale,
    slug: Option<&str>,
) -> Result<Vec<PublicProject>, AppError> {
    let rows = sqlx::query(
        "SELECT p.id, p.slug, p.year, p.status, p.sort_order, p.external_url, \
         p.video_media_id, p.poster_media_id, \
         COALESCE(NULLIF(req.title, ''), NULLIF(en.title, ''), '') AS title, \
         COALESCE(NULLIF(req.description, ''), NULLIF(en.description, ''), '') AS description, \
         COALESCE(req.tools, en.tools, '[]'::JSONB) AS tools, \
         COALESCE(req.credits, en.credits, '[]'::JSONB) AS credits, \
         COALESCE(ARRAY(SELECT COALESCE(tag_translation.name, tag.name) \
             FROM project_tags project_tag JOIN tags tag ON tag.id = project_tag.tag_id \
             LEFT JOIN tag_translations tag_translation ON tag_translation.tag_id = tag.id \
                 AND tag_translation.locale = COALESCE(req.locale, en.locale, 'en') \
             WHERE project_tag.project_id = p.id \
             ORDER BY project_tag.sort_order, tag.slug), ARRAY[]::TEXT[]) AS tags \
         FROM projects p \
         LEFT JOIN project_translations req ON req.project_id = p.id AND req.locale = $1 \
         LEFT JOIN project_translations en ON en.project_id = p.id AND en.locale = 'en' \
         WHERE p.status = 'published' AND ($2::TEXT IS NULL OR p.slug = $2) \
         ORDER BY p.sort_order, p.created_at DESC",
    )
    .bind(locale.as_str())
    .bind(slug)
    .fetch_all(pool)
    .await?;
    let mut projects = Vec::with_capacity(rows.len());
    for row in rows {
        let id: Uuid = row.try_get("id")?;
        let video_id: Option<Uuid> = row.try_get("video_media_id")?;
        let poster_id: Option<Uuid> = row.try_get("poster_media_id")?;
        projects.push(PublicProject {
            id,
            slug: row.try_get("slug")?,
            year: row.try_get("year")?,
            status: row.try_get("status")?,
            sort_order: row.try_get("sort_order")?,
            title: row.try_get("title")?,
            description: row.try_get("description")?,
            tools: json_value(row.try_get("tools")?)?,
            credits: json_value(row.try_get("credits")?)?,
            tags: row.try_get("tags")?,
            video_url: video_id.map(|media_id| format!("/media/{media_id}")),
            poster_url: poster_id.map(|media_id| format!("/media/{media_id}")),
            external_url: row.try_get("external_url")?,
        });
    }
    Ok(projects)
}

pub async fn save_project(
    pool: &PgPool,
    data: &ProjectEditorData,
) -> Result<ProjectEditorData, AppError> {
    validate_project(data)?;
    let mut transaction = pool.begin().await?;
    let id = if let Some(id) = data.id {
        let result = sqlx::query(
            "UPDATE projects SET slug = $2, year = $3, status = $4, sort_order = $5, \
             external_url = $6, video_media_id = $7, poster_media_id = $8, updated_at = NOW() WHERE id = $1",
        )
        .bind(id)
        .bind(&data.slug)
        .bind(data.year)
        .bind(&data.status)
        .bind(data.sort_order)
        .bind(&data.external_url)
        .bind(data.video_media_id)
        .bind(data.poster_media_id)
        .execute(&mut *transaction)
        .await?;
        if result.rows_affected() != 1 {
            return Err(AppError::NotFound);
        }
        id
    } else {
        sqlx::query_scalar::<_, Uuid>(
            "INSERT INTO projects (slug, year, status, sort_order, external_url, video_media_id, poster_media_id) \
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id",
        )
        .bind(&data.slug)
        .bind(data.year)
        .bind(&data.status)
        .bind(data.sort_order)
        .bind(&data.external_url)
        .bind(data.video_media_id)
        .bind(data.poster_media_id)
        .fetch_one(&mut *transaction)
        .await?
    };

    for locale in LOCALES {
        let translation = data.translations.get(locale).ok_or(AppError::Validation)?;
        sqlx::query(
            "INSERT INTO project_translations (project_id, locale, title, description, tools, credits, updated_at) \
             VALUES ($1, $2, $3, $4, $5, $6, NOW()) \
             ON CONFLICT (project_id, locale) DO UPDATE SET title = EXCLUDED.title, \
             description = EXCLUDED.description, tools = EXCLUDED.tools, credits = EXCLUDED.credits, updated_at = NOW()",
        )
        .bind(id)
        .bind(locale)
        .bind(&translation.title)
        .bind(&translation.description)
        .bind(json!(translation.tools))
        .bind(json!(translation.credits))
        .execute(&mut *transaction)
        .await?;
    }

    sqlx::query("DELETE FROM project_tags WHERE project_id = $1")
        .bind(id)
        .execute(&mut *transaction)
        .await?;
    let english_tags = &data
        .translations
        .get("en")
        .ok_or(AppError::Validation)?
        .tags;
    for (index, english_name) in english_tags.iter().enumerate() {
        let slug = tag_slug(english_name).ok_or(AppError::Validation)?;
        let tag_id = sqlx::query_scalar::<_, Uuid>(
            "INSERT INTO tags (slug, name) VALUES ($1, $2) \
             ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name RETURNING id",
        )
        .bind(slug)
        .bind(english_name.trim())
        .fetch_one(&mut *transaction)
        .await?;
        sqlx::query(
            "INSERT INTO project_tags (project_id, tag_id, sort_order) VALUES ($1, $2, $3) \
             ON CONFLICT (project_id, tag_id) DO UPDATE SET sort_order = EXCLUDED.sort_order",
        )
        .bind(id)
        .bind(tag_id)
        .bind(i32::try_from(index).map_err(|_| AppError::Validation)?)
        .execute(&mut *transaction)
        .await?;
        for locale in LOCALES {
            let name = data
                .translations
                .get(locale)
                .and_then(|translation| translation.tags.get(index))
                .ok_or(AppError::Validation)?;
            sqlx::query(
                "INSERT INTO tag_translations (tag_id, locale, name) VALUES ($1, $2, $3) \
                 ON CONFLICT (tag_id, locale) DO UPDATE SET name = EXCLUDED.name",
            )
            .bind(tag_id)
            .bind(locale)
            .bind(name.trim())
            .execute(&mut *transaction)
            .await?;
        }
    }
    sqlx::query(
        "DELETE FROM tags tag WHERE NOT EXISTS (SELECT 1 FROM project_tags project_tag WHERE project_tag.tag_id = tag.id)",
    )
    .execute(&mut *transaction)
    .await?;
    transaction.commit().await?;
    record_audit(
        pool,
        if data.id.is_some() {
            "updated"
        } else {
            "created"
        },
        "project",
        Some(&id.to_string()),
        json!({"slug": data.slug, "status": data.status}),
    )
    .await?;
    fetch_project_editors(pool)
        .await?
        .into_iter()
        .find(|project| project.id == Some(id))
        .ok_or(AppError::Internal)
}

fn validate_project(data: &ProjectEditorData) -> Result<(), AppError> {
    if data.slug.is_empty()
        || data.slug.len() > 80
        || !data
            .slug
            .chars()
            .all(|ch| ch.is_ascii_lowercase() || ch.is_ascii_digit() || ch == '-')
        || data.slug.starts_with('-')
        || data.slug.ends_with('-')
        || data.slug.contains("--")
        || !matches!(data.status.as_str(), "draft" | "published")
        || data.year.is_some_and(|year| !(1900..=2100).contains(&year))
        || data.sort_order < 0
        || data.translations.len() != LOCALES.len()
        || data
            .translations
            .keys()
            .any(|locale| !LOCALES.contains(&locale.as_str()))
        || data
            .external_url
            .as_ref()
            .is_some_and(|value| !valid_optional_http_url(value) || value.len() > 500)
    {
        return Err(AppError::Validation);
    }
    let english_tags = &data
        .translations
        .get("en")
        .ok_or(AppError::Validation)?
        .tags;
    let mut tag_slugs = HashSet::new();
    for name in english_tags {
        let slug = tag_slug(name).ok_or(AppError::Validation)?;
        if !tag_slugs.insert(slug) {
            return Err(AppError::Validation);
        }
    }
    for locale in LOCALES {
        let translation = data.translations.get(locale).ok_or(AppError::Validation)?;
        if translation.title.trim().is_empty()
            || translation.title.len() > 180
            || translation.description.len() > 5000
            || translation.tools.len() > 40
            || translation.credits.len() > 40
            || translation.tags.len() != english_tags.len()
            || translation
                .tools
                .iter()
                .chain(&translation.credits)
                .chain(&translation.tags)
                .any(|value| value.trim().is_empty() || value.len() > 120)
        {
            return Err(AppError::Validation);
        }
    }
    Ok(())
}

fn tag_slug(value: &str) -> Option<String> {
    let mut slug = String::new();
    let mut separator = false;
    for ch in value.trim().to_ascii_lowercase().chars() {
        if ch.is_ascii_alphanumeric() {
            if separator && !slug.is_empty() {
                slug.push('-');
            }
            slug.push(ch);
            separator = false;
        } else {
            separator = true;
        }
    }
    (!slug.is_empty()).then_some(slug)
}

pub async fn delete_project(pool: &PgPool, id: Uuid) -> Result<(), AppError> {
    let result = sqlx::query("DELETE FROM projects WHERE id = $1")
        .bind(id)
        .execute(pool)
        .await?;
    if result.rows_affected() == 0 {
        return Err(AppError::NotFound);
    }
    record_audit(pool, "deleted", "project", Some(&id.to_string()), json!({})).await?;
    Ok(())
}

pub async fn reorder_projects(pool: &PgPool, ids: &[Uuid]) -> Result<(), AppError> {
    if ids.len() > 1000 || ids.iter().collect::<HashSet<_>>().len() != ids.len() {
        return Err(AppError::Validation);
    }
    let mut transaction = pool.begin().await?;
    let current_rows = sqlx::query("SELECT id FROM projects ORDER BY sort_order, created_at DESC")
        .fetch_all(&mut *transaction)
        .await?;
    let current = current_rows
        .into_iter()
        .map(|row| row.try_get::<Uuid, _>("id"))
        .collect::<Result<HashSet<_>, _>>()?;
    if current.len() != ids.len() || ids.iter().any(|id| !current.contains(id)) {
        return Err(AppError::Validation);
    }
    for (index, id) in ids.iter().enumerate() {
        sqlx::query("UPDATE projects SET sort_order = $2, updated_at = NOW() WHERE id = $1")
            .bind(id)
            .bind(i32::try_from(index).map_err(|_| AppError::Validation)?)
            .execute(&mut *transaction)
            .await?;
    }
    transaction.commit().await?;
    record_audit(
        pool,
        "reordered",
        "projects",
        None,
        json!({"count": ids.len()}),
    )
    .await?;
    Ok(())
}

pub async fn list_media(pool: &PgPool) -> Result<Vec<MediaItem>, AppError> {
    let rows = sqlx::query(
        "SELECT id, original_name, mime_type, size_bytes FROM media ORDER BY created_at DESC",
    )
    .fetch_all(pool)
    .await?;
    rows.into_iter()
        .map(|row| {
            let id: Uuid = row.try_get("id")?;
            Ok(MediaItem {
                id,
                filename: row.try_get("original_name")?,
                mime_type: row.try_get("mime_type")?,
                size_bytes: row.try_get("size_bytes")?,
                url: format!("/media/{id}"),
            })
        })
        .collect()
}

pub async fn record_audit(
    pool: &PgPool,
    action: &str,
    entity_type: &str,
    entity_id: Option<&str>,
    details: Value,
) -> Result<(), AppError> {
    sqlx::query(
        "INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES ($1, $2, $3, $4)",
    )
    .bind(action)
    .bind(entity_type)
    .bind(entity_id)
    .bind(details)
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn fetch_audit(pool: &PgPool) -> Result<Vec<AuditEntry>, AppError> {
    let rows = sqlx::query(
        "SELECT id, action, entity_type, entity_id, details, created_at FROM audit_log ORDER BY created_at DESC LIMIT 100",
    )
    .fetch_all(pool)
    .await?;
    rows.into_iter()
        .map(|row| {
            let created_at: chrono::DateTime<Utc> = row.try_get("created_at")?;
            Ok(AuditEntry {
                id: row.try_get("id")?,
                action: row.try_get("action")?,
                entity_type: row.try_get("entity_type")?,
                entity_id: row.try_get("entity_id")?,
                details: row.try_get("details")?,
                created_at: created_at.to_rfc3339(),
            })
        })
        .collect()
}

pub async fn admin_passphrase_hash(pool: &PgPool) -> Result<Option<String>, AppError> {
    let row = sqlx::query("SELECT password_hash FROM admin_auth WHERE id = 1")
        .fetch_optional(pool)
        .await?;
    row.map(|record| record.try_get("password_hash"))
        .transpose()
        .map_err(AppError::from)
}

pub async fn cleanup_expired(pool: &PgPool) -> Result<Vec<String>, AppError> {
    let expired_uploads =
        sqlx::query("DELETE FROM upload_sessions WHERE expires_at < $1 RETURNING chunk_path")
            .bind(Utc::now())
            .fetch_all(pool)
            .await?;
    sqlx::query("DELETE FROM admin_sessions WHERE expires_at < $1")
        .bind(Utc::now())
        .execute(pool)
        .await?;
    sqlx::query("DELETE FROM admin_challenges WHERE expires_at < $1")
        .bind(Utc::now())
        .execute(pool)
        .await?;
    Ok(expired_uploads
        .into_iter()
        .filter_map(|row| row.try_get::<String, _>("chunk_path").ok())
        .collect())
}

pub fn upload_expiry() -> chrono::DateTime<Utc> {
    Utc::now() + Duration::hours(24)
}

fn json_value<T>(value: Value) -> Result<T, AppError>
where
    T: serde::de::DeserializeOwned,
{
    serde_json::from_value(value).map_err(AppError::from)
}
