use std::{net::SocketAddr, path::PathBuf};

use axum::{
    body::{to_bytes, Body},
    extract::{connect_info::ConnectInfo, Path, State},
    http::{header, HeaderMap, HeaderName, HeaderValue, Method, Request, Response, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Json},
    routing::{any, get},
    Router,
};
use chrono::Utc;
use serde::{de::DeserializeOwned, Serialize};
use serde_json::json;
use sqlx::Row;
use tokio::{
    fs::{self, File, OpenOptions},
    io::{AsyncReadExt, AsyncSeekExt, AsyncWriteExt, SeekFrom},
};
use tokio_util::io::ReaderStream;
use tower_http::{
    compression::CompressionLayer, limit::RequestBodyLimitLayer, services::ServeDir,
    trace::TraceLayer,
};
use tracing::field;
use uuid::Uuid;

use crate::{
    auth, db,
    error::AppError,
    i18n::{resolve_accept_language, Locale},
    models::{
        AuditEntry, MediaItem, PassphraseRequest, ProfileEditorData, ProjectEditorData,
        ReorderRequest, UploadInitRequest,
    },
    state::AppState,
    storage::{make_storage_path, sha256_file, sniff_media_type, validate_upload_request},
};

const JSON_BODY_LIMIT: usize = 1024 * 1024;
const UPLOAD_CHUNK_LIMIT: usize = 8 * 1024 * 1024;
const ADMIN_NO_INDEX: &str = "noindex, nofollow, noarchive, nosnippet";
const PUBLIC_CACHE: &str = "public, max-age=60, stale-while-revalidate=300";

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct BootstrapResponse {
    needs_setup: bool,
    authenticated: bool,
    csrf_token: String,
    max_upload_bytes: u64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct UploadStarted {
    upload_id: Uuid,
    received_bytes: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct UploadStatus {
    received_bytes: i64,
    total_bytes: i64,
}

#[derive(Serialize)]
struct ReorderResponse {
    saved: bool,
}

pub fn build_router(state: AppState) -> Router {
    let dist = state.config.frontend_dist.clone();
    let trace = TraceLayer::new_for_http().make_span_with(|request: &Request<Body>| {
        tracing::info_span!(
            "http_request",
            method = %request.method(),
            status = field::Empty,
            latency_ms = field::Empty
        )
    });

    Router::new()
        .route("/", get(spa_page))
        .route("/work", get(spa_page))
        .route("/about", get(spa_page))
        .route("/contact", get(spa_page))
        .route("/project/:slug", get(spa_page))
        .route("/:token", get(admin_page))
        .route("/:token/api/admin/*action", any(admin_dispatch))
        .route("/api/health", get(health))
        .route("/api/profile", get(public_profile))
        .route("/api/projects", get(public_projects))
        .route("/api/projects/:slug", get(public_project))
        .route("/media/:id", get(public_media))
        .route("/robots.txt", get(robots))
        .route("/sitemap.xml", get(sitemap))
        .nest_service("/assets", ServeDir::new(dist.join("assets")))
        .fallback(fallback)
        .layer(middleware::from_fn(security_headers))
        .layer(RequestBodyLimitLayer::new(UPLOAD_CHUNK_LIMIT))
        .layer(axum::extract::DefaultBodyLimit::max(JSON_BODY_LIMIT))
        .layer(CompressionLayer::new())
        .layer(trace)
        .with_state(state)
}

async fn security_headers(request: Request<Body>, next: Next) -> Response<Body> {
    let mut response = next.run(request).await;
    let headers = response.headers_mut();
    headers.insert(
        HeaderName::from_static("content-security-policy"),
        HeaderValue::from_static(
            "default-src 'self'; base-uri 'self'; form-action 'self'; object-src 'none'; frame-ancestors 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: https://yt3.googleusercontent.com; media-src 'self'; connect-src 'self'; font-src 'self'",
        ),
    );
    headers.insert(
        HeaderName::from_static("strict-transport-security"),
        HeaderValue::from_static("max-age=31536000; includeSubDomains"),
    );
    headers.insert(
        HeaderName::from_static("x-content-type-options"),
        HeaderValue::from_static("nosniff"),
    );
    headers.insert(
        HeaderName::from_static("referrer-policy"),
        HeaderValue::from_static("strict-origin-when-cross-origin"),
    );
    headers.insert(
        HeaderName::from_static("permissions-policy"),
        HeaderValue::from_static("camera=(), microphone=(), geolocation=(), payment=()"),
    );
    headers.insert(
        HeaderName::from_static("cross-origin-opener-policy"),
        HeaderValue::from_static("same-origin"),
    );
    response
}

async fn spa_page(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response<Body>, AppError> {
    localized_html(&state, &headers, false).await
}

async fn admin_page(
    State(state): State<AppState>,
    Path(token): Path<String>,
    headers: HeaderMap,
) -> Response<Body> {
    match auth::verify_admin_token(&state.pool, &token).await {
        Ok(true) => match localized_html(&state, &headers, true).await {
            Ok(response) => response,
            Err(error) => error.into_response(),
        },
        Ok(false) => plain_not_found(),
        Err(error) => error.into_response(),
    }
}

async fn localized_html(
    state: &AppState,
    headers: &HeaderMap,
    admin: bool,
) -> Result<Response<Body>, AppError> {
    let raw = fs::read_to_string(state.config.frontend_dist.join("index.html")).await?;
    let locale = locale_from_headers(headers);
    let html = inject_document_locale(&raw, locale);
    let mut response = Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, "text/html; charset=utf-8")
        .header(
            header::CACHE_CONTROL,
            if admin { "no-store" } else { "no-cache" },
        )
        .header(header::VARY, "Accept-Language")
        .body(Body::from(html))
        .map_err(|_| AppError::Internal)?;
    if admin {
        response
            .headers_mut()
            .insert("x-robots-tag", HeaderValue::from_static(ADMIN_NO_INDEX));
    }
    Ok(response)
}

fn inject_document_locale(raw: &str, locale: Locale) -> String {
    let replacement = format!(
        "<html lang=\"{}\" dir=\"{}\">",
        locale.as_str(),
        locale.direction()
    );
    if let Some(start) = raw.find("<html") {
        if let Some(relative_end) = raw[start..].find('>') {
            let end = start + relative_end + 1;
            let mut html = String::with_capacity(raw.len() + 8);
            html.push_str(&raw[..start]);
            html.push_str(&replacement);
            html.push_str(&raw[end..]);
            return html;
        }
    }
    raw.to_owned()
}

fn locale_from_headers(headers: &HeaderMap) -> Locale {
    let accept_language = headers
        .get(header::ACCEPT_LANGUAGE)
        .and_then(|value| value.to_str().ok());
    resolve_accept_language(accept_language)
}

async fn health() -> Json<serde_json::Value> {
    Json(json!({"status": "ok"}))
}

async fn public_profile(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response<Body>, AppError> {
    let locale = locale_from_headers(&headers);
    let profile = db::fetch_public_profile(&state.pool, locale).await?;
    Ok(cached_json(profile, PUBLIC_CACHE, true))
}

async fn public_projects(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response<Body>, AppError> {
    let locale = locale_from_headers(&headers);
    let projects = db::fetch_public_projects(&state.pool, locale, None).await?;
    Ok(cached_json(projects, PUBLIC_CACHE, true))
}

async fn public_project(
    State(state): State<AppState>,
    Path(slug): Path<String>,
    headers: HeaderMap,
) -> Result<Response<Body>, AppError> {
    if slug.len() > 80
        || !slug
            .bytes()
            .all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-')
    {
        return Err(AppError::NotFound);
    }
    let locale = locale_from_headers(&headers);
    let project = db::fetch_public_projects(&state.pool, locale, Some(&slug))
        .await?
        .into_iter()
        .next()
        .ok_or(AppError::NotFound)?;
    Ok(cached_json(project, PUBLIC_CACHE, true))
}

fn cached_json<T: Serialize>(value: T, cache: &'static str, vary_language: bool) -> Response<Body> {
    let mut response = Json(value).into_response();
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static(cache));
    if vary_language {
        response
            .headers_mut()
            .insert(header::VARY, HeaderValue::from_static("Accept-Language"));
    }
    response
}

async fn robots(State(state): State<AppState>) -> Response<Body> {
    let body = format!(
        "User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /media/\nSitemap: {}/sitemap.xml\n",
        state.config.public_base_url
    );
    text_response(
        StatusCode::OK,
        "text/plain; charset=utf-8",
        body,
        Some("public, max-age=3600"),
    )
}

async fn sitemap(State(state): State<AppState>) -> Result<Response<Body>, AppError> {
    let projects = db::fetch_public_projects(&state.pool, Locale::En, None).await?;
    let base = xml_escape(&state.config.public_base_url);
    let mut urls = vec![
        format!("<url><loc>{base}/</loc></url>"),
        format!("<url><loc>{base}/work</loc></url>"),
        format!("<url><loc>{base}/about</loc></url>"),
        format!("<url><loc>{base}/contact</loc></url>"),
    ];
    urls.extend(projects.into_iter().map(|project| {
        format!(
            "<url><loc>{base}/project/{}</loc></url>",
            xml_escape(&project.slug)
        )
    }));
    let body = format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">{}</urlset>",
        urls.join("")
    );
    Ok(text_response(
        StatusCode::OK,
        "application/xml; charset=utf-8",
        body,
        Some("public, max-age=3600"),
    ))
}

fn xml_escape(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

async fn fallback(request: Request<Body>) -> Response<Body> {
    if request.uri().path().starts_with("/api/") {
        AppError::NotFound.into_response()
    } else {
        plain_not_found()
    }
}

fn plain_not_found() -> Response<Body> {
    text_response(
        StatusCode::NOT_FOUND,
        "text/plain; charset=utf-8",
        "Not Found".to_owned(),
        None,
    )
}

fn text_response(
    status: StatusCode,
    content_type: &'static str,
    body: String,
    cache: Option<&'static str>,
) -> Response<Body> {
    let mut builder = Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, content_type);
    if let Some(cache) = cache {
        builder = builder.header(header::CACHE_CONTROL, cache);
    }
    builder
        .body(Body::from(body))
        .unwrap_or_else(|_| Response::new(Body::empty()))
}

async fn admin_dispatch(
    State(state): State<AppState>,
    Path((token, action)): Path<(String, String)>,
    request: Request<Body>,
) -> Response<Body> {
    match auth::verify_admin_token(&state.pool, &token).await {
        Ok(true) => {}
        Ok(false) => return plain_not_found(),
        Err(error) => return admin_error(error),
    }
    let remote = request
        .extensions()
        .get::<ConnectInfo<SocketAddr>>()
        .map(|info| info.0);
    let (parts, body) = request.into_parts();
    let headers = parts.headers;
    let method = parts.method;
    let action = action.trim_start_matches('/');

    let result = match (method.as_str(), action) {
        ("GET", "bootstrap") => admin_bootstrap(&state, &headers).await,
        ("POST", "setup") => admin_setup(&state, &headers, body).await,
        ("POST", "login") => {
            admin_login(&state, &headers, body, &state.login_limiter, remote).await
        }
        ("POST", "logout") => admin_logout(&state, &headers).await,
        ("GET", "profile") => admin_get_profile(&state, &headers).await,
        ("PUT", "profile") => admin_save_profile(&state, &headers, body).await,
        ("GET", "projects") => admin_get_projects(&state, &headers).await,
        ("POST", "projects") => admin_create_project(&state, &headers, body).await,
        ("PUT" | "POST", "projects/reorder") => {
            admin_reorder_projects(&state, &headers, body).await
        }
        ("GET", "media") => admin_get_media(&state, &headers).await,
        ("GET", "audit") => admin_get_audit(&state, &headers).await,
        ("POST", "uploads/init") => admin_upload_init(&state, &headers, body).await,
        _ => {
            if let Some(suffix) = action.strip_prefix("projects/") {
                if suffix.contains('/') {
                    return plain_not_found();
                }
                let Some(id) = parse_uuid(suffix) else {
                    return plain_not_found();
                };
                match method.as_str() {
                    "PUT" => admin_update_project(&state, &headers, body, id).await,
                    "DELETE" => admin_delete_project(&state, &headers, id).await,
                    _ => return plain_not_found(),
                }
            } else if let Some(suffix) = action.strip_prefix("uploads/") {
                let segments = suffix.split('/').collect::<Vec<_>>();
                match segments.as_slice() {
                    [id] => {
                        let Some(id) = parse_uuid(id) else {
                            return plain_not_found();
                        };
                        match method.as_str() {
                            "GET" => admin_upload_status(&state, &headers, id).await,
                            "PUT" => admin_upload_chunk(&state, &headers, body, id).await,
                            _ => return plain_not_found(),
                        }
                    }
                    [id, "complete"] if method == Method::POST => {
                        let Some(id) = parse_uuid(id) else {
                            return plain_not_found();
                        };
                        admin_upload_complete(&state, &headers, id).await
                    }
                    _ => return plain_not_found(),
                }
            } else {
                return plain_not_found();
            }
        }
    };
    match result {
        Ok(response) => with_admin_headers(response),
        Err(error) => admin_error(error),
    }
}

fn parse_uuid(value: &str) -> Option<Uuid> {
    Uuid::parse_str(value).ok()
}

async fn admin_bootstrap(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<Response<Body>, AppError> {
    let result = auth::bootstrap(&state.pool, headers).await?;
    let response = BootstrapResponse {
        needs_setup: result.needs_setup,
        authenticated: result.authenticated,
        csrf_token: result.csrf_token,
        max_upload_bytes: state.config.max_upload_bytes,
    };
    let mut response = admin_json(StatusCode::OK, response);
    if !result.set_cookie.is_empty() {
        append_cookie(&mut response, &result.set_cookie)?;
    }
    Ok(response)
}

async fn admin_setup(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
) -> Result<Response<Body>, AppError> {
    let request: PassphraseRequest = parse_json(body, JSON_BODY_LIMIT).await?;
    let result = auth::setup_passphrase(&state.pool, headers, &request.passphrase).await?;
    let mut response = admin_json(
        StatusCode::OK,
        json!({"csrfToken": result.csrf_token, "authenticated": true}),
    );
    append_cookie(&mut response, &result.set_cookie)?;
    append_cookie(&mut response, &result.clear_bootstrap_cookie)?;
    Ok(response)
}

async fn admin_login(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
    limiter: &auth::LoginLimiter,
    remote: Option<SocketAddr>,
) -> Result<Response<Body>, AppError> {
    let request: PassphraseRequest = parse_json(body, JSON_BODY_LIMIT).await?;
    let result = auth::login(&state.pool, headers, &request.passphrase, limiter, remote).await?;
    let mut response = admin_json(
        StatusCode::OK,
        json!({"csrfToken": result.csrf_token, "authenticated": true}),
    );
    append_cookie(&mut response, &result.set_cookie)?;
    append_cookie(&mut response, &result.clear_bootstrap_cookie)?;
    Ok(response)
}

async fn admin_logout(state: &AppState, headers: &HeaderMap) -> Result<Response<Body>, AppError> {
    let clear_cookie = auth::logout(&state.pool, headers).await?;
    let mut response = Response::builder()
        .status(StatusCode::NO_CONTENT)
        .body(Body::empty())
        .map_err(|_| AppError::Internal)?;
    append_cookie(&mut response, &clear_cookie)?;
    Ok(response)
}

async fn admin_get_profile(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, false).await?;
    Ok(admin_json(
        StatusCode::OK,
        db::fetch_profile_editor(&state.pool).await?,
    ))
}

async fn admin_save_profile(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let data: ProfileEditorData = parse_json(body, JSON_BODY_LIMIT).await?;
    Ok(admin_json(
        StatusCode::OK,
        db::save_profile(&state.pool, &data).await?,
    ))
}

async fn admin_get_projects(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, false).await?;
    Ok(admin_json(
        StatusCode::OK,
        db::fetch_project_editors(&state.pool).await?,
    ))
}

async fn admin_create_project(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let mut data: ProjectEditorData = parse_json(body, JSON_BODY_LIMIT).await?;
    if data.id.is_some() {
        return Err(AppError::Validation);
    }
    data.id = None;
    let project = db::save_project(&state.pool, &data).await?;
    Ok(admin_json(StatusCode::CREATED, project))
}

async fn admin_update_project(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
    id: Uuid,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let mut data: ProjectEditorData = parse_json(body, JSON_BODY_LIMIT).await?;
    if data.id.is_some_and(|received| received != id) {
        return Err(AppError::Validation);
    }
    data.id = Some(id);
    Ok(admin_json(
        StatusCode::OK,
        db::save_project(&state.pool, &data).await?,
    ))
}

async fn admin_delete_project(
    state: &AppState,
    headers: &HeaderMap,
    id: Uuid,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let candidate_media =
        sqlx::query("SELECT video_media_id, poster_media_id FROM projects WHERE id = $1")
            .bind(id)
            .fetch_optional(&state.pool)
            .await?
            .ok_or(AppError::NotFound)?;
    let media_ids = [
        candidate_media.try_get::<Option<Uuid>, _>("video_media_id")?,
        candidate_media.try_get::<Option<Uuid>, _>("poster_media_id")?,
    ];
    db::delete_project(&state.pool, id).await?;
    for media_id in media_ids.into_iter().flatten() {
        cleanup_unreferenced_media(state, media_id).await?;
    }
    Ok(admin_empty(StatusCode::NO_CONTENT))
}

async fn cleanup_unreferenced_media(state: &AppState, id: Uuid) -> Result<(), AppError> {
    let referenced = sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS (SELECT 1 FROM projects WHERE video_media_id = $1 OR poster_media_id = $1)",
    )
    .bind(id)
    .fetch_one(&state.pool)
    .await?;
    if referenced {
        return Ok(());
    }
    let record = sqlx::query("SELECT storage_path, storage_backend FROM media WHERE id = $1")
        .bind(id)
        .fetch_optional(&state.pool)
        .await?;
    let Some(record) = record else { return Ok(()) };
    let storage_path: String = record.try_get("storage_path")?;
    let backend: String = record.try_get("storage_backend")?;
    sqlx::query("DELETE FROM media WHERE id = $1")
        .bind(id)
        .execute(&state.pool)
        .await?;
    state.storage.delete(&storage_path, &backend).await?;
    Ok(())
}

async fn admin_reorder_projects(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let request: ReorderRequest = parse_json(body, JSON_BODY_LIMIT).await?;
    db::reorder_projects(&state.pool, &request.ids).await?;
    Ok(admin_json(StatusCode::OK, ReorderResponse { saved: true }))
}

async fn admin_get_media(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, false).await?;
    Ok(admin_json(
        StatusCode::OK,
        db::list_media(&state.pool).await?,
    ))
}

async fn admin_get_audit(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, false).await?;
    let entries: Vec<AuditEntry> = db::fetch_audit(&state.pool).await?;
    Ok(admin_json(StatusCode::OK, entries))
}

async fn parse_json<T: DeserializeOwned>(body: Body, limit: usize) -> Result<T, AppError> {
    let bytes = to_bytes(body, limit)
        .await
        .map_err(|_| AppError::BadRequest)?;
    serde_json::from_slice(&bytes).map_err(AppError::from)
}

fn admin_json<T: Serialize>(status: StatusCode, value: T) -> Response<Body> {
    let response = (status, Json(value)).into_response();
    with_admin_headers(response)
}

fn admin_empty(status: StatusCode) -> Response<Body> {
    with_admin_headers((status, Body::empty()).into_response())
}

fn with_admin_headers(mut response: Response<Body>) -> Response<Body> {
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response
        .headers_mut()
        .insert("x-robots-tag", HeaderValue::from_static(ADMIN_NO_INDEX));
    response
}

fn admin_error(error: AppError) -> Response<Body> {
    with_admin_headers(error.into_response())
}

fn append_cookie(response: &mut Response<Body>, cookie: &str) -> Result<(), AppError> {
    let value = HeaderValue::from_str(cookie).map_err(|_| AppError::Internal)?;
    response.headers_mut().append(header::SET_COOKIE, value);
    Ok(())
}

async fn admin_upload_init(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let request: UploadInitRequest = parse_json(body, JSON_BODY_LIMIT).await?;
    if request.filename.contains('/') || request.filename.contains('\\') {
        return Err(AppError::Validation);
    }
    validate_upload_request(
        &request.filename,
        &request.mime_type,
        request.total_bytes,
        state.config.max_upload_bytes,
    )?;
    let total_bytes = i64::try_from(request.total_bytes).map_err(|_| AppError::Validation)?;
    let id = Uuid::new_v4();
    let uploads_dir = state.config.data_dir.join("uploads");
    fs::create_dir_all(&uploads_dir).await?;
    let chunk_path = uploads_dir.join(format!("{id}.part"));
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&chunk_path)
        .await?;
    let relative_path = format!("uploads/{id}.part");
    let insert = sqlx::query(
        "INSERT INTO upload_sessions (id, filename, declared_mime, total_bytes, received_bytes, chunk_path, expires_at) \
         VALUES ($1, $2, $3, $4, 0, $5, $6)",
    )
    .bind(id)
    .bind(&request.filename)
    .bind(&request.mime_type)
    .bind(total_bytes)
    .bind(relative_path)
    .bind(db::upload_expiry())
    .execute(&state.pool)
    .await;
    if let Err(error) = insert {
        let _ = fs::remove_file(chunk_path).await;
        return Err(AppError::Database(error));
    }
    db::record_audit(
        &state.pool,
        "upload_started",
        "media",
        Some(&id.to_string()),
        json!({"bytes": total_bytes}),
    )
    .await?;
    Ok(admin_json(
        StatusCode::CREATED,
        UploadStarted {
            upload_id: id,
            received_bytes: 0,
        },
    ))
}

async fn admin_upload_status(
    state: &AppState,
    headers: &HeaderMap,
    id: Uuid,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, false).await?;
    let row = upload_session(&state.pool, id).await?;
    let status = UploadStatus {
        received_bytes: row.try_get("received_bytes")?,
        total_bytes: row.try_get("total_bytes")?,
    };
    Ok(admin_json(StatusCode::OK, status))
}

async fn admin_upload_chunk(
    state: &AppState,
    headers: &HeaderMap,
    body: Body,
    id: Uuid,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let range = headers
        .get(header::CONTENT_RANGE)
        .and_then(|value| value.to_str().ok())
        .ok_or(AppError::BadRequest)?;
    let range = parse_content_range(range).ok_or(AppError::BadRequest)?;
    let bytes = to_bytes(body, UPLOAD_CHUNK_LIMIT)
        .await
        .map_err(|_| AppError::BadRequest)?;
    if bytes.is_empty()
        || u64::try_from(bytes.len()).map_err(|_| AppError::BadRequest)?
            != range.end_exclusive - range.start
    {
        return Err(AppError::BadRequest);
    }
    let mut transaction = state.pool.begin().await?;
    let row = sqlx::query(
        "SELECT total_bytes, received_bytes, expires_at FROM upload_sessions WHERE id = $1 FOR UPDATE",
    )
    .bind(id)
    .fetch_optional(&mut *transaction)
    .await?
    .ok_or(AppError::NotFound)?;
    let total_bytes: i64 = row.try_get("total_bytes")?;
    let received_bytes: i64 = row.try_get("received_bytes")?;
    let expires_at: chrono::DateTime<Utc> = row.try_get("expires_at")?;
    if expires_at <= Utc::now()
        || i64::try_from(range.total).map_err(|_| AppError::BadRequest)? != total_bytes
    {
        return Err(AppError::NotFound);
    }
    if i64::try_from(range.start).map_err(|_| AppError::BadRequest)? != received_bytes
        || range.end_exclusive > range.total
    {
        return Err(AppError::Conflict);
    }
    let path = upload_chunk_path(state, id);
    let mut file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(path)
        .await?;
    file.set_len(u64::try_from(received_bytes).map_err(|_| AppError::Internal)?)
        .await?;
    file.seek(SeekFrom::Start(range.start)).await?;
    file.write_all(&bytes).await?;
    file.flush().await?;
    let new_received = i64::try_from(range.end_exclusive).map_err(|_| AppError::BadRequest)?;
    sqlx::query("UPDATE upload_sessions SET received_bytes = $2, expires_at = $3 WHERE id = $1")
        .bind(id)
        .bind(new_received)
        .bind(db::upload_expiry())
        .execute(&mut *transaction)
        .await?;
    transaction.commit().await?;
    Ok(admin_json(
        StatusCode::OK,
        json!({"receivedBytes": new_received}),
    ))
}

struct ContentRange {
    start: u64,
    end_exclusive: u64,
    total: u64,
}

fn parse_content_range(value: &str) -> Option<ContentRange> {
    let value = value.strip_prefix("bytes ")?;
    let (range, total) = value.split_once('/')?;
    let (start, end_inclusive) = range.split_once('-')?;
    let start = start.parse::<u64>().ok()?;
    let end_inclusive = end_inclusive.parse::<u64>().ok()?;
    let total = total.parse::<u64>().ok()?;
    let end_exclusive = end_inclusive.checked_add(1)?;
    (start < end_exclusive && end_exclusive <= total).then_some(ContentRange {
        start,
        end_exclusive,
        total,
    })
}

async fn upload_session(pool: &sqlx::PgPool, id: Uuid) -> Result<sqlx::postgres::PgRow, AppError> {
    let row = sqlx::query(
        "SELECT filename, declared_mime, total_bytes, received_bytes, chunk_path, expires_at \
         FROM upload_sessions WHERE id = $1 AND expires_at > $2",
    )
    .bind(id)
    .bind(Utc::now())
    .fetch_optional(pool)
    .await?
    .ok_or(AppError::NotFound)?;
    Ok(row)
}

fn upload_chunk_path(state: &AppState, id: Uuid) -> PathBuf {
    state
        .config
        .data_dir
        .join("uploads")
        .join(format!("{id}.part"))
}

async fn admin_upload_complete(
    state: &AppState,
    headers: &HeaderMap,
    id: Uuid,
) -> Result<Response<Body>, AppError> {
    auth::require_session(&state.pool, headers, true).await?;
    let row = upload_session(&state.pool, id).await?;
    let filename: String = row.try_get("filename")?;
    let declared_mime: String = row.try_get("declared_mime")?;
    let total_bytes: i64 = row.try_get("total_bytes")?;
    let received_bytes: i64 = row.try_get("received_bytes")?;
    if total_bytes != received_bytes {
        return Err(AppError::Conflict);
    }
    let chunk_path = upload_chunk_path(state, id);
    let metadata = fs::metadata(&chunk_path).await?;
    if i64::try_from(metadata.len()).map_err(|_| AppError::Validation)? != total_bytes {
        return Err(AppError::Conflict);
    }
    let mut file = File::open(&chunk_path).await?;
    let mut signature = [0_u8; 32];
    let read = file.read(&mut signature).await?;
    let media_type = sniff_media_type(&signature[..read]).ok_or(AppError::Validation)?;
    if declared_mime != "application/octet-stream" && declared_mime != media_type.mime() {
        return Err(AppError::Validation);
    }
    let media_id = Uuid::new_v4();
    let storage_path = make_storage_path(media_type, media_id);
    let checksum = sha256_file(&chunk_path).await?;
    let storage_backend = state
        .storage
        .store_file(
            &storage_path,
            &chunk_path,
            media_type.mime(),
            metadata.len(),
        )
        .await?;
    let insert = sqlx::query(
        "INSERT INTO media (id, storage_path, storage_backend, original_name, mime_type, size_bytes, sha256) \
         VALUES ($1, $2, $3, $4, $5, $6, $7)",
    )
    .bind(media_id)
    .bind(&storage_path)
    .bind(storage_backend)
    .bind(&filename)
    .bind(media_type.mime())
    .bind(total_bytes)
    .bind(&checksum)
    .execute(&state.pool)
    .await;
    if let Err(error) = insert {
        let _ = state.storage.delete(&storage_path, storage_backend).await;
        return Err(AppError::Database(error));
    }
    sqlx::query("DELETE FROM upload_sessions WHERE id = $1")
        .bind(id)
        .execute(&state.pool)
        .await?;
    let _ = fs::remove_file(chunk_path).await;
    db::record_audit(
        &state.pool,
        "uploaded",
        "media",
        Some(&media_id.to_string()),
        json!({"mimeType": media_type.mime(), "bytes": total_bytes}),
    )
    .await?;
    Ok(admin_json(
        StatusCode::CREATED,
        MediaItem {
            id: media_id,
            filename,
            mime_type: media_type.mime().to_owned(),
            size_bytes: total_bytes,
            url: format!("/media/{media_id}"),
        },
    ))
}

async fn public_media(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
    headers: HeaderMap,
) -> Result<Response<Body>, AppError> {
    let row = sqlx::query("SELECT storage_path, storage_backend, mime_type, size_bytes, sha256 FROM media WHERE id = $1")
        .bind(id)
        .fetch_optional(&state.pool)
        .await?
        .ok_or(AppError::NotFound)?;
    let storage_path: String = row.try_get("storage_path")?;
    let backend: String = row.try_get("storage_backend")?;
    let mime_type: String = row.try_get("mime_type")?;
    let size_bytes: i64 = row.try_get("size_bytes")?;
    let checksum: String = row.try_get("sha256")?;
    let range_header = headers
        .get(header::RANGE)
        .and_then(|value| value.to_str().ok());
    if backend == "local" {
        let path = state.storage.local_path(&storage_path)?;
        let file = File::open(path).await?;
        let metadata = file.metadata().await?;
        let total = metadata.len();
        let byte_range = match parse_range(range_header, total) {
            Ok(range) => range,
            Err(()) => return Ok(range_not_satisfiable(total)),
        };
        let (status, file, content_length, content_range) = match byte_range {
            Some(range) => {
                let mut file = file;
                file.seek(SeekFrom::Start(range.start)).await?;
                let length = range.end_exclusive - range.start;
                (
                    StatusCode::PARTIAL_CONTENT,
                    file.take(length),
                    length,
                    Some(format!(
                        "bytes {}-{}/{}",
                        range.start,
                        range.end_exclusive - 1,
                        total
                    )),
                )
            }
            None => (StatusCode::OK, file.take(total), total, None),
        };
        let stream = ReaderStream::new(file);
        let mut response = Response::builder()
            .status(status)
            .header(header::CONTENT_TYPE, mime_type)
            .header(header::CONTENT_LENGTH, content_length.to_string())
            .header(header::ACCEPT_RANGES, "bytes")
            .header(header::CACHE_CONTROL, "public, max-age=31536000, immutable")
            .header(header::ETAG, format!("\"{checksum}\""))
            .body(Body::from_stream(stream))
            .map_err(|_| AppError::Internal)?;
        if let Some(content_range) = content_range {
            response.headers_mut().insert(
                header::CONTENT_RANGE,
                HeaderValue::from_str(&content_range).map_err(|_| AppError::Internal)?,
            );
        }
        return Ok(response);
    }
    if backend != "supabase" {
        return Err(AppError::Storage);
    }
    let upstream = state
        .storage
        .get_remote(&storage_path, range_header)
        .await?;
    if upstream.status() == StatusCode::RANGE_NOT_SATISFIABLE {
        return Ok(range_not_satisfiable(
            u64::try_from(size_bytes).unwrap_or_default(),
        ));
    }
    if !upstream.status().is_success() {
        return Err(AppError::Storage);
    }
    let status = upstream.status();
    let upstream_length = upstream.headers().get(header::CONTENT_LENGTH).cloned();
    let upstream_range = upstream.headers().get(header::CONTENT_RANGE).cloned();
    let body = Body::from_stream(upstream.bytes_stream());
    let mut response = Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, mime_type)
        .header(header::ACCEPT_RANGES, "bytes")
        .header(header::CACHE_CONTROL, "public, max-age=31536000, immutable")
        .header(header::ETAG, format!("\"{checksum}\""))
        .body(body)
        .map_err(|_| AppError::Internal)?;
    if let Some(value) = upstream_length {
        response.headers_mut().insert(header::CONTENT_LENGTH, value);
    }
    if let Some(value) = upstream_range {
        response.headers_mut().insert(header::CONTENT_RANGE, value);
    }
    Ok(response)
}

#[derive(Clone, Copy)]
struct ByteRange {
    start: u64,
    end_exclusive: u64,
}

fn parse_range(value: Option<&str>, total: u64) -> Result<Option<ByteRange>, ()> {
    let Some(value) = value else { return Ok(None) };
    let value = value.strip_prefix("bytes=").ok_or(())?;
    if value.contains(',') {
        return Err(());
    }
    let (start, end) = value.split_once('-').ok_or(())?;
    if start.is_empty() {
        let suffix = end.parse::<u64>().map_err(|_| ())?;
        if suffix == 0 || total == 0 {
            return Err(());
        }
        let length = suffix.min(total);
        return Ok(Some(ByteRange {
            start: total - length,
            end_exclusive: total,
        }));
    }
    let start = start.parse::<u64>().map_err(|_| ())?;
    if start >= total {
        return Err(());
    }
    let end_exclusive = if end.is_empty() {
        total
    } else {
        end.parse::<u64>()
            .map_err(|_| ())?
            .checked_add(1)
            .ok_or(())?
            .min(total)
    };
    if end_exclusive <= start {
        return Err(());
    }
    Ok(Some(ByteRange {
        start,
        end_exclusive,
    }))
}

fn range_not_satisfiable(total: u64) -> Response<Body> {
    let content_range = format!("bytes */{total}");
    Response::builder()
        .status(StatusCode::RANGE_NOT_SATISFIABLE)
        .header(header::CONTENT_RANGE, content_range)
        .header(header::ACCEPT_RANGES, "bytes")
        .body(Body::empty())
        .unwrap_or_else(|_| Response::new(Body::empty()))
}

pub async fn cleanup_orphaned_uploads(state: &AppState) -> Result<(), AppError> {
    fs::create_dir_all(state.config.data_dir.join("uploads")).await?;
    let expired_paths = db::cleanup_expired(&state.pool).await?;
    for path in expired_paths {
        if path.starts_with("uploads/") && !path.contains("..") {
            let _ = fs::remove_file(state.config.data_dir.join(path)).await;
        }
    }
    let active = sqlx::query("SELECT chunk_path FROM upload_sessions")
        .fetch_all(&state.pool)
        .await?
        .into_iter()
        .filter_map(|row| row.try_get::<String, _>("chunk_path").ok())
        .collect::<std::collections::HashSet<_>>();
    let mut entries = fs::read_dir(state.config.data_dir.join("uploads")).await?;
    while let Some(entry) = entries.next_entry().await? {
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().into_owned();
        let relative = format!("uploads/{name}");
        if path.extension().and_then(|value| value.to_str()) == Some("part")
            && !active.contains(&relative)
        {
            let _ = fs::remove_file(path).await;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{inject_document_locale, parse_content_range, parse_range};
    use crate::i18n::Locale;

    #[test]
    fn html_receives_language_and_direction_before_vue_starts() {
        let raw = "<!doctype html><html lang=\"en\" dir=\"ltr\"><head></head></html>";
        assert!(inject_document_locale(raw, Locale::Ar).contains("<html lang=\"ar\" dir=\"rtl\">"));
        assert!(inject_document_locale(raw, Locale::Fr).contains("<html lang=\"fr\" dir=\"ltr\">"));
    }

    #[test]
    fn content_ranges_require_contiguous_valid_offsets() {
        let range = parse_content_range("bytes 8-15/32").expect("valid range");
        assert_eq!(range.start, 8);
        assert_eq!(range.end_exclusive, 16);
        assert_eq!(range.total, 32);
        assert!(parse_content_range("bytes 16-8/32").is_none());
        assert!(parse_content_range("bytes 0-0/*").is_none());
    }

    #[test]
    fn media_range_supports_open_and_suffix_forms() {
        assert_eq!(
            parse_range(Some("bytes=0-9"), 100).expect("valid"),
            Some(super::ByteRange {
                start: 0,
                end_exclusive: 10
            })
        );
        assert_eq!(
            parse_range(Some("bytes=10-"), 100).expect("valid"),
            Some(super::ByteRange {
                start: 10,
                end_exclusive: 100
            })
        );
        assert_eq!(
            parse_range(Some("bytes=-10"), 100).expect("valid"),
            Some(super::ByteRange {
                start: 90,
                end_exclusive: 100
            })
        );
        assert!(parse_range(Some("bytes=100-"), 100).is_err());
        assert!(parse_range(Some("bytes=0-1,4-5"), 100).is_err());
    }
}
