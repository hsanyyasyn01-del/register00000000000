# Artsy portfolio

A small portfolio site and private content editor for the Artsy brand. The public pages are in English, Arabic, and French. The server chooses a language from `Accept-Language`; there is no language selector on public pages.

The public profile copy is a general translation of information on the Fiverr page for `@nolohc`. “Artsy” is the display name supplied for this site. The seed includes the profile but no demo projects; it does not add ratings, client names, or performance figures.

## Run it locally

You will need Node.js 22.12 or newer, Rust 1.85 or newer, and a PostgreSQL database. From the repository root:

```sh
cp .env.example .env
```

Set `DATABASE_URL` in `.env` to a database the server can migrate and write to. For example:

```dotenv
DATABASE_URL=postgres://USER:PASSWORD@localhost:5432/artsy
```

The other values in `.env.example` are optional. The server defaults to port `8080`, serves `frontend/dist`, stores temporary uploads in `data`, uses a `portfolio-media` storage bucket name, and allows uploads up to 1 GiB. `PUBLIC_BASE_URL` should be the public site origin when deploying; locally it defaults to `http://localhost:8080`.

To use Supabase Storage, create a **private** bucket and set both `SUPABASE_URL` and `SUPABASE_SERVICE_KEY`. The service key is used only by the Rust server; do not add it to a frontend variable or expose it to the browser. If both values are empty, media is stored locally under `DATA_DIR`. Keep that directory on persistent storage. The PostgreSQL connection must use a trusted server-side role with permission to run migrations and manage the tables. Row-level security is enabled on the application tables and there are no anonymous table policies. The app’s database role is trusted; if it owns the tables or has `BYPASSRLS`, RLS does not restrict that server connection. Keep `DATABASE_URL` private and do not connect browsers directly to Postgres.

Start the server from the repository root:

```sh
cargo run --manifest-path backend/Cargo.toml -- serve
```

On startup it applies migrations and idempotent seed data. The first start prints the private editor URL to stdout once. Save that URL somewhere private. Its random path token is stored as a hash in the database. The editor asks you to set a passphrase of at least 12 characters; the passphrase is stored as an Argon2id hash. If the URL is lost, rotate it from the same repository root:

```sh
cargo run --manifest-path backend/Cargo.toml -- admin-rotate
```

Rotation invalidates existing editor sessions and prints a new private URL. For a running Docker deployment, run the same subcommand inside the application container:

```sh
docker exec -it CONTAINER_NAME /usr/local/bin/portfolio-server admin-rotate
```

You can also run the seed command separately; it applies migrations first:

```sh
cargo run --manifest-path backend/Cargo.toml -- seed
```

For deployment, terminate TLS at a reverse proxy, set `PUBLIC_BASE_URL` to the HTTPS origin, and preserve the browser’s `Host` header. The editor cookies use `Secure`, `HttpOnly`, `SameSite=Strict`, and the `__Host-` prefix. Keep `.env` out of source control and container images.

## Frontend development

The Vite server proxies same-origin API calls to `http://127.0.0.1:8080`. Start the Rust server in one terminal and the frontend in another:

```sh
cd frontend
npm ci
npm run dev
```

Set `API_PROXY_TARGET` if the backend is running somewhere else. A small preview profile is bundled so Vite can display the public UI without Axum. In deployment, the Rust API and database are the source of truth; the bundled copy is only a network/non-JSON-response fallback and does not include editor changes.

## Build and run the container

The Docker build compiles the frontend and Rust server in separate stages:

```sh
docker build -t artsy-portfolio .
docker run --rm --env-file .env -p 8080:8080 -v artsy-data:/app/data artsy-portfolio
```

The container runs as a non-root user. The named volume keeps local uploads and resumable upload pieces between container restarts. Supabase is optional.

## Public endpoints

- `GET /api/health`
- `GET /api/profile`
- `GET /api/projects`
- `GET /api/projects/:slug`
- `GET /media/:id`
- `GET /robots.txt` and `GET /sitemap.xml`

The profile and project endpoints use `Accept-Language` and return English when a translation is missing. Responses that vary by language include `Vary: Accept-Language`. Media responses support byte ranges for video playback.

The editor supports profile and project copy in all three locales, draft/publish state, project ordering, audit history, and resumable uploads in 4 MiB chunks. Upload content is checked against its file signature before it is stored. Supabase credentials stay on the server; public media is streamed through `/media/:id`.

The avatar and banner use the exact public image URLs supplied for this site. They are fetched by the visitor’s browser from YouTube’s image host; if you later keep local copies, update the two image references in `frontend/src/views/HomeView.vue` and the favicon in `frontend/index.html`.

## Checks

Frontend checks:

```sh
cd frontend
npm ci
npm run typecheck
npm run lint
npm test
npm run build
npx playwright install chromium
npm run test:e2e
npm audit
```

The Playwright tests exercise public navigation in English, Arabic, and French, check Arabic RTL and numerals at 320 px, scan the public routes and editor setup with axe (including the home page in dark mode), and use API fixtures to save translated content and resume a media upload in the editor. They do not replace a live PostgreSQL/Supabase integration test.

Backend checks, from the repository root:

```sh
cargo fmt --manifest-path backend/Cargo.toml --all -- --check
cargo test --manifest-path backend/Cargo.toml
cargo clippy --manifest-path backend/Cargo.toml --all-targets -- -D warnings
```
