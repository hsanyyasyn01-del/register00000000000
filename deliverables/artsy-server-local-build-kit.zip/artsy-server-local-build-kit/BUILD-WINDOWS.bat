@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%~dp0"

where node >nul 2>&1
if errorlevel 1 goto missing_node
where npm >nul 2>&1
if errorlevel 1 goto missing_node
where rustc >nul 2>&1
if errorlevel 1 goto missing_rust
where cargo >nul 2>&1
if errorlevel 1 goto missing_rust

echo [1/3] Installing frontend packages and building the frontend...
pushd "%ROOT%frontend"
call npm ci --no-audit --no-fund
if errorlevel 1 goto build_failed
call npm run build
if errorlevel 1 goto build_failed
popd

echo [2/3] Building the Rust server for Windows x64...
call cargo build --release --manifest-path "%ROOT%backend\Cargo.toml"
if errorlevel 1 goto build_failed

echo [3/3] Creating run-ready folder...
set "OUT=%ROOT%run-ready"
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%\frontend\dist"
mkdir "%OUT%\data"
copy /Y "%ROOT%backend\target\release\portfolio-server.exe" "%OUT%\portfolio-server.exe" >nul
if errorlevel 1 goto build_failed
robocopy "%ROOT%frontend\dist" "%OUT%\frontend\dist" /E /NFL /NDL /NJH /NJS /NC /NS >nul
if errorlevel 8 goto build_failed
copy /Y "%ROOT%.env.example" "%OUT%\.env.example" >nul
copy /Y "%ROOT%run-server.bat" "%OUT%\run-server.bat" >nul
copy /Y "%ROOT%SUPABASE-SETUP-AR.txt" "%OUT%\SUPABASE-SETUP-AR.txt" >nul
copy /Y "%ROOT%START-HERE-AR.txt" "%OUT%\START-HERE-AR.txt" >nul

echo.
echo Build finished. Your runnable folder is:
echo %OUT%
echo Follow START-HERE-AR.txt, then run run-server.bat.
pause
exit /b 0

:missing_node
echo Node.js and npm are required. Install Node.js 22 LTS, then reopen this window.
goto failed

:missing_rust
echo Rust and Cargo are required. Install the stable x64 MSVC toolchain, then reopen this window.
goto failed

:build_failed
echo Build or packaging failed. Read the error above and check the instructions.
goto failed

:failed
pause
exit /b 1
