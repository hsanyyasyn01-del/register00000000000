@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "portfolio-server.exe" (
  echo portfolio-server.exe is missing. Build the kit first.
  pause
  exit /b 1
)
if not exist ".env" (
  if exist ".env.example" copy /Y ".env.example" ".env" >nul
  echo Created .env from .env.example.
  echo Fill DATABASE_URL, SUPABASE_URL, and SUPABASE_SERVICE_KEY, then run this file again.
  start "" notepad.exe "%~dp0.env"
  pause
  exit /b 1
)
if not exist "data" mkdir "data"

start "Artsy server" "%~dp0portfolio-server.exe" serve
echo Waiting for the server to become ready...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$deadline=(Get-Date).AddSeconds(120); while ((Get-Date) -lt $deadline) { try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 -Uri 'http://localhost:8080/api/health'; if ($r.StatusCode -eq 200) { Start-Process 'http://localhost:8080'; exit 0 } } catch {}; Start-Sleep -Seconds 1 }; exit 1"
if errorlevel 1 (
  echo The server did not become ready. Check the Artsy server window and .env settings.
  pause
)
