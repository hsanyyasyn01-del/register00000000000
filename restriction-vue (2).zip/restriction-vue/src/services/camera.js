export async function startCamera(videoEl) {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'user' },
    audio: false,
  })
  videoEl.srcObject = stream
  return stream
}

export function stopCamera(stream) {
  if (stream) stream.getTracks().forEach(t => t.stop())
}

export function capturePhoto(videoEl, canvasEl) {
  return new Promise((resolve) => {
    canvasEl.width = videoEl.videoWidth || 640
    canvasEl.height = videoEl.videoHeight || 480
    const ctx = canvasEl.getContext('2d')
    ctx.translate(canvasEl.width, 0)
    ctx.scale(-1, 1)
    ctx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height)
    canvasEl.toBlob((blob) => resolve(blob), 'image/jpeg', 0.85)
  })
}