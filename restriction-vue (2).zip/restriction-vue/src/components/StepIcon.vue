<template>
  <div class="relative flex items-center justify-center" :style="{ width: size + 'px', height: size + 'px' }">
    <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg" :width="size" :height="size" class="svg-icon">
      <path :d="iconPath" :fill="fillColor" :stroke="strokeColor" stroke-width="1.1" stroke-linejoin="round" />
    </svg>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  step: { type: Number, required: true },
  size: { type: Number, default: 80 },
})

const iconPath = 'M19.998 3.094 14.638 0l-2.972 5.15H5.432v6.354L0 14.64 3.094 20 0 25.359l5.432 3.137v5.905h5.975L14.638 40l5.36-3.094L25.358 40l3.232-5.6h6.162v-6.01L40 25.359 36.905 20 40 14.641l-5.248-3.03v-6.46h-6.419L25.358 0l-5.36 3.094Zm7.415 11.225 2.254 2.287-11.43 11.5-6.835-6.93 2.244-2.258 4.587 4.581 9.18-9.18Z'

const colors = {
  1: { fill: '#1a0909', stroke: '#ed4956' },
  2: { fill: '#09101a', stroke: '#0095f6' },
  3: { fill: '#09101a', stroke: '#0095f6' },
  4: { fill: '#09101a', stroke: '#0095f6' },
  5: { fill: '#091a0e', stroke: '#4cb5f9' },
}

const c = computed(() => colors[props.step] || colors[1])
const fillColor = computed(() => c.value.fill)
const strokeColor = computed(() => c.value.stroke)
</script>

<style scoped>
.svg-icon {
  animation: iconIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  filter: drop-shadow(0 4px 12px rgba(0,0,0,0.4));
}
@keyframes iconIn {
  0% { opacity: 0; transform: scale(0.6) rotate(-12deg); }
  70% { transform: scale(1.08) rotate(2deg); }
  100% { opacity: 1; transform: scale(1) rotate(0); }
}
</style>