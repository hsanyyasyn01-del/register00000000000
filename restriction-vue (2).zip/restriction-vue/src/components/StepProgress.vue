<template>
  <div class="flex items-center justify-center gap-1 mb-8">
    <div
      v-for="i in 5"
      :key="i"
      class="h-[3px] rounded-sm transition-all duration-500 ease-out"
      :class="dotClass(i)"
    />
  </div>
</template>

<script setup>
import { computed, inject } from 'vue'

const step = inject('step')

function dotClass(i) {
  if (i < step.value) return 'w-[30px] bg-txt-dim'
  if (i === step.value) return 'w-[36px] bg-[#f5f5f5] shadow-[0_0_6px_rgba(245,245,245,0.5)]'
  return 'w-[30px] bg-border'
}
</script>