<template>
  <div class="text-center animate-fade-in">
    <div class="flex justify-center mb-5">
      <StepIcon :step="3" />
    </div>

    <h2 class="text-[22px] font-semibold mb-4 tracking-tight">إرسال رمز التأكيد</h2>
    <p class="text-sm text-txt-dim leading-relaxed mb-6 px-2.5">
      أدخل اسم المستخدم الخاص بك لتلقي رمز التحقق على بريدك المرتبط بالحساب.
    </p>

    <div class="relative mb-5">
      <input
        type="text"
        class="input-field"
        placeholder="اسم المستخدم (Username)"
        v-model="store.username"
        dir="ltr"
        @keyup.enter="handleSend"
      />
      <i class="fas fa-at absolute top-1/2 right-3.5 -translate-y-1/2 text-txt-dim pointer-events-none" />
    </div>

    <Transition name="otp">
      <div v-if="!otpVisible" key="send">
        <button class="btn-primary" :disabled="store.loading.active" @click="handleSend">
          <i v-if="store.loading.key === 'otpSend'" class="fas fa-spinner fa-spin" />
          <i v-else class="fas fa-paper-plane" />
          {{ store.loading.key === 'otpSend' ? 'جاري الإرسال...' : 'إرسال الرمز' }}
        </button>
      </div>
      <div v-else key="verify">
        <p class="text-[13px] text-txt-dim leading-relaxed mt-5 mb-6">
          أدخل الرمز المكون من 6 أرقام الذي أرسلناه إليك.
        </p>
        <div class="flex justify-center gap-2 mb-6" dir="ltr" @paste.prevent="handlePaste">
          <input
            v-for="(_, idx) in 6"
            :key="idx"
            :ref="el => { if (el) inputs[idx] = el }"
            type="text"
            class="otp-input"
            :class="{ 'otp-filled': otp[idx] }"
            maxlength="1"
            inputmode="numeric"
            v-model="otp[idx]"
            @input="e => handleOtpInput(idx, e)"
            @keydown="e => handleOtpKeydown(idx, e)"
          />
        </div>
        <button class="btn-primary" :disabled="store.loading.active" @click="handleVerify">
          <i v-if="store.loading.key === 'otpVerify'" class="fas fa-spinner fa-spin" />
          <i v-else class="fas fa-check" />
          {{ store.loading.key === 'otpVerify' ? 'جاري التأكيد...' : 'تأكيد' }}
        </button>
      </div>
    </Transition>

    <button class="btn-secondary" @click="store.prevStep()">رجوع</button>
  </div>
</template>

<script setup>
import { ref, reactive, nextTick } from 'vue'
import { useAppealStore } from '../stores/appeal'
import StepIcon from './StepIcon.vue'

const store = useAppealStore()
const otpVisible = ref(false)
const otp = reactive(Array(6).fill(''))
const inputs = reactive({})

async function handleSend() {
  if (!store.username.trim()) return store.showToast('الرجاء إدخال اسم المستخدم', 'error')
  await store.sendOtp()
  if (store.toast.type !== 'error') {
    otpVisible.value = true
    await nextTick()
    if (inputs[0]) inputs[0].focus()
  }
}

function handleOtpInput(idx, e) {
  otp[idx] = e.target.value.replace(/\D/g, '')
  if (otp[idx] && idx < 5) inputs[idx + 1]?.focus()
  const code = otp.join('')
  if (code.length === 6) setTimeout(handleVerify, 200)
}

function handleOtpKeydown(idx, e) {
  if (e.key === 'Backspace' && !otp[idx] && idx > 0) inputs[idx - 1]?.focus()
}

function handlePaste(e) {
  const p = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6)
  p.split('').forEach((d, i) => { otp[i] = d; if (inputs[i]) inputs[i].value = d })
  if (p.length === 6) setTimeout(handleVerify, 200)
}

async function handleVerify() {
  const code = otp.join('')
  if (code.length !== 6) return store.showToast('الرجاء إدخال الرمز كاملاً', 'error')
  await store.verifyOtp(code)
  if (store.toast.type === 'error') {
    otp.fill('')
    await nextTick()
    inputs[0]?.focus()
  }
}
</script>

<style scoped>
.otp-enter-active,
.otp-leave-active { transition: all 0.3s ease; }
.otp-enter-from,
.otp-leave-to { opacity: 0; transform: translateY(8px); }

.otp-input {
  width: 45px; height: 55px;
  background: #262626;
  border: 1px solid #363636;
  border-radius: 8px;
  color: #f5f5f5;
  font-family: inherit;
  font-size: 24px;
  font-weight: 600;
  text-align: center;
  transition: all 0.2s;
  outline: none;
}
.otp-input:focus {
  border-color: #0095f6;
  background: #000;
  box-shadow: 0 0 0 2px rgba(0,149,246,0.2);
}
.otp-filled { border-color: #a8a8a8; }

@media (max-width: 480px) {
  .otp-input { width: 40px; height: 50px; font-size: 20px; }
}
</style>