<template>
  <div class="text-center animate-fade-in">
    <div class="flex justify-center mb-5">
      <StepIcon :step="5" />
    </div>

    <div class="inline-flex items-center gap-1.5 bg-[#4cb5f9]/10 text-[#4cb5f9] text-xs font-semibold px-3 py-1 rounded-full mb-4">
      <i class="fas fa-clock" />
      تم الاستلام
    </div>

    <h2 class="text-[22px] font-semibold mb-4 tracking-tight">تم تقديم طلبك</h2>
    <p class="text-sm text-txt-dim leading-relaxed mb-6 px-2.5">
      تستغرق المراجعة عادةً حوالي 24 ساعة. سنقوم بإعلامك بمجرد اتخاذ قرار.
    </p>

    <div class="bg-panel rounded-xl border border-border overflow-hidden mb-6 text-right">
      <div class="flex justify-between items-center px-4 py-3.5 text-sm border-b border-border">
        <span class="text-txt-dim flex items-center gap-2">
          <i class="fas fa-calendar text-[11px]" /> تاريخ الطلب
        </span>
        <span class="font-semibold">{{ date }}</span>
      </div>
      <div class="flex justify-between items-center px-4 py-3.5 text-sm border-b border-border">
        <span class="text-txt-dim flex items-center gap-2">
          <i class="fas fa-circle text-[8px]" style="color:#e0b252" /> الحالة
        </span>
        <span class="font-semibold flex items-center gap-1.5" style="color:#e0b252">
          <i class="fas fa-spinner fa-spin text-xs" />
          قيد المراجعة
        </span>
      </div>
      <div class="flex justify-between items-center px-4 py-3.5 text-sm">
        <span class="text-txt-dim flex items-center gap-2">
          <i class="fas fa-trash-can text-[11px]" /> حذف البيانات
        </span>
        <span class="font-semibold">{{ expiresDate }}</span>
      </div>
    </div>

    <div class="bg-[#1a1a2e] border border-[#4cb5f9]/20 rounded-lg p-3 mb-6">
      <p class="text-xs text-txt-dim leading-relaxed">
        <i class="fas fa-shield-halved text-[#4cb5f9] ml-1" />
        سيتم حذف الفيديو الخاص بك نهائياً ولن يكون مرئياً على النظام بعد الانتهاء من المراجعة.
      </p>
    </div>

    <button class="btn-secondary" @click="store.logout()">
      <i class="fas fa-sign-out-alt" /> تسجيل الخروج
    </button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useAppealStore } from '../stores/appeal'
import StepIcon from './StepIcon.vue'

const store = useAppealStore()

const date = computed(() =>
  store.appealDate ? new Date(store.appealDate).toLocaleString('ar-EG') : '—'
)
const expiresDate = computed(() =>
  store.photoExpiresAt ? new Date(store.photoExpiresAt).toLocaleString('ar-EG') : '—'
)
</script>