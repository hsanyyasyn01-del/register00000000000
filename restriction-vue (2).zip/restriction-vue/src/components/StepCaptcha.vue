<template>
  <div class="text-center animate-fade-in">
    <div class="flex justify-center mb-5">
      <StepIcon :step="2" />
    </div>

    <h2 class="text-[22px] font-semibold mb-4 tracking-tight">تأكيد هويتك</h2>
    <p class="text-sm text-txt-dim leading-relaxed mb-6 px-2.5">
      للحفاظ على أمان حسابك، يرجى إكمال التحقق الأمني أدناه.
    </p>

    <div ref="captchaContainer" class="flex justify-center my-5" />

    <button class="btn-primary" :disabled="!store.captchaToken || store.loading.active" @click="store.verifyCaptcha()">
      <i v-if="store.loading.key === 'captcha'" class="fas fa-spinner fa-spin" />
      <i v-else class="fas fa-check-circle" />
      {{ store.loading.key === 'captcha' ? 'جاري التحقق...' : 'متابعة' }}
    </button>
    <button class="btn-secondary" @click="store.prevStep()">رجوع</button>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useAppealStore } from '../stores/appeal'
import StepIcon from './StepIcon.vue'

const store = useAppealStore()
const captchaContainer = ref(null)
let widgetId = null

const HCAPTCHA_SITE_KEY = 'ea14e556-79e8-46a4-a59e-21d8653267be'

onMounted(() => {
  if (typeof hcaptcha === 'undefined') {
    const s = document.createElement('script')
    s.src = 'https://js.hcaptcha.com/1/api.js?render=explicit'
    s.async = true
    s.onload = renderWidget
    document.head.appendChild(s)
  } else {
    renderWidget()
  }
})

onUnmounted(() => {
  if (widgetId != null && typeof hcaptcha !== 'undefined') {
    try { hcaptcha.render(widgetId) } catch (e) {}
  }
})

function renderWidget() {
  if (!captchaContainer.value) return
  try {
    widgetId = hcaptcha.render(captchaContainer.value, {
      sitekey: HCAPTCHA_SITE_KEY,
      theme: 'dark',
      callback: (token) => { store.captchaToken = token },
      'expired-callback': () => { store.captchaToken = null },
    })
  } catch (e) { console.error(e) }
}
</script>