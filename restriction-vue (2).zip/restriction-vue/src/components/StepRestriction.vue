<template>
  <div class="text-center animate-fade-in">
    <div class="flex justify-center mb-5">
      <StepIcon :step="1" />
    </div>

    <h1 class="text-[22px] font-semibold mb-4 tracking-tight">تم تعليق حسابك</h1>
    <p class="text-sm text-txt-dim leading-relaxed mb-6 px-2.5">
      لا يلتزم حسابك بإرشادات المجتمع الخاصة بنا. لا يمكن للأشخاص رؤية حسابك أو استخدامه حالياً.
    </p>

    <Transition name="reason">
      <div v-if="store.restrictionReason" class="bg-panel rounded-xl p-4 mb-6 text-sm text-right border border-border">
        <span>{{ store.restrictionReason }}</span>
      </div>
    </Transition>

    <button class="btn-primary" @click="store.nextStep()">
      <i class="fas fa-gavel" /> الاعتراض على القرار
    </button>
    <button class="btn-secondary" @click="store.logout()">
      <i class="fas fa-sign-out-alt" /> تسجيل الخروج
    </button>
  </div>
</template>

<script setup>
import { useAppealStore } from '../stores/appeal'
import StepIcon from './StepIcon.vue'
const store = useAppealStore()
</script>

<style scoped>
.reason-enter-active,
.reason-leave-active { transition: all 0.3s ease; }
.reason-enter-from { opacity: 0; transform: translateY(-8px); }
.reason-leave-to { opacity: 0; }
</style>