<template>
  <Transition name="toast">
    <div v-if="store.toast.show" class="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999]" :class="toastClass">
      <i :class="toastIcon" />
      <span>{{ store.toast.msg }}</span>
    </div>
  </Transition>
</template>

<script setup>
import { computed } from 'vue'
import { useAppealStore } from '../stores/appeal'

const store = useAppealStore()
const toastClass = computed(() =>
  store.toast.type === 'error'
    ? 'bg-panel text-[#f5f5f5] px-6 py-3.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 shadow-lg border-b-3 border-danger'
    : 'bg-panel text-[#f5f5f5] px-6 py-3.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 shadow-lg border-b-3 border-[#4cb5f9]'
)
const toastIcon = computed(() =>
  store.toast.type === 'error' ? 'fas fa-exclamation-circle' : 'fas fa-check-circle'
)
</script>

<style scoped>
.toast-enter-active { animation: toastSlide 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
.toast-leave-active { animation: toastSlide 0.3s ease reverse; }
@keyframes toastSlide {
  from { transform: translate(-50%, 20px); opacity: 0; }
  to { transform: translate(-50%, 0); opacity: 1; }
}
</style>