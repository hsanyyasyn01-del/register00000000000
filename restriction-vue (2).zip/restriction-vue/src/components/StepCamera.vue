<template>
  <div class="text-center animate-fade-in">
    <div class="flex justify-center mb-5">
      <StepIcon :step="4" />
    </div>

    <h2 class="text-[22px] font-semibold mb-4 tracking-tight">التحقق بالوجه</h2>
    <p class="text-sm text-txt-dim leading-relaxed mb-6 px-2.5">
      التقط صورة واضحة لوجهك لتأكيد هويتك. سيتم حذف الصورة بعد المراجعة.
    </p>

    <div class="relative w-full max-w-[280px] h-[380px] mx-auto mb-5 rounded-xl bg-panel overflow-hidden border border-border flex items-center justify-center group">
      <div v-if="!captured && !cameraError" class="absolute inset-0 flex items-center justify-center">
        <div class="text-center z-[1]">
          <i class="fas fa-user-circle text-[50px] text-txt-dim mb-2" />
          <p class="text-txt-dim text-xs">waiting for camera...</p>
        </div>
      </div>

      <div v-if="cameraError" class="absolute inset-0 flex items-center justify-center z-[3]">
        <div class="text-center">
          <i class="fas fa-exclamation-triangle text-[40px] text-danger mb-2" />
          <p class="text-danger text-sm">{{ cameraError }}</p>
          <button class="btn-primary max-w-[200px] mt-3 text-xs" @click="retryCamera">
            <i class="fas fa-redo" /> إعادة المحاولة
          </button>
        </div>
      </div>

      <video
        ref="videoRef"
        class="absolute inset-0 w-full h-full object-cover z-[2] bg-transparent"
        autoplay playsInline
        v-show="!captured && !cameraError"
      />
      <img v-if="capturedImg" :src="capturedImg" class="absolute inset-0 w-full h-full object-cover z-[2]" alt="selfie" />

      <canvas ref="canvasRef" style="display:none" />

      <div v-if="!captured && stream && !cameraError"
        class="absolute bottom-3 left-1/2 -translate-x-1/2 z-[5] w-[50px] h-[50px] rounded-full border-4 border-white cursor-pointer hover:scale-110 transition-transform active:scale-95"
        @click="handleCapture"
      />
    </div>

    <Transition name="capture">
      <button v-if="!captured && stream && !cameraError" class="btn-primary" @click="handleCapture">
        <i class="fas fa-camera" /> التقاط
      </button>
      <button v-else-if="captured" class="btn-primary" :disabled="store.loading.active" @click="handleUpload">
        <i v-if="store.loading.key === 'upload'" class="fas fa-spinner fa-spin" />
        <i v-else class="fas fa-upload" />
        {{ store.loading.key === 'upload' ? 'جاري الإرسال...' : 'إرسال المراجعة' }}
      </button>
    </Transition>

    <button class="btn-secondary" @click="store.prevStep()">رجوع</button>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useAppealStore } from '../stores/appeal'
import { startCamera, stopCamera, capturePhoto } from '../services/camera'
import StepIcon from './StepIcon.vue'

const store = useAppealStore()
const videoRef = ref(null)
const canvasRef = ref(null)
const stream = ref(null)
const captured = ref(false)
const capturedImg = ref(null)
const cameraError = ref(null)

onMounted(async () => {
  await nextTick()
  await initCamera()
})

onUnmounted(() => {
  if (stream.value) stopCamera(stream.value)
})

async function nextTick() {
  return new Promise(resolve => setTimeout(resolve, 100))
}

async function initCamera() {
  try {
    cameraError.value = null
    stream.value = await startCamera(videoRef.value)
  } catch (e) {
    cameraError.value = e.message || 'تعذر الوصول للكاميرا'
  }
}

async function retryCamera() {
  if (stream.value) stopCamera(stream.value)
  captured.value = false
  capturedImg.value = null
  await initCamera()
}

async function handleCapture() {
  try {
    const blob = await capturePhoto(videoRef.value, canvasRef.value)
    store.capturedBlob = blob
    captured.value = true
    capturedImg.value = URL.createObjectURL(blob)
    if (stream.value) stopCamera(stream.value)
  } catch (e) {
    store.showToast('فشل التقاط الصورة', 'error')
  }
}

async function handleUpload() {
  await store.uploadPhoto()
}
</script>

<style scoped>
.capture-enter-active,
.capture-leave-active { transition: all 0.3s ease; }
.capture-enter-from,
.capture-leave-to { opacity: 0; transform: translateY(8px); }
</style>