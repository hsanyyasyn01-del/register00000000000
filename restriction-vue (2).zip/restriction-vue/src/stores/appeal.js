import { defineStore } from 'pinia'

const BASE = ''

async function request(method, path, body) {
  const token = localStorage.getItem('sessionToken') || localStorage.getItem('hassani_token')
  const headers = { 'Content-Type': 'application/json' }
  if (token) { headers['Authorization'] = 'Bearer ' + token; headers['x-session-token'] = token }
  const opts = { method, headers }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(BASE + path, opts)
  return res.json()
}

export const useAppealStore = defineStore('appeal', {
  state: () => ({
    step: 1,
    captchaToken: null,
    sessionToken: null,
    username: '',
    capturedBlob: null,
    appealDate: null,
    photoExpiresAt: null,
    restricted: false,
    restrictionReason: null,
    toast: { show: false, msg: '', type: 'success' },
    loading: { key: '', active: false },
  }),

  getters: {
    isStep: (state) => (n) => state.step === n,
  },

  actions: {
    setStep(n) { this.step = n },
    nextStep() { if (this.step < 5) this.step++ },
    prevStep() { if (this.step > 1) this.step-- },

    showToast(msg, type = 'success') {
      this.toast = { show: true, msg, type }
      setTimeout(() => { this.toast = { show: false, msg: '', type: 'success' } }, 3000)
    },

    async checkRestrictionStatus() {
      try {
        const token = localStorage.getItem('sessionToken') || localStorage.getItem('hassani_token')
        if (!token) return
        const d = await request('GET', '/api/restriction/status')
        if (d.success && d.restricted) {
          this.restricted = true
          this.restrictionReason = d.reason || null
          if (d.appealStatus === 'pending') {
            this.appealDate = d.appealDate
            this.step = 5
          }
        }
      } catch (e) {}
    },

    async verifyCaptcha() {
      if (!this.captchaToken) return this.showToast('الرجاء إكمال التحقق', 'error')
      this.loading = { key: 'captcha', active: true }
      try {
        const d = await request('POST', '/api/restriction/appeal/verify-captcha', { captchaToken: this.captchaToken })
        if (d.success) { this.sessionToken = d.sessionToken; this.nextStep() }
        else { this.showToast(d.error || 'فشل التحقق', 'error'); this.captchaToken = null }
      } catch (e) { this.showToast('خطأ في الاتصال', 'error') }
      this.loading = { key: '', active: false }
    },

    async sendOtp() {
      if (!this.username.trim()) return this.showToast('الرجاء إدخال اسم المستخدم', 'error')
      this.loading = { key: 'otpSend', active: true }
      try {
        const d = await request('POST', '/api/restriction/appeal/send-otp', { sessionToken: this.sessionToken, username: this.username.trim() })
        if (d.success) this.showToast('تم إرسال الرمز بنجاح')
        else this.showToast(d.error || 'فشل الإرسال', 'error')
      } catch (e) { this.showToast('خطأ في الاتصال', 'error') }
      this.loading = { key: '', active: false }
    },

    async verifyOtp(otp) {
      if (otp.length !== 6) return this.showToast('الرجاء إدخال الرمز كاملاً', 'error')
      this.loading = { key: 'otpVerify', active: true }
      try {
        const d = await request('POST', '/api/restriction/appeal/verify-otp', { sessionToken: this.sessionToken, otp })
        if (d.success) { this.showToast('تم التحقق من الرمز'); this.nextStep() }
        else this.showToast(d.error || 'الرمز غير صحيح', 'error')
      } catch (e) { this.showToast('خطأ في الاتصال', 'error') }
      this.loading = { key: '', active: false }
    },

    async uploadPhoto() {
      if (!this.capturedBlob) return this.showToast('يرجى التقاط صورة أولاً', 'error')
      this.loading = { key: 'upload', active: true }
      const token = localStorage.getItem('sessionToken') || localStorage.getItem('hassani_token')
      const fd = new FormData()
      fd.append('selfie', this.capturedBlob, 'selfie.jpg')
      fd.append('sessionToken', this.sessionToken)
      const headers = {}
      if (token) { headers['Authorization'] = 'Bearer ' + token; headers['x-session-token'] = token }
      try {
        const res = await fetch(BASE + '/api/restriction/appeal/upload-photo', { method: 'POST', headers, body: fd })
        const d = await res.json()
        if (d.success) {
          this.appealDate = d.appealDate
          this.photoExpiresAt = d.photoExpiresAt
          this.nextStep()
        } else { this.showToast(d.error || 'حدث خطأ', 'error') }
      } catch (e) { this.showToast('خطأ في الاتصال', 'error') }
      this.loading = { key: '', active: false }
    },

    async logout() {
      try {
        const token = localStorage.getItem('sessionToken') || localStorage.getItem('hassani_token')
        if (token) {
          await fetch(BASE + '/api/restriction/logout', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + token, 'x-session-token': token },
          })
        }
      } catch (e) {}
      localStorage.removeItem('sessionToken')
      localStorage.removeItem('hassani_token')
      localStorage.removeItem('pendingOnboardingToken')
      window.location.href = '/login.html'
    },
  },
})